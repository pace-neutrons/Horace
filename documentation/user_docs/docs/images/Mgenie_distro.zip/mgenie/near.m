function ind=near(value,array)
% Find the index of the elementof an array that is closest to a given value
%
%   >> ind=near(value,array)
%
del=abs(array-value);
[true_value,ind]=min(del);
display(['Nearest value: ',num2str(array(ind))])
