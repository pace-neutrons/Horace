function [delta, twotheta, azimuth, x2] = get_secondary_spectra
% Get secondary spectrometer information for all spectra, with the information
% being returned in order of increasing spectrum number
% Information in obtained by averaging that for all the detectors contributing to the spectrum
% Assumes that spectra are numbered 0,1,2,...nspec (ISIS ICP guarantees this)

spec = gget('spec');
[spec,ind]=sort(spec);
% get first index where spectrum number=1
ilo=lower_index(spec,1);
if ilo>length(spec) % all spectra are zero length
    delta = [];
    twotheta = [];
    azimuth = [];
    x2 = [];
else
    [delta, twotheta, azimuth, x2] = get_secondary;
    nspec = spec(end);  % number of spectra
    ndet  = accumarray(spec(ilo:end)',ones(size(ind(ilo:end))),[nspec,1])';
    delta   = accumarray(spec(ilo:end)',delta(ind(ilo:end)),[nspec,1])'./ndet;
    twotheta= accumarray(spec(ilo:end)',twotheta(ind(ilo:end)),[nspec,1])'./ndet;
    azimuth = accumarray(spec(ilo:end)',azimuth(ind(ilo:end)),[nspec,1])'./ndet;
    x2      = accumarray(spec(ilo:end)',x2(ind(ilo:end)),[nspec,1])'./ndet;
end
