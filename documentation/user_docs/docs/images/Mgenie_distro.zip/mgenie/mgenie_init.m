function mgenie_init (initialisation_file)
% Adds the paths needed by mgenie.
%
% In your startup.m, add the mgenie root path and call mgenie_init, e.g.
%       addpath('c:\mprogs\mgenie')
%       mgenie_init
%
% or if you have an initialisation file for mgenie that sets up data paths
% instrument parameters and so on:
%       addpath('c:\mprogs\mgenie')
%       mgenie_init('c:\tgp\maps_setup.m')
%
%
% Is PC and Unix compatible.

% T.G.Perring

% root directory is assumed to be that in which this function resides
rootpath = fileparts(which('mgenie_init'));
addpath(rootpath)  % MUST have rootpath so that mgenie_init, mgenie_off included

% Compiled Fortran mex files
addpath_message (rootpath,'fortran');

% Perform initialisation
if exist('initialisation_file','var')
    mgenie_setup_file(initialisation_file)
end
genie_init


%--------------------------------------------------------------------------
function addpath_message (varargin)
% Add a path from the component directory names, printing a message if the
% directory does not exist.
% e.g.
%   >> addpath_message('c:\mprogs\libisis','bindings','matlab','classes')

% T.G.Perring

string=fullfile(varargin{:});
if exist(string,'dir')==7
    addpath (string);
else
    warning('"%s" is not a directory - not added to path',string)
end

