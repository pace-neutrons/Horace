function xrem = remove_ranges_slice (wslice, xkeep, xremove)
% Given bin centres of a slice, and ranges xkeep and xremove, return a cell array of
% remove ranges for use with Tobyfit
%
%   >> xrem = remove_ranges_slice (wslice, xkeep, xremove)
%
% Input:
%   wslice  Slice as read into matlab using read_slice (i.e. array of mgenie spectra)
%   xkeep   Ranges of x and y to retain for fitting. A range is specified by an array
%               [xlo, xhi, ylo, yhi]
%           More than one range can be defined in rows,
%               [xlo_1, xhi_1, ylo_1, yhi_1; xlo_2, xhi_2, ylo_2, yhi_2;...]
%   xremove Ranges to remove from fitting. Follows the same format as xkeep
%
% Output:
%   xrem    Cell array of 2xm arrays containing the lower and upper limits of 
%           ranges to be removed from each strip of the slice
%             e.g. 
%               xrem{1}=[p1, p2, p3, ...; q1, q2, q3, ...]
%             means remove p1 to q1, and p2 to q2, etc.
%           xrem{i} refers to the ith strip of the cut
%
%           If no range is to be removed from strip i, then xrem{i}=[]
%           Even if the slice contains no data in strip i, there is a corresponding entry xrem{i}
%
%  The output cell array xrem can be used to construct a list of commands for Tobyfit for the
% a slice using the new multi-frills command @rmuse to remove ranges
%
%   # @rmuse <irun> <idataset> 1 p1 q1    (p1 q1 from xrem{1})
%   # @rmuse <irun> <idataset> 1 p2 q2
%           :
%   # @rmuse <irun> <idataset> 2 p1 p2    (p1 q1 from xrem{2})
%           :

% Get the x and y centre values
xbnd=get(wslice(1),'x');
x1=0.5*(xbnd(2:end)+xbnd(1:end-1));
tmp=read_labels(get(wslice(1),'title'));
ystart=str2num(tmp.mgenie_control_y_start);
ystep=str2num(tmp.mgenie_control_y_step);
ny=length(wslice);
x2=ystart+(0:ny-1)*ystep;

% Find points to be retained for fit
x=ndgridcell({x1,x2});
zarr=ones(size(x{1}));
earr=ones(size(x{1}));
sel = retain_for_fit (x, zarr, earr, xkeep, xremove, []);

% Remove points
xrem=cell(numel(x2),1);
for i=1:numel(x2)
    xrem{i}=remove_ranges(xbnd,sel(:,i));
end
