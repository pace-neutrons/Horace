function mgenie_mex
% Create mex files for all the mgenie fortran routines
%
% Assumes that the library speclib.lib exists in the same folder
% as the main fortran programs

% TGP's own programs:

start_dir=pwd;
try
    % root directory is assumed to be that in which this function resides
    rootpath = fileparts(which('mgenie_mex'));
    cd(rootpath);

    in_rel_dir = 'fortran';
    out_rel_dir = 'fortran';
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_deriv2.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_deriv.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_integrate.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_rebin_by_descriptor.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_rebin_by_spectrum.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_regroup.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_units.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'spectrum_unspike.for');

    mgenie_mex_single(in_rel_dir, out_rel_dir,'get_cut_fortran.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'get_slice_fortran.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'get_spe_fortran.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'put_cut_fortran.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'put_slice_fortran.for');
    mgenie_mex_single(in_rel_dir, out_rel_dir,'put_spe_fortran.for');
    cd(start_dir);
    disp('Succesfully created all required mex files from fortran.')
catch
    disp('Problems creating mex files. Please try again.')
    cd(start_dir);
end

%----------------------------------------------------------------
function mgenie_mex_single (in_rel_dir, out_rel_dir, flname)
% mex a single file
curr_dir = pwd;
flname = fullfile(curr_dir,in_rel_dir,flname);
outdir = fullfile(curr_dir,out_rel_dir);

speclib = fullfile(curr_dir,'fortran','speclib.lib');

disp(['Mex file creation from ',flname,' ...'])
mex(flname, '-outdir', outdir, speclib);
