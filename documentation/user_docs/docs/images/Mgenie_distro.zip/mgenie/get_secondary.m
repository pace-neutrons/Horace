function [delta, twotheta, azimuth, x2] = get_secondary
% Get secondary spectrometer information for all detectors
% Used to allow different interpretations of user tables depending on
% instrument and run number, for example.
%
% Syntax:
%   >> [delta, twotheta, azimuth, x2] = get_secondary
%

global genie_handle
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

delta = gget('delt');
x2 = gget('len2');
twotheta = gget('tthe');

inst = genie_instrument;
if (strcmp(lower(inst),'mer')|strcmp(lower(inst),'map')|strcmp(lower(inst),'het')|strcmp(lower(inst),'mar')) & double(gget('nuse'))>=1
    azimuth = gget('ut1');
else
    azimuth = zeros(1,gget('ndet'));
end
    
