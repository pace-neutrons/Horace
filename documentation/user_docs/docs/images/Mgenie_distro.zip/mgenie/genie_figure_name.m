function fig_name = genie_figure_name(name)
% Get plot figure name following these rules
% - if the name is character string, not empty -> fig_name = name
%                                     is empty -> fig_name = name of current figure
% - if the name is a number, not empty -> fig_name = name of numbered figure
%                             is empty -> fig_name = name of current figure
%
% if cannot satisfy these rules (e.g. figure number does not exist, or name is empty
% and current window has no name) then returns empty string, for calling routine
% to recognise and take action it sees fit.

if ischar(name)
    if ~isempty(name)
        fig_name=name;
    else
        h_current_figure=get(0,'CurrentFigure');
        if ~isempty(h_current_figure)
            fig_name = get(h_current_figure,'name');    % will be '' if no name
        else
            fig_name = '';  % no current figure
        end
    end
elseif isnumeric(name)
    if ~isempty(name)
        h_figs=findobj(0,'type','figure');  % all figure handles; handle is same as figure number
        n=find(h_figs==name);
        if ~isempty(n)
            fig_name = get(h_figs(n),'name');
        else
            fig_name = '';
        end
    else
        fig_name = '';
    end
else
    fig_name = '';
end
