function xy
% Puts cross-hairs on the screen and prints the position of the cursor cross
% when the left pouse button is pressed. Continues until carriage return is hit.

val=[0,0];
display ('Click left mouse button; <carriage return> to finish')
while ~isempty(val)
    val = ginput(1);
    if ~isempty(val)
        display (['x value: ',num2str(val(1),'%16.6g'),'    y value: ',num2str(val(2),'%16.6g')])
        disp(' ')
    end
end