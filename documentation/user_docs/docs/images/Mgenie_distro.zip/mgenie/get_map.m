function map_out = get_map (file_internal)
% FOR INTERNAL USE - USE LOAD_MAP
% 
% GET_MAP reads the list of spectra in a map file into a cell array of 1D arrays.
% Each array contains the spectra for that workspace. For example, if the examples below
% are used to load a map file into the cell array, map:
%
%   map{1}  array of spectra in workspace 1
%   map{2}  array of spectra in workspace 2
%    :                    :
%
% Syntax
%   >> map = get_map (file)    % read from named file
%   >> map = get_map           % prompts for file
%


% Read data from file
% ---------------------
fid = fopen(file_internal);
% skip over lines that begin with '!'
first_line = 1;
nw = 0;
iw = 1;
ns = 0;
while 1
    istring = fgetl(fid);
    if ~ischar(istring)
        if nw < 1 | iw<= nw
            error ('Check format of .map file')
        else
            break
        end
    end
    if (~strcmp(istring(1:1),'!'))
        if first_line==1 % first line to be read
            first_line = 0;
            nw = str_to_iarray(istring);
            if length(nw)~=1
                error ('Check format of .map file')
            elseif nw < 1
                error ('Check number of workspaces declared in first non-comment line')
            else
                map = cell(1,nw);
            end
        else
            if ns==0   % array not declared yet
                if iw > nw
                    error ('Check format of .map file: excess uncommented information at bottom of file')
                end
                wdata = sscanf(istring,'%d');
                if ~isempty(wdata)   % header line for workspace
                    if wdata(1) > 0
                        ns = wdata(1);
                    else
                        error (['Check number of spectra declared for workspace ',num2str(iw)])
                    end
                else
                    error (['Check format of .map file at workspace ',num2str(iw)])
                end
            else
                map{iw} = [map{iw}, str_to_iarray(istring)];
                if length(map{iw})==ns
                    map{iw}=sort(map{iw});
                    if round(min(diff(map{iw}))) == 0
                        error (['One or more spectra are repeated in mapping for workspace ',num2str(iw)])
                    else
                        map{iw}=round(map{iw});
                    end
                    iw = iw + 1;
                    ns = 0;
                end
            end
        end
    end
end
fclose (fid);
map_out = map;
