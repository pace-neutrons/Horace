function [] = set_inst (instrument)
%SET_INST Set instrument
%
global genie_handle
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% check the instrument is a character string of three letters:
if(~isa(instrument,'char') | size(instrument,1)~=1 | size(deblank(instrument),2)~=3)
    error ('Instrument must be a three character string')
end
genie_instrument = deblank(instrument);
