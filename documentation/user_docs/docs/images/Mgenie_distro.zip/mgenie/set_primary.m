function [] = set_primary (x1)
% Set moderator-to-sample distance (m).
%
% Syntax:
%   >> set_primary (x1)
%
% To view current values, use with no arguments:
%   >> set_primary
%

global genie_handle
global genie_efix genie_x1 genie_emode
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% check arguments and set parameters:
small = 1.0e-10;
if (nargin==1)
    if isa(x1,'double')
        if (x1 < small)
            error ('Moderator-sample distance must be greater than zero')
        end
        genie_x1 = x1;
    else
        error('Check parameter type')
    end
elseif (nargin > 1)
    error ('Check number of arguments')
end

% Print values to screen
disp(['                       Fixed energy (meV) : ',num2str(genie_efix,5)])
disp(['            Moderator-sample distance (m) : ',num2str(genie_x1,5)])
disp(['                              Energy mode : ',num2str(genie_emode)])
disp(' ')
