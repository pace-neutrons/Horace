function amark(varargin)
% AMARK: Change the marker type and size in MGENIE plots.
%
% Syntax examples:
%	>> amark(6)
%	>> amark(10,'+')
%   >> amark('+')
%	>> amark('+',10)    *** NOT VALID IN COMMAND LINE MODE
%
% Arguments can set a sequence of type and/or size for cascade plots e.g.
%   >> amark (13,14,'+','*','.')
%   >> amark ({'v','p'},5:15)       % example with a cell array
%
%        Valid marker types:
%           '+', 'o', '*', '.', 'x', 's', 'd', '^', 'v', '>', '<', 'p', 'h'
%                                     |    |    |  triangles   |    |    |
%                                     |    |                        |    |
%                            square --|    |       5-pointed star --|    |
%                            diamond ------|       6-pointed star -------|
%
%
%        Size of markers is in points (default size is 6)

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

% Create two row vectors, of marker sizes and marker types:
n = length(varargin);
if n < 1
    genie_marker_size
    genie_marker
    return
end
nsize = 0;
mark_size = [];
ntype = 0;
mark_type =[];
for i = 1:n
    try
        temp = evalin('caller',varargin{i});
    catch
        temp = varargin{i};
    end
    if isa_size(temp,'vector','numeric')
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        mark_size = [mark_size,temp];
    elseif isa_size(temp,'vector','cellstr')
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        mark_type = [mark_type,temp];
    elseif isa(temp,'char') && length(size(temp))==2
        temp=strtrim(cellstr(temp));
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        mark_type = [mark_type,temp];
    else
        error ('Check argument type(s)')
    end
end

% check validity of input arguments
if length(mark_size)>0
    if min(mark_size) >= 0.1 & max(mark_size) <= 50
        genie_marker_size = mark_size;
    else
        error ('Marker size is too small or too large - left unchanged (amark)')
    end
end

markers = {'+', 'o', '*', '.', 'x', 's', 'd', '^', 'v', '>', '<', 'p', 'h'};
if length(mark_type)>0
    for i=1:length(mark_type)
        itype = string_find (mark_type{i}, markers);
        if itype==0
            error ('Invalid marker type - left unchanged (amark)')
        elseif itype<0
            error ('Ambiguous abbreviation of marker type - left unchanged (amark)')
        end
    end
    genie_marker = mark_type;
end