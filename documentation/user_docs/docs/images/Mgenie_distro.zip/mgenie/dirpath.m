function files = dirpath (name_in)
% DIRPATH - Performs the matlab 'DIR' operation on files that incorporate
%           a user path or environment variable in the file name
%           (see >> help set_globalpath for details of user paths).
%
% Syntax:
%   >> dirpath name
%   >> dirpath ('name')
%   >> files = dirpath ('name')
%
%   name    The name of a file, including wildcards
%           e.g. 'mystuff.txt'  'data_path:map071*.raw'
%
%   file    List of files in an mx1 structure with fields
%               name    Full file name
%               date    Modification date
%               bytes   Number of bytes allocated to the file
%               isdir   0 if a file, 1 id a directory

% *** CARE MUST BE TAKEN TO ENSURE THAT THIS ROUTINE AND DIRPATH ARE CONSISTENT

if nargin==0
    name = '';
else
    name = name_in;
end

path_found = 0;
if nargout==1
    files=[];
end

% Find out if file_in has form nnn:mmm
[path_name, file_name] = pathstrip(name);
if ~isempty(path_name)
    % name includes a global path or environment variable
    % check if path is a global user path
    [path, mess] = get_globalpath(path_name);
    if isempty(mess)   % is a global user path
        p = getuserpath(path);
        if length(p)>0 % path not empty
            for i=1:length(p)
                if exist(p{i},'dir')==7   % check directory exists
                    file_out = fullfile(p{i},file_name);
                    if ~path_found; path_found=1; end   % indicate that a valid path has been searched
                    if nargout==0
                        disp (['----- ',p{i},' contains:'])
                        dir (file_out)
                        disp(' ')
                    else
                        files = [files; dir(file_out)];
                    end
                end
            end
        end
    end
    % check if path is an environment variable pointing to a directory
    trans = getenv(path_name);
    if exist(trans,'dir')==7
        file_out = fullfile(trans,file_name);
        if ~path_found; path_found=1; end   % indicate that a valid path has been searched
        if nargout==0
            disp (trans)
            dir (file_out)
            disp(' ')
        else
            files = [files; dir(file_out)];
        end
    end
end

% Check if found a valid path; if yes then return, if not then treat as if normal Matlab 'dir' command

if path_found   
    return
else
    if nargout==0
        dir(name)
    else
        files = dir(name);
    end
end
