function [] = bin (n)
% BIN(n)  alters binning for graphics, where N has integer value
%
global genie_binning

small = 1.0e-10;

if (isa(n,'double'))
    n_temp = n;
elseif (isa(n,'int32'))
    n_temp = double(n);
else
    error ('Check run number is a number.')
end

if (abs(n_temp-round(n_temp)) < small & n_temp > 0.5)
    genie_binning = n_temp;
else
    error ('Graphics binning must be an integer >= 1')
end