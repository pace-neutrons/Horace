function wout=spe_to_spectrum(spe)
% Convert a .spe data structure into an array of mgenie spectra
%
%   >> wout=spe_to_spectrum(spe)
%
%   spe     spe data structure as read in by get_spe
%
%   wout    Array of Mgenie spectra. Will be histogram spectra

null_data = -1e30;

% Determine if a spectrum contains null data; fill with NaN if null
ind = find(spe.S(1,:)<=null_data);   % check on basis of first element
if ~isempty(ind)
    spe.S(:,ind) = NaN;
    spe.ERR(:,ind) = 0;
end

ndet = size(spe.S,2);
ne = size(spe.S,1);
if (ndet==1)    % just one detector in the SPE file
    wout = spectrum(spe.en, spe.S, spe.ERR, avoidtex(fullfile(spe.filepath,spe.filename)),'Energy transfer','Intensity','meV',1);
else
    wout = spectrum(spe.en, zeros(ne,1), zeros(ne,1), avoidtex(fullfile(spe.filepath,spe.filename)),'Energy transfer','Intensity','meV',1);
    wout = repmat(wout,1,ndet);
    for i=1:ndet
        wout(i) = set_simple (wout(i), 'y', spe.S(:,i),  'e', spe.ERR(:,i));
    end
end

