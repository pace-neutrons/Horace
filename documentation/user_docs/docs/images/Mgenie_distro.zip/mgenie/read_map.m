function wout = read_map (file)
% READ_MAP reads the list of spectra in a map file into a spectrum suitable for plotting.
% 
%
% Syntax
%   >> w = read_map (file)    % read from named file
%   >> w = read_map           % prompts for file
%
%  x-axis:  spectrum number (range is min to max spectrum number)
%  y-axis:  corresponding workspace number. Set to zero if no workspace
%  errors:  If a spectrum goes to more than one workspace, gives the spread workspace numbers
%           i.e. y(iw)-e(iw) and y(iw) + e(iw) are the limits of the workspace numbers
%


% Get file name - prompt if file does not exist (using file to set default seach location and extension
% -----------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.map');
end
if (isempty(file_internal))
    error ('No file given')
end


% Use get routine:
% -----------------
map = get_map (file_internal);


% Construct spectrum:
% ------------------------------------------
nw = length(map);   % no. workspaces
ns = zeros(1,nw);   % will contain no. spectra in each workspace
for i=1:nw
    ns(i) = length(map{i});
end

nscum=[0,cumsum(ns)];
w=zeros(1,nscum(end));    % will contain list of corresponding workspaces
for i=1:nw
    w(nscum(i)+1:nscum(i+1))=i;
end
s=cell2mat(map)  ;

[s,iarr]=sort(s);   % sort into order of increasing spectrum number
w=w(iarr);          
ib=find([1,diff(s)]>0);     % index of first occurences of each spectrum number
ie=find([diff(s),1]>0);     % index of last occurences
s_out = linspace(1,s(end),s(end));         % array of spectrum numbers
if max(ie-ib)==0
    w_mean = zeros(1,s(end));
    w_mean(s(ib)) = w(ib);
    e(1:s(end)) = 0;
else
    disp ('Note: at least one spectrum appears in more than one workspace')
    wmin = zeros(1,s(end));
    wmax = zeros(1,s(end));
    for i=1:length(ib)      % loop over distinct spectra
        wmin(s(ib(i))) = min(w(ib(i):ie(i)));
        wmax(s(ib(i))) = max(w(ib(i):ie(i)));
    end
    w_mean = 0.5.*(wmax-wmin);
    e = 0.5.*(wmax-wmin);
end

wout = spectrum(s_out, w_mean, e, avoidtex(file_internal), 'Spectrum number', 'Workspace number', '', 0);


% [s,iarr]=sort(s);   % sort into order of increasing spectrum number
% w=w(iarr);          
% ib=find([1,diff(s)]>0);     % index of first occurences of each spectrum number
% ie=find([diff(s),1]>0);     % index of last occurences
% s_distinct = s(ib);         % array of distinct spectrum numbers
% if max(ie-ib)==0
%     w_mean = w(ib);
%     e(1:length(ib)) = 0;
% else
%     disp ('Note: at least one spectrum appears in more than one workspace')
%     wmin = zeros(1,length(s_distinct));
%     wmax = zeros(1,length(s_distinct));
%     for i=1:length(ib)      % loop over distinct spectra
%         wmin(i) = min(w(ib(i):ie(i)));
%         wmax(i) = max(w(ib(i):ie(i)));
%     end
%     w_mean = 0.5.*(wmax-wmin);
%     e = 0.5.*(wmax-wmin);
% end
%
% wout = spectrum(s_distinct, w_mean, e, avoidtex(file_internal), 'Spectrum number', 'Workspace number', '', 0);

disp (['Data read from ' file_internal])