function [] = sh_bin ()
% SH_BIN  Shows binning for graphics
%
global genie_binning

disp(strcat(['Present graphics binning = ' num2str(round(genie_binning))]))
