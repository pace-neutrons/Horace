function genie_off
%GENIE_OFF
%  Clears global parameters created in genie_init
%  Ensure that the variables in the two functions are synchronised

try
    clear global genie_handle
    clear global genie_binning
    clear global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale
    clear global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
    clear global genie_efix genie_x1 genie_emode
    clear global genie_setup_file
    clear global genie_mgenie_initialised genie_opengenie_present

    clear global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant

    gget_off;   % cleanup after gget_init
catch
    error('Error cleaning up the mgenie install')
end
