function ans = gget (nam)
% GGET Retrieve information for the named variable from an ISIS raw file
%
global isisraw_hdr isisraw_run isisraw_field

% Check NAM is a single character string
% ----------------------------------------
if(~isa(nam,'char') | size(nam,1)~=1)
    error ('Input field name must be a character array (GGET)')
end

warning off;    % turn off warnings that are printed if use 6.1

% Is NAM a valid raw file field name ?
% -------------------------------------
ind = strmatch(lower(nam),isisraw_field.name,'exact');
if (ind > 0)
    ans = genie_get(nam);
    warning on;
    return
end

% Is NAM of the form CNT1[m:n] ? (i.e. read a section of the CNT1 array)
% ------------------------------
if (strfind(lower(nam),'cnt1[')==1 & nam(end:end)==']' & ~isempty(strfind(nam(6:end-1),':')>1)) % has format cnt1[xx:xx]
    ipos = strfind(nam,':');
    islo = str2num(nam(6:ipos-1));
    ishi = str2num(nam(ipos+1:end-1));
    warning on;
    nspec = double(genie_get('nper'))*(double(genie_get('nsp1'))+1) - 1;    % maximum spsectrum number in a multi-period run
    if( (size(ipos,2)==1) & ...   % Checks only one : found
        (~isempty(islo) & islo >= 0) & (~isempty(ishi) & (ishi <= nspec)) & (islo <= ishi) )
        ans = genie_get(nam);
        return
    else
        error (['Count array section must have form CNT1[m:n], with 0 =< m =< n =< ',num2str(nspec),' (GGET)'])
    end
end

% Is NAM a valid derived raw file field ?
% ---------------------------------------
% User tables for detector information:
if (strfind(lower(nam),'ut')==1 & ~isempty(str2num(nam(3:end))))  % NAM starts with the two letters UT, and the rest is a number
    n = round(str2num(nam(3:end)));
    warning on;
    if (n >= 1 & n <= genie_get('nuse')) % table number in range 1 to NUSE
        ans = genie_get(nam);
        return
    else
        error ('Must have UTnn with nn in range 1 to NUSE (GET)')
    end
end

% sample environment block information: check if NAM starts with SE, RSE or CSE, and that the rest is a number
n=0;
if (strfind(lower(nam),'se')==1 & ~isempty(str2num(nam(3:end))))
    n = round(str2num(nam(3:end)));
end
if ((strfind(lower(nam),'rse')==1 | strfind(lower(nam),'cse')==1) & ~isempty(str2num(nam(4:end))))
    n = round(str2num(nam(4:end)));
end
if (n ~= 0)
    warning on;
    if (n >= 1 & n <= genie_get('nsep')) % table number in range 1 to NSEP
        ans = genie_get(nam);
        return
    else
        error ('Must have SEnn/RSEnn/CSEnn with nn in range 1 to NSEP (GET)')
    end
end

% Determine if NAM is not in the RAW file field definitions, but is defined by GENIE_INIT as a valid name
% --------------------------------------------------------------------------------------------------------
% (Many fields in the raw file are obscure e.g. uA.hr is in RRPB(8) !)

% Is NAM in HEADER section ?
ind = strmatch(lower(nam),isisraw_hdr.name,'exact');
if (ind > 0)
    temp = genie_get('hdr');
    ans = temp(isisraw_hdr.begin(ind):isisraw_hdr.end(ind));
    warning on;
    return
end

% Is NAM in RUN section ?
ind = strmatch(lower(nam),isisraw_run.name,'exact');
if (ind > 0)
    temp = genie_get(isisraw_run.raw_name(ind,:));
    ans = temp(isisraw_run.index(ind));
    if (iscellstr(ans) & max(size(ans))==1)    % if a cellstring with a single entry, then convert to character string
        ans = char(ans);
    end
    warning on;
    return
end

% Any other custom names dealt with on a case-by-case basis:
% ----------------------------------------------------------
if (strmatch(lower(nam),'tchan1','exact') > 0)   % return time channel boundaries in microseconds
    daep = genie_get('daep');
    pre1 = genie_get('pre1');
    ans = (double(pre1).*double(genie_get('tcb1')) + 128*double(daep(24)))/32;
    warning on;
    return
end

if (strmatch(lower(nam),'dtchan1','exact') > 0)   % return widths of time channel boundaries in microseconds
    pre1 = genie_get('pre1');
    temp = double(genie_get('tcb1'));
    ans = (double(pre1)/32).*(temp(2:end)-temp(1:end-1));
    warning on;
    return
end


% Not a valid variable name
% ----------------------------

error ('Unrecognised data field name (GET)')

