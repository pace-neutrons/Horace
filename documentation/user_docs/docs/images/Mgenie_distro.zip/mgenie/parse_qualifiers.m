function [parameter,present,index,message]=parse_qualifiers(qualifier,takes_value,arglist,nstart)
% [present,index,message]=parse_qualifiers(qualifier,takes_value,arglist,nstart)
%
% Given a cellstr of qualifiers, qualifier, and a array of the same length indicating if a
% parameter is required (0=no, 1=yes), this function searches a cell array of arguments, arglist,
% for those qualifiers, returning structures with field names the same as those of the qualifiers
% with values 0 or 1 for present and the index in the arglist of the corresponding value if
% one is required. The indices of those arguments not identified as qualifiers or their values are
% returned in the array parameter.
%
% Ensure that the qualifiers are all lower case; the comparison is insensitive to the case in arglist
% Qualifiers are succesfully identified if they are unambiguous abbreviations.
% Optionally, nstart gives the starting element number for searching for qualifiers in arglist.
%
% e.g.
%   qualifier = {'any','bear','belt'}
%   takes_value = [0,1,0]
%
%   arglist = {'bel',20,30,'bea',999,'any'}
%   nstart = 2
%
% then:
%   parameter = [1,2,3]
%
%   present.any = 1
%   present.bear= 1
%   present.belt= 0 % 'bel' was ignored as we started the search only at the second argument
%
%   index.any = 0
%   index.bear= 5
%   index.belt= 0
%

% Check input parameters
if nargin < 3| nargin > 4
    error ('check number of arguments')
end
if ~iscellstr(qualifier)|~isnumeric(takes_value)|length(qualifier)~=length(takes_value)
    error ('check qualifier and/or takes_value')
end
if nargin==3    % nstart not present
    n = 1;
else
    if length(arglist)<nstart|nstart<1
        error ('check arglist and/or nstart')
    end
    n = nstart;
end
nmax = length(arglist);

% Initialise output parameters
par_posn = zeros(1,length(arglist));
found=zeros(1,length(qualifier));
value_posn=zeros(1,length(qualifier));

parameter = zeros(1,0);
for i=1:length(qualifier)
    present.(qualifier{i})=0;
    index.(qualifier{i})=0;
end
message='';

% Return if no arguments
if nmax==0   % no qualifiers can be present
    return
end

% Parse the arguments if there are some present:
if n>1
    par_posn(1:n-1)=linspace(1,n-1,n-1);
end
skip = 0;
for i=n:nmax
    if skip~=1
        if ischar(arglist{i})
            j = string_find (arglist{i}, qualifier);
            if j>0
                if found(j)
                    message = ['ERROR: Qualifier "',arglist{i},'" appears more than once'];
                    break
                else
                    found(j) = 1;
                end
                if round(takes_value(j))~=0
                    if i==nmax  % no further parameters
                        message = ['ERROR: No parameter given to qualifier "',arglist{i},'"'];
                        break
                    else
                        value_posn(j) = i+1;
                        skip = 1;
                    end
                else
                    skip = 0;
                end
            elseif j<0
                message = ['ERROR: Ambiguous qualifier "',arglist{i},'" in argument list'];
                break
            else
                message = ['ERROR: Unrecognised qualifier "',arglist{i},'"'];
                break
            end
        else
            par_posn(i)=i;
        end
    else
        skip=0;
    end
end

if isempty(message)
    parameter = par_posn(par_posn>0);
    for i=1:length(qualifier)
        present.(qualifier{i})=found(i);
        index.(qualifier{i})=value_posn(i);
    end
end