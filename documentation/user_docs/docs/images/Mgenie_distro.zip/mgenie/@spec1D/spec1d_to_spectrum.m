function w=spec1d_to_spectrum(s)
% Convert spec1d object to spectrum object. Takes array input of spec1d too.
%
% Syntax:
%   >> w = spec1d_to_spectrum (s)

% T.G.Perring 10 May 2007
for i=1:length(s)
    ss=get(s(i));
    if isempty(ss.datafile); ss.datafile=''; end    % in case created from combine function
    if i==1
        w=spectrum(ss.x,ss.y,ss.e,ss.datafile,ss.x_label,ss.y_label);
        w=repmat(w,size(s));
    else
        w(i)=spectrum(ss.x,ss.y,ss.e,ss.datafile,ss.x_label,ss.y_label);
    end
end
    
    