function val = get(w,varargin)
% Get one or more fields from a spec1d object and put in a structure
%
% Syntax:
%   >> val = get (w, 'x')               Gets x array
%   >> val = get (w, 'x_label', 'x')    Gets x label and x array. Output is a structure
%   >> val = get (w)        Gets a structure containing all fields of spec1d object w
%
% T.G.Perring 10 May 2007

% if a single input argument, return whole structure:

if nargin==1
    val=struct(w);
else
    fnames=fieldnames(w);
    wcell=struct2cell(w);
    for i=1:length(varargin)
        if ischar(varargin{i}) && size(varargin{i},1)==1
            icell=strmatch(varargin{i},fnames,'exact');
            if ~isempty(icell)
                val.(fnames{icell})=wcell{icell};
            else
                disp(['Unrecognised field ',varargin{i}])
            end
        else
            disp('Requested fields must all be character strings')
        end
    end
end
        