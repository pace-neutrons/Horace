function mess = clear_globalpath (name)
% CLEAR_GLOBALPATH    Delete the named global user path
%
% Syntax:
%   >> clear_globalpath (name)   % name is a character string containing
%                                % the name of the global user path

if nargout==1; fail_on_error=0; else; fail_on_error=1; end
mess='';

% check name of global user path
if nargin < 1
    mess = 'ERROR: Must give name of global user path that is to be displayed';
    if fail_on_error; error(mess); else; return; end
end

if nargin >= 1
    if ischar(name) & length(name)>0 & size(name,1)==1
        if isvarname(name)
            path = get_global(name);
            if isa(path,'userpath')
                eval(['clear global ',name])
            else
                mess = ['ERROR: Global user path ''',name,''' does not exist.'];
                if fail_on_error; error(mess); else; return; end
            end
        else
            mess = ['ERROR: Invalid name for a global user path: ''',name,''''];
            if fail_on_error; error(mess); else; return; end
        end
    else
        mess = 'ERROR: Invalid argument type for a global user path name';
        if fail_on_error; error(mess); else; return; end
    end
end
