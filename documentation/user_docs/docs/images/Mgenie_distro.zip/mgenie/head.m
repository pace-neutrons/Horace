function [] = head (irun_lo_in, irun_hi_in)
%HEAD   Header information for run
%
%   >> head                 % header info for currently assigned data source
%   >> head irun            % For given run number
%   >> head irun_lo irun_hi % For given run number range
%

% Determine range of run numbers for which to printing headers
if nargin >= 1
    try
        irun_lo = evalin('caller',irun_lo_in);
    catch
        irun_lo = irun_lo_in;
    end
end

if nargin == 2
    try
        irun_hi = evalin('caller',irun_hi_in);
    catch
        irun_hi = irun_hi_in;
    end
end

% Print header(s)
if nargin==0
    head_listing
elseif nargin==1
    ass irun_lo;
    head_listing
elseif nargin==2
    for irun=irun_lo:irun_hi
        ass irun;
        head_listing
    end
end

%------------------------------------------------
function head_listing
hdr = genie_get('hdr');
user= genie_get('user');
titl= genie_get('titl');
crpb= genie_get('crpb');
line1 = ['Run ID : ' hdr(1:8) '        User: ' hdr(9:28) '  Inst: ' user{5}];
line2 = ['Protons: ' hdr(73:80) ' uAhrs  Date: ' hdr(53:72) ' to ' crpb{17} ' ' crpb{20}];
disp(line1)
disp(line2)
disp(titl(1:80))