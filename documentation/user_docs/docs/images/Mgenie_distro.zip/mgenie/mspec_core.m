function warr = mspec_core (ns, s, msk, av_mode)
% Core function used to create array of tofspectra from spectrum-to-workspace mapping, with a mask file
%   >> warr = mspec (ns, s [,msk] [,av_mode])
%
%   ns = array of number of spectra in each workspace (before any masking)
%        (note: elements of ns can be equal to zero)
%   s  = array containing list of spectra in order of increasing workspace number
%        (note: sum of elements of ns must be equal to the length of s)
%   msk= array of spectra to be masked
%
%   av_mode = averaging scheme (default is 'average')
%               = 'average'         take the average for all spectra in a group
%               = 'min_twotheta'    take parameters from the detector element with minimum twotheta
%               = 'max_twotheta'    take parameters from the detector element with minimum twotheta
%               = 'none'            dummy call - no parameters calculated, and w is returned as a double
%                                   with value zero.

% t0=0;
% tic

global genie_handle
global genie_efix genie_x1 genie_emode
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end
efix = genie_efix;
x1 = genie_x1;
emode = genie_emode;

% -----------------------------------------------------------------------------------------------
% Read workspace-spectrum mapping  and prepare lists of spectra, workspaces for reading in data
% -----------------------------------------------------------------------------------------------
ntc = double(genie_get('ntc1'));
nsp = double(genie_get('nsp1'));
nper= double(genie_get('nper'));
nsptot = nper*(nsp+1) - 1;    % maximum spectrum number in a multi-period run

% Determine control parameters
% -------------------------------
%   - max number of spectra to read in a single block
%   - the threshold number of adjacent masked spectra that determines a new block of spectra is to be read
%   - small number to use to avoid rounding errors
t_block     = 1e4;          % overhead time (microseconds) for a single call to genie_get('cnt[i:j]')
t_datapoint = 0.2;          % time (microseconds) to read a single data point in genie_get('cnt[i:j]')
max_points  = 1048576;      % buffer size od data points
max_sp = max(1,floor(max_points/ntc));
max_msk= max(1,floor((max_sp*t_block)/(t_datapoint*max_points)));
max_sp = max(1,2^round(log2(max_sp)));  % round max_sp to nearest power of two
del_sp = 0.01/max_sp;                   % used to avoid any rounding errors from double precision arithmetic (may not be necessary)

% disp(['         Max. spectra in a block: ',num2str(max_sp)])
% disp(['Unused spectra break block limit: ',num2str(max_msk)])


% Check input data have correct type and dimensions
% ----------------------------------------------------
if ~(length(size(ns))==2 & min(size(ns))==1)
    error ('No. spectra in each workspace must be 1D array')
end

if ~(length(size(s))==2 & min(size(s))==1)
    error ('List of spectra in workspaces must be 1D array')
end

if length(s)~=sum(ns)
    error ('Sum of spectra per workspace and spectrum list inconsistent in mapping information')
end

if ~isempty(msk)
    if ~(length(size(msk))==2 & min(size(msk))==1)
        error ('List of masked spectra must be 1D array')
    end
end

% Sort the spectra into increasing spectrum number, and check validity of elements

[sp,iarr]=sort(s);
if sp(1)<0 | sp(end)>nsptot
    error (['Spectrum numbers in mapping must lie between 0 and ',num2str(nsptot)])
end
if min(sp(2:end)-sp(1:end-1))==0
    error ('A spectrum must appear in only once')
end

% Create array of indices to workspaces corresponding to the sorted spectrum list
nw = length(ns);
w=ones(1,length(s));
nscum=cumsum(ns);
if (nw>1)
    for i=2:nw
        w(nscum(i-1)+1:nscum(i))=i;
    end
end
w = w(iarr);

% Create array of masked spectra, containing only unique entries
if ~isempty(msk)
    msk_sort = sort(msk);
    ilo = lower_index(msk_sort,sp(1));   % get range of indices that correspond to the spectra in the map file
    ihi = upper_index(msk_sort,sp(end));
    if ihi==ilo                     % single spectrum is masked
        msk_short = msk_sort(ihi);
    elseif ihi > ilo
        msk_work = msk_sort(ilo:ihi);
        del = [1,msk_work(2:end)-msk_work(1:end-1)];   % non-zero elements of del give unique mask entries
        msk_short = msk_work(del>0);
    else
        msk_short = [];
    end
else
    msk_short = [];
end

% Combine information from mapping file and mask file to get a list of spectra that must be read
%   [fortran-style loop would probably be faster in a high level language, but very slow in old versions of MATLAB]
if ~isempty(msk_short)
    sp2w = zeros(1,sp(end)-sp(1)+1);    % mask array, whose non-zero elements will be spectra to keep (offset by sp(1)-1)
    sp2w(sp-(sp(1)-1))=w;               % indicate which spectra to keep (offset by sp(1)-1), by giving their workspace number
    sp2w(msk_short-(sp(1)-1))=0;        % remove those that are masked
    sp_msk = find(sp2w>0)+(sp(1)-1);        % update this list of spectrum numbers that must be read
    w_msk = sp2w(sp2w>0);                   % and the corresponding workspace numbers
    if ~(length(sp_msk)>0)      % no spectra left after masking
        error ('All spectra in the spectrum-to-workspace mapping are masked')
    end
    % Get the number of spectra in the workspaces now that masked spectra have been removed
    ns_msk = zeros(1,nw);
    wsort = sort(w_msk);
    iwsort = find([1,diff(wsort)]>0);           % indices of first occurence in wsort of each workspace number
    ns_msk(wsort(iwsort))=diff([iwsort,length(w_msk)+1]);  % number of spectra in each workspace after masking
else
    sp_msk = sp;
    w_msk  = w;
    ns_msk = ns;
end

% Get lower and upper limits for reading blocks of spectra
if length(sp_msk)~=1    % more than one spectrum
    % find spectrum indices after which there is a break of more than max_msk spectra; prepend 0 for convenience later on
    brk = [0,find(diff(sp_msk)>max_msk), length(sp_msk)];
    temp = zeros(1,length(sp_msk));
    % create a logical array containing indices of spectra that form end of a block to be read
    % blocks will terminate at positions of breaks determined above
    for ib=1:length(brk)-1
        temp(brk(ib)+1:brk(ib+1)) = [diff(floor((sp_msk(brk(ib)+1:brk(ib+1))-sp_msk(brk(ib)+1)+del_sp)./max_sp)),1];
    end
    % create arrays of lower and upper bounds of the blocks of spectra
    is_lo = find([1,temp(1:end-1)]>0);   % index of lower bounds in the array sp_msk
    is_hi = find(temp>0);
    sp_lo = sp_msk(is_lo);                   % actual spectrum numbers of lower bounds
    sp_hi = sp_msk(is_hi);
else
    is_lo = 1;
    is_hi = 1;
    sp_lo = sp_msk;
    sp_hi = sp_msk;
end

% t=toc;
% disp(['time preparing mapping information: ',num2str(t-t0)])
% t0=t;


% ---------------------------------------------------------------------------------------
% Get detector information, appending NaN information for spectrum zero
% ---------------------------------------------------------------------------------------
% Note: min_twotheta, max_twotheta can cause unusual effects: currently the min or max functions
% are used. If there are more than one element with the mionimum value, then only the index of the
% first encountered is returned, not all of the indexes. This means that e.g. the azimuthal angle
% will not be averaged over all detectors with the minimum twotheta. We would prefer that it was,
% however.

% Get the averaging mode
iav_average = 1;
iav_min_twotheta = 2;
iav_max_twotheta = 3;
iav_none = 4;
iav_default = iav_average;
if nargin==4
    if ischar(av_mode)
        average_mode = lower(av_mode);
        if ~strcmp(average_mode,'')
            iav = string_find (average_mode, {'average','min_twotheta','max_twotheta','none'});
            if iav <= 0
                if iav <0
                    disp ('Ambiguous detector parameter averaging mode - chose to average')
                else
                    disp ('Unrecognised detector parameter averaging mode - chose to average')
                end
                iav = iav_default;  %make the default 'average'
            end
        else
            iav = iav_default;
        end
    else
        iav = iav_default;
    end
else
    iav = iav_default;
end

% Get the detector information from the raw file
if iav ~= iav_none
    s_raw=double(gget('spec'));            % spectrum numbers corresponding to the detector index numbers
    [delta_raw, twotheta_raw, azimuth_raw, x2_raw] = get_secondary;
    % Create an array of workspace numbers for each detector. Note that the instrument tables may not have
    % entries for all spectra, and may have entries for spectrum zero.
    [sp_raw,iarr]=sort(s_raw);  % sort detector information arrays in order of spectrum number
    jump = diff(sp_raw);        % indices of spectra after which there is an increase in spectrum number
    isp_lo = zeros(1,nsp);
    isp_hi = zeros(1,nsp);
        
    if sp_raw(1)==0             % some detectors are mapped to spectrum zero
        sp_distinct = sp_raw([0,jump]>0);               % distinct spectrum numbers in range 1 - nsp
        isp_lo(sp_distinct) = find([0,jump]>0);         % find indices of first occurrence of each spectrum number
        temp = find([jump,1]>0);
        isp_hi(sp_distinct) = temp(2:end);              % last occurrence
    else
        sp_distinct = sp_raw([1,jump]>0);               % distinct spectrum numbers in range 1 - nsp
        isp_lo(sp_distinct) = find([1,jump]>0);         % find indices of first occurrence of each spectrum number
        isp_hi(sp_distinct) = find([jump,1]>0);         % last occurrence
    end
    nd = isp_hi-isp_lo+1;

    delta=delta_raw(iarr);
    x2=x2_raw(iarr);
    twotheta=twotheta_raw(iarr);
    azimuth=azimuth_raw(iarr);

    delta_av = zeros(1,nsp+1);          % the last entry is information for spectrum zero
    x2_av = zeros(1,nsp+1);
    twotheta_av = zeros(1,nsp+1);
    azimuth_av = zeros(1,nsp+1);
    delta_av(end) = NaN;                % Spectrum zero information is NaN
    x2_av(end) = NaN;
    twotheta_av(end) = NaN;
    azimuth_av(end) = NaN;
end

% Get effective detector parameters only for those spectra that are used in the mapping file
% [We include those that are masked out, because we want to calculate the effective detector
% parameters for workspaces with no spectra left after masking]

% Create look-up for spectrum numbers into detector parameter arrays:
sp_norm = round(rem(sp+del_sp,nsp+1));  % spectrum number in the period
sp_norm_sort = sort(sp_norm);
jump = diff(sp_norm_sort);
if sp_norm_sort(1)==0                           % some workspaces contain spectrum zero (or equivalent in other periods)
    sp_distinct = sp_norm_sort([0,jump]>0);     % distinct spectrum numbers in range 1 - nsp
else
    sp_distinct = sp_norm_sort([1,jump]>0);     % distinct spectrum numbers in range 1 - nsp
end
sp_norm(sp_norm==0) = nsp+1;    % convention is that last entry of detector parameter arrays contains information for spectrum zero

% Look-up for unmasked spectrum numbers into detector parameter arrays:
sp_msk_norm = round(rem(sp_msk+del_sp,nsp+1));   % spectrum number in the period
sp_msk_norm(sp_msk_norm==0) = nsp+1;    % convention is that last entry of detector parameter arrays contains information for spectrum zero

if iav==iav_average
    for i=sp_norm(sp_norm>0)
        twotheta_av(i) = sum(twotheta(isp_lo(i):isp_hi(i)))/nd(i);
        azimuth_av(i) = sum(azimuth(isp_lo(i):isp_hi(i)))/nd(i);
        delta_av(i) = sum(delta(isp_lo(i):isp_hi(i)))/nd(i);
        x2_av(i) = sum(x2(isp_lo(i):isp_hi(i)))/nd(i);
    end
elseif iav==iav_min_twotheta
    for i=sp_norm(sp_norm>0)
        [twotheta_av(i),j]=min(twotheta(isp_lo(i):isp_hi(i)));
        azimuth_av(i) = azimuth(isp_lo(i)+j-1);
        delta_av(i) = delta(isp_lo(i)+j-1);
        x2_av(i) = x2(isp_lo(i)+j-1);
    end
elseif iav==iav_max_twotheta
    for i=sp_norm(sp_norm>0)
        [twotheta_av(i),j]=max(twotheta(isp_lo(i):isp_hi(i)));
        azimuth_av(i) = azimuth(isp_lo(i)+j-1);
        delta_av(i) = delta(isp_lo(i)+j-1);
        x2_av(i) = x2(isp_lo(i)+j-1);
    end
elseif iav~=iav_none
    error ('Unrecognised averaging mode')
end


% t=toc;
% disp(['      time preparing detector info: ',num2str(t-t0)])
% t0=t;


% -----------------------------------------------------------------------------------------------------------------------
% Read in blocks of spectra, accumulate sums for the workspaces and calculate detector parameters for the workspaces
% -----------------------------------------------------------------------------------------------------------------------

% Read in the counts
% -------------------------
wcnt = zeros(ntc,nw);                       % array in which to accumulate counts for the workspaces
cnt  = zeros(ntc,max(sp_hi-sp_lo)+1);       % array to hold raw counts (declare now to avoid repeated allocation/deallocation)
for i=1:length(sp_lo)
    ilo_char=sprintf('%.0f',round(sp_lo(i)));
    ihi_char=sprintf('%.0f',round(sp_hi(i)));
    cmd = strcat('cnt1[',ilo_char,':',ihi_char,']');
    cnt = double(genie_get(cmd));
    for j=is_lo(i):is_hi(i) % loop over indices of spectra to be read. Must be a loop, as more than one spectrum may go into one workspace
        wcnt(:,w_msk(j)) = wcnt(:,w_msk(j)) + cnt(2:ntc+1,sp_msk(j)-(sp_msk(is_lo(i))-1));
    end
end

% t=toc;
% disp(['                 time reading data: ',num2str(t-t0)])
% t0=t;



% Get average detector parameters
% ---------------------------------------
% For future change: if perform units conversion on individual spectra before adding to the workspaces,
% then the detector information needs to be extracted for each block of raw counts as they are read.

% Get parameters for workspaces keeping only masked spectra:
if iav==iav_average
    delta_msk= zeros(1,nw);
    x2_msk   = zeros(1,nw);
    twotheta_msk = zeros(1,nw);
    azimuth_msk = zeros(1,nw);
    for j=1:length(w_msk)   % loop over all spectra
        twotheta_msk(w_msk(j)) = twotheta_msk(w_msk(j)) + twotheta_av(sp_msk_norm(j));
        azimuth_msk(w_msk(j)) = azimuth_msk(w_msk(j)) + azimuth_av(sp_msk_norm(j));
        delta_msk(w_msk(j)) = delta_msk(w_msk(j)) + delta_av(sp_msk_norm(j));
        x2_msk(w_msk(j)) = x2_msk(w_msk(j)) + x2_av(sp_msk_norm(j));
    end
    twotheta_msk(ns_msk>0) = twotheta_msk(ns_msk>0)./ns_msk(ns_msk>0);
    azimuth_msk(ns_msk>0) = azimuth_msk(ns_msk>0)./ns_msk(ns_msk>0);
    delta_msk(ns_msk>0) = delta_msk(ns_msk>0)./ns_msk(ns_msk>0);
    x2_msk(ns_msk>0) = x2_msk(ns_msk>0)./ns_msk(ns_msk>0);
elseif iav==iav_min_twotheta
    delta_msk= nan.*zeros(1,nw);
    x2_msk   = nan.*zeros(1,nw);
    twotheta_msk = nan.*zeros(1,nw);
    azimuth_msk = nan.*zeros(1,nw);
    for j=1:length(w_msk)   % loop over all spectra
        [twotheta_msk(w_msk(j)),k] = min([twotheta_msk(w_msk(j)),twotheta_av(sp_msk_norm(j))]); % use min(a,nan)=max(a,nan)=a for a~=nan
        if k==2
            azimuth_msk(w_msk(j)) = azimuth_av(sp_msk_norm(j));
            delta_msk(w_msk(j)) = delta_av(sp_msk_norm(j));
            x2_msk(w_msk(j)) = x2_av(sp_msk_norm(j));
        end
   end
elseif iav==iav_max_twotheta
    delta_msk= nan.*zeros(1,nw);
    x2_msk   = nan.*zeros(1,nw);
    twotheta_msk = nan.*zeros(1,nw);
    azimuth_msk = nan.*zeros(1,nw);
    for j=1:length(w_msk)   % loop over all spectra
        [twotheta_msk(w_msk(j)),k] = max([twotheta_msk(w_msk(j)),twotheta_av(sp_msk_norm(j))]); % use min(a,nan)=max(a,nan)=a for a~=nan
        if k==2
            azimuth_msk(w_msk(j)) = azimuth_av(sp_msk_norm(j));
            delta_msk(w_msk(j)) = delta_av(sp_msk_norm(j));
            x2_msk(w_msk(j)) = x2_av(sp_msk_norm(j));
        end
    end
else        % iav = iav_none; follow convention that parameters contain NaN
    delta_msk= nan.*zeros(1,nw);        
    x2_msk   = nan.*zeros(1,nw);
    twotheta_msk = nan.*zeros(1,nw);
    azimuth_msk = nan.*zeros(1,nw);
end

% Get parameters for workspaces keeping all spectra:
if iav==iav_average
    delta= zeros(1,nw);
    x2   = zeros(1,nw);
    twotheta = zeros(1,nw);
    azimuth = zeros(1,nw);
    for j=1:length(w)   % loop over all spectra
        twotheta(w(j)) = twotheta(w(j)) + twotheta_av(sp_norm(j));
        azimuth(w(j)) = azimuth(w(j)) + azimuth_av(sp_norm(j));
        delta(w(j)) = delta(w(j)) + delta_av(sp_norm(j));
        x2(w(j)) = x2(w(j)) + x2_av(sp_norm(j));
    end
    azimuth(ns>0) = azimuth(ns>0)./ns(ns>0);
    twotheta(ns>0) = twotheta(ns>0)./ns(ns>0);
    delta(ns>0) = delta(ns>0)./ns(ns>0);
    x2(ns>0) = x2(ns>0)./ns(ns>0);
elseif iav==iav_min_twotheta
    delta= nan.*zeros(1,nw);
    x2   = nan.*zeros(1,nw);
    twotheta = nan.*zeros(1,nw);
    azimuth = nan.*zeros(1,nw);
    for j=1:length(w)   % loop over all spectra
        [twotheta(w(j)),k] = min([twotheta(w(j)),twotheta_av(sp_norm(j))]); % use min(a,nan)=max(a,nan)=a for a~=nan
        if k==2
            azimuth(w(j)) = azimuth_av(sp_norm(j));
            delta(w(j)) = delta_av(sp_norm(j));
            x2(w(j)) = x2_av(sp_norm(j));
        end
   end
elseif iav==iav_max_twotheta
    delta= nan.*zeros(1,nw);
    x2   = nan.*zeros(1,nw);
    twotheta = nan.*zeros(1,nw);
    azimuth = nan.*zeros(1,nw);
    for j=1:length(w)   % loop over all spectra
        [twotheta(w(j)),k] = max([twotheta(w(j)),twotheta_av(sp_norm(j))]); % use min(a,nan)=max(a,nan)=a for a~=nan
        if k==2
            azimuth(w(j)) = azimuth_av(sp_norm(j));
            delta(w(j)) = delta_av(sp_norm(j));
            x2(w(j)) = x2_av(sp_norm(j));
        end
    end
else        % iav = iav_none; follow convention that parameters contain NaN
    delta= nan.*zeros(1,nw);        
    x2   = nan.*zeros(1,nw);
    twotheta = nan.*zeros(1,nw);
    azimuth = nan.*zeros(1,nw);
end


% t=toc;
% disp(['  time calculating det. parameters: ',num2str(t-t0)])
% t0=t;


% Fill up array of output workspaces as tofspectrum object:
% -------------------------------------------------------------

tcb = gget('tchan1');
conv = 1./diff(tcb); % inverse of time channels (so multiply later on, not divide)

% Fill output array with first workspace:
wx = gget('tchan1');
wy = wcnt(:,1)'.*conv;
we = sqrt(wcnt(:,1))'.*conv;
wtitle = avoidtex(genie_get);  % inquire about genie source
[xlab,xunit] = units_to_caption ('t',0); % get captions for time-of-flight
wxlab = xlab;
wylab = 'Counts';
wxunit= xunit;
wdistribution = 1;
wsp = spectrum(wx,wy,we,wtitle,wxlab,wylab,wxunit,wdistribution);

if ns_msk(1) > 0
    par = tofpar(emode,delta_msk(1),x1,x2_msk(1),twotheta_msk(1),azimuth_msk(1),efix);
else
    par = tofpar(emode,delta(1),x1,x2(1),twotheta(1),azimuth(1),efix);
end
wref = tofspectrum(wsp,par,'t');
if (nw>1)
    warr = repmat(wref,1,nw); % repeat workspace to preallocate (and therefore save CPU time)
else
    warr = wref;
    return
end

% Fill up remaining workspaces
for iw=2:nw
    wy = wcnt(:,iw)'.*conv;
    we = sqrt(wcnt(:,iw))'.*conv;
    if ns_msk(iw) > 0
        warr(iw) = set_special (warr(iw), wy', we', delta_msk(iw), x2_msk(iw), twotheta_msk(iw), azimuth_msk(iw));
    else
        warr(iw) = set_special (warr(iw), wy', we', delta(iw), x2(iw), twotheta(iw), azimuth(iw));
    end
end


% t=toc;
% disp(['             time creating spectra: ',num2str(t-t0)])
% t0=t;
% 
% 
% t=toc;
% disp('------------------------------------------------------------------')
% disp(['                        total time: ',num2str(t)])
% disp('------------------------------------------------------------------')
