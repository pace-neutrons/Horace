function w = read_asc (file)
% READ_ASC Reads x,y,e arrays of bin boundaries, y, errors on y, from the output
% of binary to .asc conversion of MODES program in use on OSIRIS
%
% Syntax:
%   >> w = read_hist (file)    % read from named file
%   >> w = read_hist           % prompts for file
%

% *** I assume that the data is histogram

% Get file name - prompt if file does not exist (using file to set default seach location and extension)
% ------------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.asc');
end
if (isempty(file_internal))
    error ('No file given')
end

% Read data
% -----------
fid = fopen(file_internal);
tline = fgets(fid);
title = fgets(fid);
tline = fgets(fid);
tline = fgets(fid);
a = fscanf(fid,'%g %g %g',[3,inf]);
fclose(fid);

% Put data in a spectrum (histogram mode assumed)
% ----------------------
nx = size(a,2);
w.x=a(1,1:nx-1);    % the last data point seems to be rubbish
w.y=a(2,1:nx-2);    % we are assuming histogram data
w.e=a(3,1:nx-2);
title = fliplr(deblank(fliplr(deblank(title))));  % in matlab 7 can use strtrim
w.title={avoidtex(file_internal) avoidtex(title)};
w.xlab = 'x axis';
w.ylab = 'intensity';
w.xunit= 'xunit';
w.distribution=1;

w = spectrum(w);

disp (['Data read from ' file_internal])
