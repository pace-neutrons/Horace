function w = binary_op_template (w1, w2)
%

% Template of a binary operator that can take array-valued arguments

len1 = length(w1);
len2 = length(w2);
if (len1==len2 & len1==1)
    w = binary_op (w1, w2);
elseif (len1==len2 & len1>1)
    w = top_class;
    w = repmat(w,1,len1);   % create empty output array
    for i=1:len1
       w(i) = binary_op (w1(i),w2(i));
    end
elseif (len1==1 & len2>1)
    w = top_class;
    w = repmat(w,1,len2);   % create empty output array
    for i=1:len2
        w(i) = binary_op (w1,w2(i));
    end
elseif (len1>1 & len2==1)
    w = top_class;
    w = repmat(w,1,len1);   % create empty output array
    for i=1:len1
        w(i) = binary_op (w1(i),w2);
    end
else
    error ('Check lengths of array(s) of input arguments')
end
return
  
