function wint = dintegrate (w, xlo, xhi)
% Performs an integral of an array of spectra created with the DSCAN_ANAL
% or DSPACE_MAPS functions. The x-axis of the resulting spectrum is set as
% the scan parameter / scattering angle.[The standard mgenie function
% integrate will plot with the x-axis as the workspace index, not scan
% parameter / scattering angle]. 
%
% Syntax:
%   >> wout = dintegrate (w, dlo, dhi)

% Get integral:
if nargin==1
    wint = integrate (w);
elseif nargin==3
    wint = integrate (w, xlo, xhi);
end


% Get title for the y axis:
temp = get(get(w(1),'spectrum'));
if isempty(temp.title)
    str='';
elseif isa(temp.title,'cell')
    lt = length(temp.title);
    str = char(temp.title{lt});
elseif isa(temp.title,'char')
    str = temp.title;
else
    display ('Something screwy with titles')
    str = ''
end

if (~isempty(str))
    k = findstr(str,'Scan:');
    if (~isempty(k))
        str=str(k+5:end);
    else
        str='';
    end
end
str=fliplr(deblank(fliplr(deblank(str))));  % in matlab 7 can use strtrim
if (~isempty(str))
    ylab = str;
else
    ylab = 'Scan parameter value'
end


% *** AN AWFUL, AWFUL FIX-UP UNTIL ADD AN EXTRA PARAMETER TO HOLD MPLOT Y VALUES ***
% use efix to hold the dplot y-axis and dintegrate x-axis values
lw = length(w);
if (lw>1)
    ang = zeros(1,lw);
    for i=1:lw
        ang(i) = get(get(w(i),'tofpar'),'efix');
    end
    wint = set(wint,'x',ang,'xlab',ylab);
else
    return   % not an array of tof spectra
end
