function w = genie_get (nam)
% GENIE_GET  Get named variable from ISIS raw file. This should be the only gateway to retrieve data values
%
global genie_handle

% Check that opengenie is available
if isempty(genie_handle); 
    error('Command cannot be completed because OpenGenie not found')
end

if (nargin==0)  % enquire about source being used by genie
    command_line=strcat('w <~ cfn()');
    invoke(genie_handle,'AssignHandle',command_line,'');
    w = invoke(genie_handle, 'GetValue', 'w');
    invoke(genie_handle,'AssignHandle','free "w"','');   % clear w immediately to reduce memory costs
    return
end

if (nargin ==1) % get data from default source
    command_line=strcat('w <~ get("',nam,'")');          % w <~ get(...) avoids a double copy
    invoke(genie_handle,'AssignHandle',command_line,'');
    w = invoke(genie_handle, 'GetValue', 'w');           % works with character arrays too
    invoke(genie_handle,'AssignHandle','free "w"','');   % clear w immediately to reduce memory costs
    return
end

if (nargin >1)
    error ('Wrong number of arguments to GENIE_GET')
end



