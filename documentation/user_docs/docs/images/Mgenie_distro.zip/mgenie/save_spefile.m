function save_spefile(data,file)
% Writes an .SPE file 
%
% Syntax:
%   >> write_spefile (data)           % prompts for file to write to
%   >> write_spefile (data, file)     % write to named file
%
% data has following fields:
%   data.S          Data array:
%                    - [ne x ndet] array of signal values
%                 OR - cell array of ndet arrays, each with ne values
%                     (i.e. each element corresponds to one detector)
%
%   data.ERR        Error values (st. dev.):
%                    - [ne x ndet] array of signal values
%                 OR - cell array of ndet arrays, each with ne values
%                     (i.e. each element corresponds to one detector)
%
%   data.en         Vector of energy bins:
%                    - if length(data.en)=ne+1 then interpreted as bin boundaries
%                    - if length(data.en)=ne then interpreted as bin centres
%
% and optionaly can include the (redundant) phi grid:
%   data.phi        Vector of scattering angles
%                    - if length(data.phi) = ndet, appends a zero to the end
%                     (the assumption is that the values are the centres, and want to store in the spe file)
%                    - if length(data.phi) = ndet+1, writes the array
%                     (the assumption is that it is a true grid)

% T.G.Perring 2 Jan 2008 - based on write_spefile, in turn based on R.Coldea's save_spe

null_data = -1.0e30;    % conventional NaN in spe files
small_data = 1.0e-30;
big_data = 1.0e30;

% Check input data
% ----------------
if length(size(data.S))>2 || length(size(data.S))~=length(size(data.ERR)) || any(size(data.S)~=size(data.ERR))
    error('Check sizes of signal and error arrays')
end
ne   = size(data.S,1);
ndet = size(data.S,2);

if ~(numel(data.en)==ne+1||numel(data.en)==ne)
    error('Number of energy values inconsistent with size of data arrays')
end

if isfield(data,'phi') && ~(numel(data.phi)==ndet+1||numel(data.phi)==ndet)
    error('Number of phi values inconsistent with size of data arrays')
end

% Get file name - prompting if necessary
% --------------------------------------
if (nargin==1)
    file_internal = genie_putfile('*.spe');
    if (isempty(file_internal))
        error ('No file given')
    end
elseif (nargin==2)
    file_internal = file;
end

fid = fopen (file_internal, 'wt');
if (fid < 0)
    error (['ERROR: cannot open file ' file_internal])
end


% Write spe file. Note that on PC systems, numbers are written with three digits in the exponent
% e.g. -1.234E+007. It turns out that with format %-10.4G that Matlab will always give 4 sig. fig.,
% so that the result is an 11 character string if exponent form is needed. This will cause the spe
% file read routines to break. This is why in the following there is a test for PC (windows) - see
% sprintf documentation
%
% Should rewrite as a mex file as all the string manipulations if a PC are time consuming

% === write ndet, ne
fprintf(fid,'%-8d %-8d \n',ndet,ne);    

% === write phi grid (normally unused)
if isfield(data,'phi')
    if numel(data.phi)==ndet
        phi_grid=[data.phi(:);0];
    else
        phi_grid=data.phi(:);
    end
else
    phi_grid=(1:(ndet+1))';
end

fprintf(fid,'%s\n','### Phi Grid');
fprintf(fid,'%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f\n',phi_grid(:));
if rem(ndet+1,8)~=0,
    fprintf(fid,'\n');
end

% === write energy grid
fprintf(fid,'%s\n','### Energy Grid');
if numel(data.en)==ne
    if ne~=1
        de=(data.en(end)-data.en(1))/(ne-1);
        en_grid=[data.en(:)-de/2;data.en(end)+de/2];
    else
        error('Centre of one energy bin given only; cannot generate bin boundaries')
    end
else
    en_grid=data.en(:);
end
en_grid=round(en_grid*1e5)/1e5;	%truncate at the 5th decimal point
fprintf(fid,'%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f%-10.4f\n',en_grid(:));
if rem(ne+1,8)~=0,
  	fprintf(fid,'\n');
end

% === write S(det,energy) and ERR(det,energy)
for i=1:ndet,
    fprintf(fid,'%s\n','### S(Phi,w)');
    if iscell(data.S); yarr=data.S{i}; else yarr=data.S(:,i); end;
    if iscell(data.ERR); earr=data.ERR{i}; else earr=data.ERR(:,i); end;
    % if contains any nans, then set entire array to null_data; else perform checks on sizes of array elements
    if any(isnan(yarr))||any(~isfinite(yarr))||any(isnan(earr))||any(~isfinite(earr))
        yarr=null_data*ones(size(yarr));
        earr=null_data*ones(size(earr));
    else
        yarr(yarr<null_data)=null_data;
        yarr(yarr>big_data)=big_data;
        yarr(abs(yarr)<small_data)=0;
        earr(earr>big_data)=big_data;
        earr(abs(earr)<small_data)=0;
    end
    if ispc
        for j=1:8:ne
            temp = sprintf('%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E',yarr(j:min(j+7,ne)));
            temp = strrep(strrep(temp, 'E+0', 'E+'), 'E-0', 'E-');
            fprintf(fid,'%s\n',temp);
        end
    else
        fprintf(fid,'%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G\n',yarr);
        if rem(ne,8)~=0,
            fprintf(fid,'\n');
        end
    end
    fprintf(fid,'%s\n','### Errors');
    if ispc
        for j=1:8:ne
            temp = sprintf('%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E%+11.3E',earr(j:min(j+7,ne)));
            temp = strrep(strrep(temp, 'E+0', 'E+'), 'E-0', 'E-');
            fprintf(fid,'%s\n',temp);
        end
    else
        fprintf(fid,'%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G%-10.4G\n',earr);
        if rem(ne,8)~=0,
            fprintf(fid,'\n');
        end
    end
end
fclose(fid);
