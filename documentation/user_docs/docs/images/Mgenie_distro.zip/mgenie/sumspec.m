function w = sumspec (isp_lo, isp_hi, t_lo, t_hi)
% SUMSPEC Creates a list of integrals for the spectra IS_LO to IS_HI for the time channels
%         fully contained in the time range T_LO to T_HI.
%
% Valid syntax:
%   w = sumspec(is_lo,is_hi)             Integrals over the full time range for sepctra IS_LO to IS_HI
%   w = sumspec(is_lo,is_hi,t_lo,t_hi)   Integrals over the full time range for sepctra IS_LO to IS_HI
%

% Check input arguments and get integration range.
title = avoidtex(genie_get);
xlab = 'Spectrum number';
xunit = '';
distribution = 0;

if (nargin==2 | nargin==4)
    nspec = double(genie_get('nper'))*(double(genie_get('nsp1'))+1) - 1;    % maximum spsectrum number in a multi-period run
    if (~isa(isp_lo,'double') | ~isa(isp_hi,'double') | round(isp_lo) < 0 | round(isp_hi) > nspec | isp_lo > isp_hi)
        error (['Ensure 0 =< ISP_LO =< ISP_HI =< ',num2str(nspec)])
    end
    if (nargin==2)  % integrate over all time channels
        tchan = gget('tchan1');
        jlo = 1;
        jhi = double(genie_get('ntc1'));
        tlo = tchan(jlo);
        thi = tchan(jhi+1);
    else
        if (isa(t_lo,'double') & isa(t_hi,'double') & t_lo <= t_hi)
            tchan = gget('tchan1');
            temp = find(tchan>=t_lo & tchan<=t_hi);
            if(size(temp,2)>=2)   % complete time channels in the given time range
                jlo = double(temp(1));
                jhi = double(temp(end)-1);
                tlo = tchan(jlo);
                thi = tchan(jhi+1);
            else
                w.x=linspace(isp_lo-0.5, isp_hi+0.5, isp_hi-isp_lo+2);
                w.y=zeros(1,isp_hi-isp_lo+1);
                w.e=zeros(1,isp_hi-isp_lo+1);
                ylab = 'Counts';
                w = spectrum(w.x,w.y,w.e,title,xlab,ylab,xunit,distribution);
                disp('WARNING: No whole time channels in indicated range. Spectrum of zeros returned.')
                return
            end
        else
            error ('Ensure T_LO =< T_HI')
        end
    end
else
    error ('Check number of arguments')
end

% Get integrals
% Split the spectrum gathering into manageable chunks: 512 spectra seems to bwork well on TGP's 2.4GHz 1GB PC.
del = 512;
%
ilo = isp_lo;
ihi = min(isp_hi,isp_lo+del-1);
nblock = floor((isp_hi-isp_lo)/del) + 1;
w.x = linspace(isp_lo-0.5, isp_hi+0.5, isp_hi-isp_lo+2);
w.y = zeros(1,isp_hi-isp_lo+1); % create empty array (more efficient than succesively extending during FOR loop below
for m=1:nblock
    ilo_char=sprintf('%.0f',round(ilo));
    ihi_char=sprintf('%.0f',round(ihi));
    cmd = strcat('cnt1[',ilo_char,':',ihi_char,']');
    cnt = genie_get(cmd);    % user the general GET routine
    w.y(ilo-isp_lo+1:ihi-isp_lo+1) = sum(double(cnt(jlo+1:jhi+1,:)),1);
    ilo = ilo + del;
    ihi = min(isp_hi,ihi+del);
end
w.e = sqrt(w.y);
tlo_char=sprintf('%.3f',tlo);
thi_char=sprintf('%.3f',thi);
ylab = ['Counts from ' tlo_char ' to ' thi_char '\mus'];
w = spectrum(w.x,w.y,w.e,title,xlab,ylab,xunit,distribution);