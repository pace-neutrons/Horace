function val = get_global (var_name)
% get_global: Get value of a GLOBAL variable with name given by the
%             Character string var_name. Return argument is empty if
%             the variable name does not exist, or the input argument is
%             not a valid name.
%
% Syntax:
%   >> value = get_global (var_name)
%
% e.g.
%   >> value = get_global ('map_path');
%
if isvarname(var_name)
    eval(['s=who(''',var_name,''',''global'');']);
    if ~isempty(s)
        eval(['global ',var_name]);
        val=eval(var_name);
    else
        val=[];
    end
else
    val = [];
end