function genie_init
%GENIE_INIT 
%  Set up global parameters for MGENIE and invoke OpenGenie
%
% Dont forget to propagate any changes to the global variable list to genie_off so that
% a clean 'uninstall' can be made

global genie_handle
global genie_binning
global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_efix genie_x1 genie_emode
global genie_setup_file
global genie_mgenie_initialised genie_opengenie_present

global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant



% disp('------------------------------------------------------------------')
% disp('  MGENIE - A collection of routines to mimic GENIE in Matlab')
% disp('     Please send any ideas or feedback to t.g.perring@rl.ac.uk')
% disp('------------------------------------------------------------------')


% initialise genie data location globals
genie_file = '';
genie_disk = '';
genie_directory  = '';
genie_instrument = '';
genie_run = 0;
genie_run_char = '';
genie_extension = '';
genie_dae = '';
genie_crpt = '';

% initialise binning, max no. plots in a cascade of 1D plots
genie_binning = 1;
genie_max_spectra_1d = 100;

% initialise graphics styles
genie_color{1} = 'k';
genie_line_style{1} = '-';
genie_line_width = 0.5;
genie_marker{1} = 'o';
genie_marker_size = 6;
genie_xscale = 'linear';
genie_yscale = 'linear';


% --------------------------------------------------------------------------------------------------------------
% initialise units conversion parameters:
genie_efix = 0;
genie_x1 = 0;
genie_emode = 0;

% --------------------------------------------------------------------------------------------------------------
% More specialised constants for analysis programs

% Monitor normalisation parameters: set some sensible values to prevent programs from falling over:
analysis_mon_norm   = 0;        % Default monitor for normalisation
analysis_mon_tlo    = 0;        % Lower time integration limit
analysis_mon_thi    = 0;        % Upper time integration limit
analysis_mon_norm_constant = 0; % Normalisation constant.
                                        % Data will be normalised by monitor counts in units of mon_norm_constant
                                        % i.e. data is divided by (integral/mon_norm_constant)
                                        
% --------------------------------------------------------------------------------------------------------------
% Invoke OpenGenie and initialise arrays with names of raw file fields for data access routines
if size(genie_mgenie_initialised)~=1 % haven't yet tried to invoke open genie
    genie_mgenie_initialised=1;
    try
        genie_handle = actxserver('OpenGENIE.Application'); % Get handle to open genie
        genie_opengenie_present = 1;
    catch
        genie_handle = [];
        genie_opengenie_present = 0;
    end
end
    
gget_init

% --------------------------------------------------------------------------------------------------------------
% Run setup file, if exists
if (~isempty(genie_setup_file))
    if (isa(genie_setup_file,'char') & size(genie_setup_file,1)==1)
        if (exist(genie_setup_file)==2)
            try
                if ~isempty(fileparts(genie_setup_file))    % contains a directory in the name
                    run (genie_setup_file);
                else
                    run(which(genie_setup_file));           % run the m file script
                end
            catch
                disp(['Warning: unable to run mgenie setup script in ',genie_setup_file])
            end
        else
            disp (['Warning: mgenie setup file ',genie_setup_file,' not found'])
        end
    else
        disp ('Warning: variable named "genie_setup_file" is not a single character string')
    end
end


                                        
