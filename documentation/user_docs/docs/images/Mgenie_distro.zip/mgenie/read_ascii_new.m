function [w, string] = read_ascii (read_type, source, terminator)
% Reads data from ascii file of one of several types of data.
%
% Syntax:
%   >> [w, string] = read_ascii (read_type, source, end_of_read)
%
% read_type
%   * 'field' - field/value pair: information that is read has form:
%           lhs_1 = rhs_1
%           lhs_2 = rhs_2
%             :       :
%       (lhs are valid field names; rhs are read as character strings)
%   * {lhs_1, lhs_2, ...} - array of particular field/value pairs that
%     appear in that named order
%   * 'numeric' - two dimensional numeric array of any size
%   * 'comment' - line beginning with '%' or '!'
%   * 'text' - any string that is not of the above type
%
% source
%   * file identifier of an open text file
%   * cell array of character strings
%
% terminator
%   Data of read_type will be read until a line of type terminator is
%  encountered (where terminator is one of the types described above).
%  Lines of any other type will be skipped over.
%

% Check nature of source
if ~isnumeric(source)    % not a fid
    if iscellstr(source)
        nline = length(source);
    elseif ischar(source)
        nline = size(source,1);

if isnumeric(source)
    string = fgetl(source);
else
    

    t=fgetl(fid);
    elseif iscellstr(fid)|ischar(fid)
        if iscellstr(fid)
            str_array = fid;
        else
            str_array = cellstr(fid);
        end
        if icount < length(str_array)
            icount = icount + 1;
            t = char(str_array(icount));
        else
            t = -1;
        end
    else
        t = -1;


if read_type=='field'




function w = analyse_ascii (string)
% analyse a string to determine if a numeric, comment, field or text string
%   w.numeric = row array containing values
%   w.comment = comment (trimmed)
%   w.field_name = field name
%   w.field_value = value of result (trimmed)
%   w.text = text (trimmed)

w.numeric=0; w.comment=0; w.field=0; w.text=0; w.value=''; w.field_name='';

% determine if a field string
pos=strfind(string,'=');
if ~isempty(pos)
    field=strtrim(string(1:pos(1)-1));
    if isvarname(field)
        w.field = 1;
        w.field_name = field;
        w.value = strtrim(string(pos(1)+1:end));
        return
    end
end

% determine if a comment string
string_trim = strtrim(string);

if (length(string_trim)>0 && (string_trim(1)=='%'||string_trim(1)=='!')) || length(string_trim)==0
    w.comment = 1;
    w.value = string_trim;
    return
end
    
% Determine if string is numeric (i.e. numbers only)
value = str2num(string_trim);
if length(value)>0
    w.numeric = 1;
    w.value = value;
    return
end

% Must be a text string if none of the above
w.text = 1;
w.value = string_trim;

