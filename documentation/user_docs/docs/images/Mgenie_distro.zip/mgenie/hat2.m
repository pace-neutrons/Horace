function y= hat2(w1, h1, w2, h2, x)

% function y=hat2(w1, h1, w2, h2, x)
% This function calculates the convolution of 2 hat functions centred 
% at 0 with widths w1, w2 and heights h1,h2, over a range given by x.

% Joost van Duijn: 29-08-03

if nargin<5,
    error('Insuficient number of paramters given');
end
if (w1<0)|(w2<0),
    error('Width of the 2 hat functions need to be positive');
end


% Irrespective of the input widths, the convolution will be calculated as
% that of of a broad top hat (width w, height p) with a narrow top hat
% (width delta, height q).
%
%             ____|____ delta*p*q
%            /    |    \
%           /     |    |\
% _________/______|____|_\___________ x
%                 0    |  w/2+delta/2
%                      w/2-delta/2
if w1>w2,
    w= w1;
    p= h1;
    delta= w2;
    q= h2;
elseif w1<w2,
    w= w2;
    p= h2;
    delta= w1;
    q= h1;
else
    w= w1;
    p= h1;
    delta= w2;
    q= h2;
end

x= abs(x);
y= zeros(size(x));

temp1= x<((w-delta)/2);
temp2= ((w-delta)/2)<=x&x<((w+delta)/2);

y(temp1)= delta*p*q;
y(temp2)= (delta*p*q)-(p*q*(x(temp2)-(w-delta)/2));
