function data1 = get_slice_diff(file1,file2,ebars)
% Take the difference between two slice files with control over how error bars are handled
%
%   >> data = get_slice_diff(file1,file2)
%   >> data = get_slice_diff(file1,file2,ebars)
%
%   file1   First slice file. All the titles, labels etc. taken from this file.
%   file2   Second slice file
%   ebars  (Optional) 1x2 array to indicate how to treat error bars
%          e.g. [1,0] means treat error bars of file2 as zeros
%           Default is [1,1] i.e. use error bars from both files
%
% Generalisation of get_slice

data1=get_slice(file1);
if isempty(data1),
    error(['Could not load .slc file ',file1]);
end

data2=get_slice(file2);
if isempty(data1),
    error(['Could not load .slc file ',file2]);
end

if ~exist('ebars','var')
    ebars=logical([1,1]);
elseif ~(isnumeric(ebars)||islogical(ebars)) || ~isvector(ebars) || length(ebars)~=2
    error('Check ebars option is vector length 2 containing only 0 or 1')
else
    ebars=logical(ebars);
end

% Check that the two files are commensurate
if ~(all(size(data1.xbounds)==size(data2.xbounds)) && all(data1.xbounds==data2.xbounds)) ||...
   ~(all(size(data1.ybounds)==size(data2.ybounds)) && all(data1.ybounds==data2.ybounds)) ||...
    ~all(size(data1.x)==size(data2.x)) || ~(all(size(data1.pixels)==size(data2.pixels)) && all(all(data1.pixels(:,1:5)==data2.pixels(:,1:5))))
    error('Slice files do not have same number of points and same contributing pixels')
end

% Take difference between the slice files, looking after error bars appropriately
data1.c=data1.c-data2.c;    
if all(ebars==[0,0])
    data1.e=zeros(size(data1.e));
elseif all(ebars==[0,1])
    data1.e=data2.e;
elseif all(ebars==[1,1])
    data1.e=sqrt(data1.e.^2+data2.e.^2);
end
