function [] = sh_ass ()
% SH_ASS  Shows the assignment
%
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt

if(isempty(genie_instrument) | isempty(genie_run_char) | isempty(genie_extension)) % print individual components if not of form IIInnnnn.eee
    disp('------------------------------------------------------------------')
    if (isempty(genie_disk) & isempty(genie_directory) )
        disp('  location :')
    else
        location = strcat([genie_disk genie_directory]);
        disp(strcat(['  location : ' location]))
    end
    disp(strcat(['instrument : ' genie_instrument]))
    if(isempty(genie_run_char))
        disp('       run :')
    else
        disp(strcat(['       run : ' num2str(round(genie_run))]))
    end
    disp(strcat([' extension : ' genie_extension]))
else
    istatus=exist(genie_file); % check if file exists
    if (istatus ~= 2)
        mess = strcat(['Input data file   ' genie_file '   does not exist']);
        error(mess,'_SHOW_ASS')
    else
        disp(strcat(['Data source: ' genie_file]))
    end
end
