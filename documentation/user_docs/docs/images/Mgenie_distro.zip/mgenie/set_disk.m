function [] = set_disk (disk)
%SET_DISK Set raw data source disk name
%
global genie_handle
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% check the disk is a character string or a blank:
if(~isa(disk,'char') | size(disk,1)>1) % we'll allow a blank string too
    error ('Directory must be a character string')
end
genie_disk = deblank(disk);
