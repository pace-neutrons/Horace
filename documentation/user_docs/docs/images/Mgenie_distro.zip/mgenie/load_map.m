function map_out = load_map (file)
% LOAD_MAP reads the list of spectra in a map file into a cell array of 1D arrays.
% Each array contains the spectra for that workspace. For example, if the examples below
% are used to load a map file into the cell array, map:
%
%   map{1}  array of spectra in workspace 1
%   map{2}  array of spectra in workspace 2
%    :                    :
%
% Syntax
%   >> map = load_map (file)    % read from named file
%   >> map = load_map           % prompts for file
%


% Get file name - prompt if file does not exist (using file to set default seach location and extension
% -----------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.map');
end
if (isempty(file_internal))
    error ('No file given')
end

% Use get routine:
% -----------------
map_out = get_map (file_internal);