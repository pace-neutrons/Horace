function xrem = remove_ranges_cut (wcut, xkeep, xremove)
% Given a cut and remove and keep ranges, return array of remove ranges
% for use with Tobyfit
%
%   >> xrem = remove_ranges_cut (wcut, xkeep, xremove)
%
% Input:
%   x       Array of x coordinates of data points
%   xkeep   Ranges of x and y to retain for fitting. A range is specified by an array
%               [xlo, yhi]
%           More than one range can be defined in rows,
%               [xlo_1, yhi_1; xlo_2, yhi_2;...]
%   xremove Ranges to remove from fitting. Follows the same format as xkeep
%
% Output:
%   xrem    2xm array containing the lower and upper limits of 
%           ranges to be removed from the cut
%               xrem=[p1, p2, p3, ...; q1, q2, q3, ...]
%           means remove p1 to q1, and p2 to q2, etc.
%
%           If no range is to be removed, then xrem=[]
%
%  The output cell array xrem can be used to construct a list of commands for Tobyfit for the
% a slice using the new multi-frills command @rmuse to remove ranges
%
%   # @rmuse <irun> <idataset> 1 p1 q1
%   # @rmuse <irun> <idataset> 1 p2 q2
%           :

x=get(wcut,'x');
zarr=ones(size(x));
earr=ones(size(x));
sel = retain_for_fit ({x}, zarr, earr, xkeep, xremove, []);

if numel(x)>1
    del=(x(end)-x(1))/(numel(x)-1);
else
    del = max(0.0002*x,0.0002);   % to give a range even if only one point
end
xbnd=[x(:)-del/2;x(end)+del/2];

xrem=remove_ranges(xbnd,sel);
