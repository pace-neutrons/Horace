function w = read_sum (file)
% READ_SUM    reads x,y,e arrays of spectrum number, sum, error on sum
%             from Homer/White_van/Sum, or Sumspec
%
% Syntax
%   >> w = read_sum (file)    % read from named file
%   >> w = read_sum           % prompts for file
%

% Get file name - prompt if file does not exist (using file to set default seach location and extension)
% ------------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.sum');
end
if (isempty(file_internal))
    error ('No file given')
end

% Read in data
% ------------
fid = fopen(file_internal);
tline = fgets(fid);
tline = fgets(fid);
tline = fgets(fid);
loc = findstr('Sum/minute',tline);
tline = fgets(fid);

if ~isempty(loc) % treat case of a file produced by VMS SUMSPEC program separately
    a = fscanf(fid,'%*g %g %*g %*g %*g %g %*g',[2,inf]);
    w.x=a(1,:);
    w.y=a(2,:);
    w.e=sqrt(abs(w.y));
else
    a = fscanf(fid,'%*g %g %*g %*g %*g %g %g',[3,inf]);
    w.x=a(1,:);
    w.y=a(2,:);
    w.e=a(3,:);
end
fclose(fid);

% Put data in a spectrum (point mode)
% ----------------------
w = spectrum(w.x,w.y,w.e);
w = set(w,'title',avoidtex(file_internal));

disp (['Data read from ' file_internal])
