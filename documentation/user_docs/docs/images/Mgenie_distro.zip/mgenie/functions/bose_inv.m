function y = bose_inv (x, beta)
% Inverse of Bose function. Multiply S(Q,w) by this function to get X''(Q,w)
%   >> y = bose_inv(x,beta)
%   x       energy (your choice of units)
%   beta    hbar/(Kb.T) in the same units as x
%               Recall 1 meV = 11.6045 K
%
%   y       = 1-exp(beta.x)
y = 1 - exp(-beta*x);