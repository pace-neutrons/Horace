function y = polyline (x, xpnt, ypnt)
% Function joining points
%   >> y = polyline(x,xpnt,ypnt)
%   x       x value(s) at which to evaluate function
%   xpnt    -|-(x,y) pairs of points defining the line
%   ypnt    -|
%
%   y       Linearly interpolated y-value(s)
%
% - If the function is multi-valued at any point, then
%  the lowest value is returned.
% - The evaluation is performed using two extra points
%  at (-Inf,ypnt(1)) and (Inf,ypnt(end)) for evaluation
%  outside the range of xpnt

if isa_size(xpnt,'row') & isa_size(ypnt,'row')
    xx = [-Inf,xpnt,Inf];
    yy = [ypnt(1),ypnt,ypnt(end)];
elseif isa_size(xpnt,'column') & isa_size(ypnt,'column')
    xx = [-Inf;xpnt;Inf];
    yy = [ypnt(1);ypnt;ypnt(end)];
else
    error('Check that the point arrays are both row or both column vectors')
end

xlo = min(xx(1:end-1),xx(2:end));
xhi = max(xx(1:end-1),xx(2:end));
y=zeros(size(x));

% trick to avoid divide by zero warning
warning_status = warning('query');
warning off

for i=1:length(x)
    ind = find(x(i)>=xlo & x(i)<=xhi);
    ytemp = ((x(i)-xx(ind)).*yy(ind+1) + (xx(ind+1)-x(i)).*yy(ind))./(xx(ind+1)-xx(ind));
    bad = isnan(ytemp)|ytemp>max(yy(ind),yy(ind+1))|ytemp<min(yy(ind),yy(ind+1));
    ygood=min(yy(ind),yy(ind+1));
    ytemp(bad) = ygood(bad);
    y(i) = min(ytemp);
end
    
% return to original warning status
warning(warning_status);