function y = gauss (x, cent, sig)
% Normalised Gaussian function: y = gauss (x, cent, sig)
y = (1/(sig*sqrt(2*pi))) * exp(-0.5*((x-cent)/sig).^2);