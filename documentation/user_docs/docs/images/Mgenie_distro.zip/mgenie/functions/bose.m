function y = bose (x, beta)
% Bose function. Multiply X''(Q,w) by this function to get S(Q,w)
%   >> y = bose(x,beta)
%   x       energy (your choice of units)
%   beta    hbar/(Kb.T) in the same units as x
%               Recall 1 meV = 11.6045 K
%
%   y       = 1/(1-exp(beta.x))

% trick to avoid divide by zero warning
warning_status = warning('query');
warning off

y = 1./(1 - exp(-beta*x));

% return to original warning status
warning(warning_status);