function y = pop (x, beta)
% Bose function multiplied by energy
%   >> y = pop(x,beta)
%   x       energy (your choice of units)
%   beta    hbar/(Kb.T) in the same units as x
%               Recall 1 meV = 11.6045 K
%
%   y       = x/(1-exp(beta.x))

% trick to avoid divide by zero warning
warning_status = warning('query');
warning off

y = x./(1 - exp(-beta*x));

% return to original warning status
warning(warning_status);