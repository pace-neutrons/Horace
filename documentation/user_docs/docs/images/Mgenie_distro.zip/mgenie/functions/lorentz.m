function y = lorentz (x, cent, gam)
% Normalised Lorenztian function: y = lorentz (x, cent, gam) (gam=HWHH)
y = (gam/pi)./((x-cent).^2 + gam^2);