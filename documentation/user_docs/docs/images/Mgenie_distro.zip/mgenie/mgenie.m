function [] = mgenie ()
%MGENIE To start MGENIE
genie_init