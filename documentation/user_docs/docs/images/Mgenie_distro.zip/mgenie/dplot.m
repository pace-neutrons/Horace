function dplot (w)
% Creates a colour plot of MAPS diffraction data created by DSPACE_MAPS or DSCAN_ANAL
% functions. [The difference between dplot and the more standard mgenie function mplot
% is that the y axis is labelled with the scattering angle or scan parameter value
% rather than the index of the workspace in the array created by dspace_maps.]
%
% Syntax:
%   >> dplot (w)

% should work for MARI, and HET if stick to just 4m or just 2.5m banks.

% *** AN AWFUL, AWFUL FIX-UP UNTIL ADD AN EXTRA PARAMETER TO HOLD MPLOT Y VALUES ***
% use efix to hold the dplot y-axis and dintegrate x-axis values 
lw = length(w);
ang = zeros(1,lw);
for i=1:lw
    ang(i) = get(get(w(i),'tofpar'),'efix');
end


% Get title for the y axis:
temp = get(get(w(1),'spectrum'));
if isempty(temp.title)
    str='';
elseif isa(temp.title,'cell')
    lt = length(temp.title);
    str = char(temp.title{lt});
elseif isa(temp.title,'char')
    str = temp.title;
else
    display ('Something screwy with titles')
    str = ''
end

if (~isempty(str))
    k = findstr(str,'Scan:');
    if (~isempty(k))
        str=str(k+5:end);
    else
        str='';
    end
end
str=fliplr(deblank(fliplr(deblank(str))));  % in matlab 7 can use strtrim
if (~isempty(str))
    ylab = str;
else
    ylab = 'Scan parameter value'
end

% Perform plot:
if (strcmp(ylab,'Scattering angle'))   % by convention, is detector scattering angle
    % Get median spacing. Use this as the value for plotting purposes
    % (use median, as there will be gaps between detector banks that will distort the average)
    widths = ang(2:end) - ang(1:end-1);
    delta = median(widths)*ones(1,lw);
    mplot(w,ang,delta);
    ylabel(ylab);
else
    mplot(w,ang);
    ylabel(ylab);
end

