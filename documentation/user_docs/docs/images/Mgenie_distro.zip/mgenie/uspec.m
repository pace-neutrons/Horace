function wout = uspec(map, period, av_mode_mspec, av_mode_uspec, xunits, rebin_vec)
%
% Special interface to mspec that performs units conversion on spectra,
% rebins and then adds to give the output workspaces.
%
% Simple argument checking as not designed for users.
%
% This routine is a fixup until units conversion and rebinning are
% implemented in mspec and spec. THis routine is limited because it
% does not work with masking arrays.
%
%   map             Cellarray of integer arrays
%   period          Period number
%   av_mode_mspec   Detector averaging mode for use inside mspec
%   av_mode_uspec   Spectrum averaging mode for summing performed in dspec
%   xunits          Character string giving units for conversion (see units
%                  command for available units)
%   rebin_vec       Vector giving rebinning boundaries (see rebin command
%                  for syntax)
%

% Get list of spectra
nw = length(map);
ns = zeros(1,nw);
for i=1:nw
    ns(i)=length(map{i});
end
nscum=[0,cumsum(ns)];
s = zeros(1,nscum(end));
for i=1:nw
    s(nscum(i)+1:nscum(i+1)) = map{i};
end

% Call mspec to create temporary output array of workspaces
w = mspec(s,'period',period,av_mode_mspec);

% Do units conversion, rebinning and summing
w = rebin(units(w,xunits),rebin_vec);
wout = repmat(w(1),1,nw);   % create dummy output array with correct titles, lengths of x,y,e axes
for i = 1:nw
    wout(i) = sum_work(w,nscum(i)+1,nscum(i+1));
end

% Average tofpar:
par = get(w(1),'tofpar');   % get parameters so recover efix, x1, emode
twotheta = zeros(1,length(w));
delta = zeros(1,length(w));
x2 = zeros(1,length(w));
for i=1:length(w)
    temp = get(w(i),'tofpar');
    twotheta(i) = get(temp,'twotheta');
    delta(i) = get(temp,'delta');
    x2(i) = get(temp,'x2');
end
twotheta
if strcmp(av_mode_uspec,'min_twotheta')
    for i = 1:nw
        [test,ind] = min(twotheta(nscum(i)+1:nscum(i+1)));
        ind = ind + nscum(i);
        par = set_simple(par,'twotheta',twotheta(ind),'delta',delta(ind),'x2',x2(ind));
        wout(i) = set_par(wout(i),par);
    end
elseif strcmp(av_mode_uspec,'max_twotheta')
    for i = 1:nw
        [test,ind] = max(twotheta(nscum(i)+1:nscum(i+1)));
        ind = ind + nscum(i);
        par = set_simple(par,'twotheta',twotheta(ind),'delta',delta(ind),'x2',x2(ind));
        wout(i) = set_par(wout(i),par);
    end
elseif strcmp(av_mode_uspec,'average')
    for i = 1:nw
        twotheta_temp = sum(twotheta(nscum(i)+1:nscum(i+1)))/ns(i);
        delta_temp = sum(delta(nscum(i)+1:nscum(i+1)))/ns(i);
        x2_temp = sum(x2(nscum(i)+1:nscum(i+1)))/ns(i);
        par = set_simple(par,'twotheta',twotheta_temp,'delta',delta_temp,'x2',x2_temp);
        wout(i) = set_par(wout(i),par);
    end
elseif strcmp(av_mode_uspec,'none')
    par = set_simple(par,'twotheta',NaN,'delta',NaN,'x2',NaN);  % Follow convention mspec_core
else
    error ('ERROR: Unrecognised averaging of tofpar for spectra -> workspaces')
end

