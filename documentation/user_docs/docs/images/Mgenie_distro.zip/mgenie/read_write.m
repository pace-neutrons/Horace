function read_write (nlines, file1, file2)
% READ_WRITE    reads the first lines of a file into a text file.
% Some files are too large to be opened in a text editor, so this routine can
% be used to read them.
%
% Syntax
%   >> read_write           % Prompts for input and output file names, and reads a
%                             maximum of 1000 lines
%   >> read_write (n)       % Read first N lines; prompts for input and output file names
%
%   >> read_write (n, file_in, file_out)
%

nlines_max = 1000;      % max. no. lines to read from file 

% Get number of lines to read & write
% ------------------------------------
if (nargin < 1)
    nlines = nlines_max;
else
    if (nlines<1 | ~(isa(nlines,'double') & max(size(nlines))==1))
        error ('no. lines must be a positive value')
    end
end

% Get input file name - prompt if file does not exist
% ---------------------------------------------------
if (nargin>=2)
    if (exist(file,'file')==2)
        file_internal = file1;
    else
        file_internal = genie_getfile(file1);
    end
else
    file_internal = genie_getfile;
end
if (isempty(file_internal))
    error ('No file given')
end


% Read in data
% ------------
fid = fopen(file_internal);
i = 1;
finish = 0;
while (~finish)
    tline{i} = fgets(fid);
    if (~isa(tline{i},'numeric'))
        i = i + 1;
        if (i>nlines)
            disp([num2str(nlines) ' lines read from file'])
            n = nlines;
            finish = 1;
        end
    else
        n = i - 1;  % no. lines read from file
        finish = 1;
    end
end
fclose(fid);

if (n<0)
    error ('No data read from file. No output file created')
end


% Get output file name - prompting if necessary
% ---------------------------------------------
if (nargin<3)
    file_internal = genie_putfile('*.txt');
    if (isempty(file_internal))
        error ('No file given')
    end
elseif (nargin==3)
    file_internal = file2
end

fid = fopen (file_internal, 'wt');
if (fid < 0)
    error (['ERROR: cannot open file ' file_internal])
end

for i=1:n
    fprintf(fid,'%s',tline{i});
end
fclose(fid);