function wout = tomgenie(d)
% Function to copy a dataset_1d into an MGENIE spectrum
wout = spectrum(d.x,d.signal,d.error,d.title,d.x_label,'intensity',d.x_units,real(d.x_distribution));
