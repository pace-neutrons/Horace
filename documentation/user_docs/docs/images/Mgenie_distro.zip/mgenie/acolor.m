function [] = acolor(varargin)
% acolor: Change the colour for line and markers in MGENIE plots.
%         The color can be entered as either the standard one-character 
%        Matlab abbreviation or an unambiguous abbreviation of the full
%        colour name.
%
% Syntax:
%   >> acolor('r')
%   >> acolor('k')      % black
%   >> acolor('re')
%   >> acolor('bla'))
%
% Argument can set a sequence of colors for cascade plots e.g.
%   >> acolor('r','b','bla','g')
%   >> acolor({'r','y','k'})        % cell array
%
% The color can be entered as either the one-character MatLab abbreviation:
%            r, g, b, c, m, y, k, w
% or an unambiguous abbreviation of the full colour name:
%            red, green, blue, cyan, magenta, yellow, black, white

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

% Create vector of colors
n = length(varargin);
if n < 1
    genie_color
    return
end
ncol = 0;
col_type =[];
for i = 1:n
    try
        temp = evalin('caller',varargin{i});
    catch
        temp = varargin{i};
    end
    if isa_size(temp,'vector','cellstr')
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        col_type = [col_type,temp];
    elseif isa(temp,'char') && length(size(temp))==2
        temp=strtrim(cellstr(temp));
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        col_type = [col_type,temp];
    else
        error ('Check argument type(s)')
    end
end

% check validity of input arguments
col_brev = {'r', 'g', 'b', 'c', 'm', 'y', 'k', 'w'};
col_full = {'red', 'green', 'blue', 'cyan', 'magenta', 'yellow', 'black', 'white'};
if length(col_type)>0
    for i=1:length(col_type)
        itype = string_find (col_type{i}, col_brev);
        if itype == 0
            itype = string_find (col_type{i}, col_full);
        end
        if itype>0
            col_type(i) = col_brev(itype);
        elseif itype==0
            error ('Invalid color - left unchanged (acolor)')
        elseif itype<0
            error ('Ambiguous abbreviation of color name - left unchanged (acolor)')
        end
    end
    genie_color = col_type;
end
