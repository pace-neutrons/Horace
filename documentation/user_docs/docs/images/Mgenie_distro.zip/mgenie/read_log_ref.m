function [w, value, mess] = read_log (varargin)
% READ_LOG reads a log file for a given run number and parameter name and
%          returns 
%          (i)the value of the logged variable as a function of time
%          from the beginning of the run, in a spectrum object,
%          (ii) the average, median, standard deviation, minimum and maximum
%          values of the logged parameter during the run
%
% Notes:
%          The path on which the log file is searched for is the one set with
%          the set_disk, set_dir, set_inst, set_ext and ass commands.
%
% Syntax:
%   >> w = read_log (irun, parameter_name)
%   >> [w, val] = read_log (irun, parameter_name)
%
%   w    Spectrum containing logged parameter as a function of time
%   val  Structure with fields val.average, val.median, val.std_dev,
%       val.minimum, val.maximum
%
% --- Optional input parameter:
%   The spectrum is returned in elasped seconds, minutes or hours according to
%   how long the run was. To overide the default choice enter the units as the
%   final parameter ('s','m','h')
% e.g.
%   >> w = read_log (7045, 't_head', 's')
% e.g.
%   >> w = read_log (7045, 't_head')
%
%
% --- Optional output parameter for silent return from error
%
%   >> w = [w, val, mess] = read_log (irun...)
%
%   If read_log encounters an error e.g. unable to find log file, no values logged
%   then w, val are returned as empty, and mess is filled with the error message.
%   If values were logged, but not between the start and end times of the run, then
%   val is returned as the last logged value before the run began, and a warning
%   message is placed in mess.
%

global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt

if nargout==3; fail_on_error=0; else; fail_on_error=1; end
w = spectrum;
value = '';
mess = '';

% Check input arguments
if nargin < 2
    mess = 'ERROR: Missing parameters to read_log'
    if fail_on_error; error(mess); else; return; end
end
run_log = varargin{1};
log_parameter = varargin{2};
if nargin==3
    time_units = varargin{3};
else
    time_units = '';
end

if isa(run_log,'numeric') & length(run_log)>0
    run_store = genie_run;  % store currently assigned run number
    run_char_store = genie_run_char;
    mess = ass(run_log);
    if ~isempty(mess)
        if ~isempty(run_store)
            ass(run_store)  % reset original run assignment, if assigned
        end
        if fail_on_error; error(mess); else; return; end
    else
        run_log_char = genie_run_char;  % save character representation in the GENIE format for constructing log file name later on
        run_start_char =[gget('start_date'),' ',gget('start_time')];
        run_finish_char=[gget('end_date'),' ',gget('end_time')];
        run_start=datenum(run_start_char);     % time is to nearest second only
        run_finish=datenum(run_finish_char);    % time is to nearest second only
        if ~isempty(run_char_store)
            ass(run_store)  % reset original run assignment, if assigned
        end

    end
else
    mess = 'ERROR: First argument must be run number';
    if fail_on_error; error(mess); else; return; end
end

if isa(log_parameter,'char') & size(log_parameter,1)==1 & length(log_parameter)>0
    % find logfile. Note there is more than one possible format to check !
    if strcmp(lower(genie_instrument),'map')
        inst_full = 'maps';
    else
        mess = 'Unrecognised instrument for reading log files';
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
    
    file=[pathname(genie_disk,genie_directory),genie_instrument,run_log_char,'_',log_parameter,'.txt'];
    file_translated=findfile(file,'old');
    istatus=exist(file_translated); % check if file exists
    if (istatus ~= 2)
        file=[pathname(genie_disk,genie_directory),inst_full,num2str(run_log),'_',log_parameter,'.txt'];
        file_translated=findfile(file,'old');
        istatus_2=exist(file_translated);
        if(istatus_2 ~=2)
            mess = ['Cannot find log file for parameter ',log_parameter ,' for run ',num2str(genie_run),'.\nCheck genie search path'];
            if fail_on_error; error(mess,'ASS'); else; mess_out=mess; return; end
        end
    end
    
    % open log file, read entries
    fid = fopen(file_translated);
    istart=ftell(fid);  % starting point of file
    tline = fgets(fid);
    if isnumeric(tline) % must be an error or empty file
        mess = ['ERROR: Empty file or error reading from ',file_translated];
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
    
    % do some tests on tline to check format is OK
    time = tline(1:19);
    if time(3:3)=='/'       % assume datetime format dd/mm/yyyy HH:MM:SS
        format = 'dd/mm/yyyy HH:MM:SS';
    elseif time(5:5)=='-' & time(11:11)==' '   % assume datetime format yyyy-mm-dd HH:MM:SS
        format = 'yyyy-mm-dd HH:MM:SS';
    elseif time(5:5)=='-' & time(11:11)=='T'   % assume datetime format yyyy-mm-ddTHH:MM:SS
        format = 'yyyy-mm-ddTHH:MM:SS';
    else
        mess = ['ERROR: Unrecognised date-time format in ',file_translated];
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
    
    % Read in whole of log file into two cell arrays, one of time, one of log value
    fstatus=fseek(fid,istart,'bof'); % step back one line
    a = textscan(fid, '%19s%s');
    fclose(fid);

    % log files for PC-ICP store times to nearest second only;
    time = round(86400*(datenum(a{1},format)-run_start));  % elapsed time from start of run in seconds
    log_val = str2num(char(a{2}));
    
    % create output workspace
    xlab = 'Elapsed time from start of run';
    ylab = avoidtex(log_parameter);
    distribution = 0;
    run_duration = round(86400*(run_finish - run_start));
    iunit = string_find(time_units,{'seconds','minutes','hours'});
    if iunit==3 | (iunit<1 & time(end)>3*3600)    % if more than three hours long, express time in hours
        time = time/3600;
        duration = num2str(run_duration/3600, '%6.2f');
        xunit= 'hours';
        short_xunit= 'hr';
    elseif iunit==2 | (iunit<1 & time(end)>5*60)    % if more than five minutes long, express time in minutes
        time = time/60;
        duration = num2str(run_duration/60, '%6.2f');
        xunit= 'minutes';
        short_xunit= 'min';
    else
        duration = num2str(run_duration);
        xunit= 'seconds';
        short_xunit= 'sec';
    end
    title= {avoidtex(file_translated),['Run date: ',run_start_char,' to ',run_finish_char,'   Duration: ',duration,' ',short_xunit]};
    w=spectrum(time,log_val,zeros(length(log_val),1),title,xlab,ylab,xunit,distribution);
    
    % Calculate average temperature, st. deviation etc.
    ind=find(time>0&time<run_duration);
    if length(ind)<1
        ind = find(time<0);
        if length(ind)<1
            mess='ERROR: No values logged before or during run';
            if fail_on_error; error(mess); else; mess_out=mess; return; end
        else
            mess='Warning: No values logged during run; using last value before run.';
            value.average = log_val(ind(end));
            value.median  = value.average;
            value.std_dev = 0;
            value.minimum = value.average;
            value.maximum = value.average;
        end
    else
        value.average= mean(log_val(ind));
        value.median = median(log_val(ind));
        value.std_dev= std(log_val(ind),1);
        value.minimum= min(log_val(ind));
        value.maximum= max(log_val(ind));
    end
    
end
