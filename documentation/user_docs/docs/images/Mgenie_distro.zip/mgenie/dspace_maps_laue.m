function w = dspace_maps_laue(irun,bank)
% Creates an array of tofspectra for the named bank. Assumes 4to1 spectra.dat.
% The units are d-spacing along the x-axis
%
% Syntax:
%   >> w = dspace_maps_laue (irun, bank) % bank is a1,a2,c1,c2,c3,c4
%
%  e.g.
%   >> w = dspace_maps_laue (9765, 'c4')

ass(irun);

len16 = 16*64;
len18 = 18*64;
len34 = 34*64;
len36 = 36*64;

if strcmp(lower(bank),'a1')
    start = [1,len18+1,2*len18+1,3*len18+1];
    finish= [len16,len18+len16,2*len18+len16,3*len18+len16];
elseif strcmp(lower(bank),'a2')
    start = 4608+[1,len18+1,2*len18+1,3*len18+1];
    finish= 4608+[len16,len18+len16,2*len18+len16,3*len18+len16];
elseif strcmp(lower(bank),'c1')
    start = 32257;
    finish= start + len34 - 1;
elseif strcmp(lower(bank),'c2')
    start = 32257 + len36;
    finish= start + len34 - 1;
elseif strcmp(lower(bank),'c3')
    start = 32257 + 2*len36;
    finish= start + len34 - 1;
elseif strcmp(lower(bank),'c4')
    start = 32257 + 3*len36;
    finish= start + len34 - 1;
else
    error('Unrecognised MAPS detector bank')
end

w = units(mspec(start,finish),'d');

