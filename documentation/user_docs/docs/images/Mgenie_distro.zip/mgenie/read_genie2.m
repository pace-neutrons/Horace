function w = read_genie2 (file)
% READ_GENIE2 Reads x,y,e arrays of bin boundaries, y, errors on y, from the output
% of SHOW DATA command in Genie-2. It is assumed that the file being read is
% the output from a histogram data set.
%
% Syntax:
%   >> w = read_hist (file)    % read from named file
%   >> w = read_hist           % prompts for file
%

% Get file name - prompt if file does not exist (using file to set default seach location and extension)
% ------------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile;
end
if (isempty(file_internal))
    error ('No file given')
end

% Read data
% -----------
fid = fopen(file_internal);
tline = fgets(fid);
tline = fgets(fid);
tline = fgets(fid);
tline = fgets(fid);
a = fscanf(fid,'%*g %g %g %g',[3,inf]);
fclose(fid);

% Put data in a spectrum (histogram mode assumed)
% ----------------------
nx = size(a,2);
w.x=a(1,1:nx);
w.y=a(2,1:nx-1);  % we are reading histogram data
w.e=a(3,1:nx-1);
w = spectrum(w.x,w.y,w.e);

disp (['Data read from ' file_internal])
