function w = mask_spefile (w, mask)
% MASK_SPE Takes an array of MGENIE spectra and replaces the y and e values with NaN
%          for spectra with indicies given in the mask array 
%
% Syntax:
%   >> w = mask (w, mask)
%

if ~isa_size(mask,'vector','numeric')
    error ('mask array must be a numeric vector')
end

if length(mask)==0
    wout = w;
    disp('No spectra masked')
elseif min(mask)<0 | max(mask)>length(w)
    error('Elements of mask array must lie in range 1-length(input_workspace)')
else
    wout = w;
    for i = mask
        temp = size(get(w(i),'y'));
        w(i) = set(w(i),'y',nan(temp),'e',nan(temp));
    end
end
