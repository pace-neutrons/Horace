function mess_out = ass (source_in)
% ASS Sets run number, dae or crpt as data source
%
% Syntax:
%   >> ass (123)
%   >> ass ("dae")
%   >> ass ("crpt")
%
global genie_handle
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_mgenie_initialised genie_opengenie_present

% Determine failure mode and default return algorithm
if nargout==1; fail_on_error=0; else; fail_on_error=1; end
mess='';

if ~genie_mgenie_initialised
    genie_init
end

if nargin ~= 1
    mess = 'command must have one argument';
    if fail_on_error; error(mess); else; mess_out=mess; return; end
else
    try
        source = evalin('caller',source_in);
    catch
        source = source_in;
    end
end

% Check that run number is valid (allow for int32 too): must have runno in range 1->99999, or 'dae' or 'crpt'
runno = 0;
crpt = 0;
dae = 0;
if (isa(source,'double') | isa(source,'int32'))
    runno = double(source);
    if runno < 1
        mess = 'Run number must be in range 1 - 99999';
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    elseif runno < 10
        runno_char=strcat('0000',sprintf('%.0f',round(runno)));
    elseif runno < 100
        runno_char=strcat('000',sprintf('%.0f',round(runno)));
    elseif runno < 1000
        runno_char=strcat('00',sprintf('%.0f',round(runno)));
    elseif runno < 10000
        runno_char=strcat('0',sprintf('%.0f',round(runno)));
    elseif runno < 100000
        runno_char=sprintf('%.0f',round(runno));
    else
        mess = 'Run number must be in range 1 - 99999';
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end 
elseif (isa(source,'char') & size(source,1)==1)
    if (strcmp(lower(source),'crpt'))
        crpt = 1;
    elseif (strcmp(lower(source),'dae'))
        dae = 1;
    else
        mess = 'Check input is DAE or CRPT';
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
else
    mess = 'Check input is a valid run number, DAE or CRPT';
    if fail_on_error; error(mess); else; mess_out=mess; return; end
end

if (runno > 0)
    % Now check that the data file exists:
    file=[pathname(genie_disk,genie_directory),genie_instrument,runno_char,'.',genie_extension];
    file_translated=findfile(file,'old');
    istatus=exist(file_translated); % check if file exists
    if (istatus ~= 2)
        mess = strcat(['Input data file   ' file '   does not exist.\nInput data source unchanged']);
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
    % Now call genie data access
    genie_run = runno;
    genie_run_char = runno_char;
    genie_file = file_translated;
    command = ['set/file/input "',strrep(file_translated,'\','/'),'"'];     % replace \ with / in file name to avoid genie silliness.

elseif (crpt)
    command = 'assign $crpt';
    
elseif (dae)
    command = 'assign $dae';
    
end

% issue command to open genie:
if ~isempty(genie_handle)
    invoke (genie_handle,'AssignHandle',command,'');
else
    error('Command cannot be completed because OpenGenie not found')
end

if nargout==1;mess_out=mess;end
