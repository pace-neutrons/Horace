function w = dscan_anal (irun_start, specno, scan_parameter_name, omega_start, d_omega, npnts, p1, p2, p3)
% Analysis of an alignment scan. Produces an array of spectra containing the intensity
% as a function of d-spacing for the chosen instrument spectrum as a function of the
% scan parameter. The data must be either in a consecutive series of runs, or a single
% multi-period run. The user is prompted for parameters that are not supplied. 
%
% Data is normalised by the monitor integral. The monitor and integration ranges are
% set using the mgenie function analysis_init.
%
% Syntax:
%  For default d-spacing range and binning:
%   >> wout = dscan_anal(irun_start, specno, scan_parameter_name, start_value, step, npnts)
%
%  For custom d-spacing range and binning:
%   >> wout = dscan_anal(irun_start, ... npnts, d_start, d_finish, d_step)

global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant

%------------------------------------------------------------------------------------------------------
% default d-spacing binning.
dlo_def = 0.5;  % instrument specific (depends on scattering angle range)
dhi_def = 15;   % instrument specific (depends on scattering angle range)
%------------------------------------------------------------------------------------------------------

% Read in any unsupplied parameters:
if (nargin < 1)
    str = input('Give (starting) run number for analysis: ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    irun_start = evalin('caller',str);
end

if (nargin < 2)
    str = input('                        spectrum number: ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    specno = evalin('caller',str);
end

if (nargin < 3)
    str = input('       Name of parameter being scanned : ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    try
        scan_parameter_name = evalin('caller',str);
        if (~ischar(scan_parameter_name))
            error ('Scan parameter name must be a character string')
        end    
    catch
        scan_parameter_name = str;
    end
end

if (nargin < 4)
    str = input('                        starting value : ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    omega_start = evalin('caller',str);
end

if (nargin < 5)
    str = input('                             step size : ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    d_omega = evalin('caller',str);
end

if (nargin < 6)
    str = input('                       number of points: ','s');
    if isempty(str)
        error ('Parameter must be suppled')
    end
    npnts = evalin('caller',str);
end

% Get data
ass(irun_start)
nperiods = double(gget('nper'));
if nperiods==1      % assume single run for each crystal setting
    % Get spectra:
    for i=1:npnts
        disp(['Analysing point ',num2str(i),' ...'])
        ass(irun_start+i-1);
        % Get normalisation constant
        area = integrate(unspike(mon(analysis_mon_norm,'none')),analysis_mon_tlo,analysis_mon_thi);
        norm = area.val/analysis_mon_norm_constant;
        if i~=1
            w(i) = set_spectrum(w(i),spec(specno,'none')/norm);
        else
            w = spec(specno)/norm;
            w = repmat(w,1,npnts);
        end
    end
elseif nperiods >= npnts
    % Get normalisation constant
    area = integrate(unspike(mon(analysis_mon_norm,linspace(1,npnts,npnts),'none')),analysis_mon_tlo,analysis_mon_thi);
    norm = get(area,'y')/analysis_mon_norm_constant;
    w = spec(specno,'period',linspace(1,npnts,npnts))/norm;
else
    error ('Check the number of points &/or number or periods in run')
end

% Add line to titles to show spectrum number and nature of analysis
for i=1:length(w)
    add_title = ['Spectrum ',num2str(specno),'   Scan: ',scan_parameter_name];
    temp = get(get(w(i),'spectrum'));
    if isempty(temp.title)
        temp.title = add_title;
    elseif isa(temp.title,'cell')
        lt = length(temp.title);
        temp.title{lt+1} = add_title;
    elseif isa(temp.title,'char')
        temp.title = cellstr(temp.title);
        temp.title{2}=add_title;
    else
        error ('Something screwy with titles')
    end
    w(i) = set_spectrum(w(i),spectrum(temp));
end


% change units:
n_dpar = nargin - 6;
if (n_dpar<=0)  % no d-spacing information given
    w = rebin(units(w,'d'),dlo_def,dhi_def);
elseif (n_dpar==2)
    if (isa(p1,'double') & isa(p2,'double'))
        w = rebin(units(w,'d'),p1,p2);
    else
        error ('Check rebinning parameter types')
    end
elseif (n_dpar==3)
    if (isa(p1,'double') & isa(p2,'double') & isa(p3,'double'))
        w = rebin(units(w,'d'),p1,p2,p3);
    else
        error ('Check rebinning parameter types')
    end
else
    error ('Check number of rebinning parameters')
end


% *** AN AWFUL, AWFUL FIX-UP UNTIL ADD AN EXTRA PARAMETER TO HOLD MPLOT Y VALUES ***
% use efix to hold the dplot y-axis and dintegrate x-axis values 
for i=1:length(w)
    w(i) = set_par(w(i),'efix',omega_start+(i-1)*d_omega);
end
