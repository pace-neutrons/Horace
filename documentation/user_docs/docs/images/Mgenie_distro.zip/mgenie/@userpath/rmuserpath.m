function [path_out, mess] = rmuserpath (path_in, varargin)
% USERPATH/RMUSERPATH  Removes one or more paths from a user path
%
% Syntax
%   >> path_out = userpath(path_in,path1,path2,...)
%
%   path_in is the user path from which path1, path2, ... will be removed
%
%   path1, path2, ... are valid paths, i.e.
%    - A directory name e.g. 'c:\temp\my_work'
%
%    - A valid matlab path i.e. a character string containing a series of
%     directory names separated by the (platform-specific) path separator
%     On windows the separator is ';' so 'c:\temp;c:\my_progs' is valid.
%
%    - A previously defined user path created with userpath
%
%    - An environment variable for the platform. Note that environment
%     variables are translated at the time of the call to userpath, hence
%     subsequent changes using SETENV are not recognised.
%
%

% Determine failure mode and default return algorithm
if nargout==2; fail_on_error=0; else; fail_on_error=1; end
p.path = {};
p_default=class(p,'userpath');

if ~isa(path_in,'userpath')
    path_out = p_default;
    mess = 'ERROR: First argument must be of class userpath'
    if fail_on_error; error(mess); else; return; end
end

if nargin==1
    path_out = path_in;
    mess = '';
    return
end

% construct a path from the remaining input arguments
if length(varargin)==1 & iscell(varargin{1})  % interpret as having been passed a varargin
                                    % (as cell array is not a valid type to be passed to rmuserpath)
    args = varargin{1};
else
    args = varargin;
end

[path_rm, mess] = userpath (args(1:nargin-1));
if ~isempty(mess)
    path_out = p_default;
    mess = 'ERROR: Check that argument(s) of paths to be removed are correct';
    if fail_on_error; error(mess); else; return; end
end

% find occurences of paths in path_in that are to be removed
% (This is probably an n^2 algorithm, but in practice paths will be short, so OK)
n_in = length(path_in.path);
keep=zeros(length(path_in.path),1);
for i=1:length(path_in.path)
    keep(i)=sum(strcmp(path_in.path{i},path_rm.path));
end
path_out.path = path_in.path(find(keep<1));

path_out = class(path_out,'userpath');
