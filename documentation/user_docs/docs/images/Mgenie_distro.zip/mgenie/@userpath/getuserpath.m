function path_out = getuserpath (path)
% USERPATH/GETUSERPATH  Returns the userpath object as a cell array
%                       of character strings.
%
% Syntax
%   >> path_out = getuserpath(path)
%
path_out = path.path;