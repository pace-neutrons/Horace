function [p_out, mess] = userpath (varargin)
% USERPATH/USERPATH  Sets a path on which to search for files. The path can
%   be put in file names so long as the file name is translated into a 
%   proper file name before it is used by intrinsic matlab functions.
%
% e.g.
%   >> my_path = userpath('c:\temp;c:\my_progs');
%   >> nam = file_translate('my_path:some_text.txt');
%   >> fid = fopen(nam)
%
% Syntax
%   >> path = userpath(path1,path2,...)
%
%   where path1, path2, ... are valid paths, i.e.
%    - A character string containng a directory name e.g. 'c:\temp\my_work'
%
%    - A valid matlab path i.e. a character string containing a series of
%     directory names separated by the (platform-specific) path separator
%     On windows the separator is ';' so 'c:\temp;c:\my_progs' is valid.
%
%    - A character string containing the name of a system  environment
%     variable. Note that environment variables are translated at the time
%     of the call to userpath, hence subsequent changes to the environment
%     variable using SETENV will not propagate to the user path.
%
%    - A character string containing the name of a global user path
%     defined by set_userpath
%
%    - A previously defined user path created with userpath
%
%
%   The output pathname is constructed in the order of the input arguments
%  and this will define the order files are searched for.
%
% See also:
%   rmuserpath, display
%
%
% Note: Given a particular directory structure, platform independent paths
%  can be built using the matlab intrinsic function FULLFILE and PATHSEP:
% e.g.
%   >> path1 = fullfile('c:','temp','my_work');  % ...
%         creates 'c:\temp\my_work' on windows, 'c:/temp/my_work' on unix.
%   >> path2 = fullfile('c:','my_progs');
%   >> long_path = [path1,pathsep,path2];
%

% Determine failure mode and default return algorithm
if nargout==2; fail_on_error=0; else; fail_on_error=1; end
p.path = {};
p_default=class(p,'userpath');

% Main algorithm:
p.path = {};
mess = '';
if nargin==1 & iscell(varargin{1})  % interpret as having been passed a varargin
                                    % (as cell array is not a valid type to be passed to userpath)
    args = varargin{1};
else
    args = varargin;
end
for i=1:length(args)
    if isa(args{i},'userpath')
        p.path = [p.path;args{i}.path];
    elseif isa(args{i},'char')
        str = args{i};
        if size(str,1)>1
            p_out = p_default;
            mess = 'ERROR: Check character strings are not matricies';
            if fail_on_error; error(mess); else; return; end
        elseif length(str)>0
            % break down into tokens
            j = strfind(str,pathsep);
            jbeg = [0,j]+1;
            jend = [j,length(str)+1]-1;
            len = jend-jbeg+1;   
            for k=find(len>0)
                test=str(jbeg(k):jend(k));
                if ~(strcmp(test,filesep)|strcmp(test,'/')|strcmp(test,'\'))    % on windows, '/' and '\' accepted as valid directories in EXIST !
%               If name conflicts resolved in priority order: global user path, environment variable, matlab partial path.#
                    temp = get_global(test);
                    if isa(temp,'userpath')
                        p.path = [p.path;temp.path];
                    elseif length(getenv(test))~=0
                        trans = getenv(test);
                        if exist(trans,'dir')==7
                            p.path = [p.path;cellstr(trans)];
                        elseif length(trans)>0
                            p_out = p_default;
                            mess = ['ERROR: Unrecognised path for environment variable: ',test];
                            if fail_on_error; error(mess); else; return; end
                        end
                    elseif exist(test,'dir')==7
                        p.path = [p.path;cellstr(test)];
                    else
                        p_out = p_default;
                        mess = ['ERROR: Unrecognised path: ',test];
                        if fail_on_error; error(mess); else; return; end
                    end
                end
            end
        end
    else
        p_out = p_default;
        mess = 'ERROR: Check input argument type(s)';
        if fail_on_error; error(mess); else; return; end
    end
end

% Remove any trailing filesep:
for i=1:length(p.path)
    if p.path{i}(end:end)==filesep
        p.path{i}=p.path{i}(1:end-1);
    end
end

% sort and remove duplicates - lousy n^2 algorithm, but paths will probably be short, so OK
repeat = zeros(length(p.path),1);
for i=1:length(p.path)-1
    for j = i+1:length(p.path)
        repeat(j) = max(repeat(j),strcmp(p.path{i},p.path{j}));
    end
end
p.path = p.path(find(repeat<1));

p_out = class(p,'userpath');
