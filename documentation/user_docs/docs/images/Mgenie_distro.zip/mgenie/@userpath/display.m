function display (p)
% USERPATH/DISPLAY Command window display of a user path
%
% Syntax:
%   >> display (path)
%

% Get name of input object
if (strcmp(inputname(1),''))
    string = 'path';
else
    string = inputname(1);
end

if length(p.path)==0
    disp ([string,' is an empty path.'])
else
    disp (['Path ''',string,''' has entries:'])
    for i=1:length(p.path)
        disp(['     ',p.path{i}])
    end
end
disp(' ')
