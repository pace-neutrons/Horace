function [efix,emode] = get_efix
% Get fixed energy for the run:
%     efix  - incident or final energy (meV)
%     emode - 0,1,2 for elastic, direct geometry, indirect geometry
%
% Inverse function of SET_EFIX
%
% Syntax:
%   >> efix = get_efix      efix = +ve for direct geometry (sets emode=1)
%                           efix = -ve for indirect geometry (sets emode=2)
%                           efix = 0   for elastic (sets emode=0)
% or:
%   >> [efix, emode] = get_efix (efix)    
%                               (efix > 0 if inelastic; set to zero if elastic)
%
%

global genie_handle
global genie_efix genie_x1 genie_emode
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

if nargout==1
    if round(genie_emode) == 2
        efix = -genie_efix;
    else
        efix = genie_efix;
    end
elseif nargout==2
    efix = genie_efix;
    emode = genie_emode;
else
    if round(genie_emode) == 2
        efix = -genie_efix;
    else
        efix = genie_efix;
    end
end
