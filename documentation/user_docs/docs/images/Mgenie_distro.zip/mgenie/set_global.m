function set_global (var_name, val)
% set_global: Assign a value to a variable with name given by the character
%            string var_name, and make it GLOBAL. 
%             Return value is 0 if error, 1 if OK
%
% Syntax:
%   >> ok = set_global (var_name, value)
%
% e.g.
%   >> ok = set_global ('map_path','c:\temp');
%   >> ok = set_global ('my_age',42);
%
if isvarname(var_name)
    eval(['global ',var_name]);
    eval([var_name,'=val;']);
elseif ischar(var_name) & size(var_name,1)==1
    error (['ERROR: ''',var_name,''' is an invalid name for a variable'])
else
    error ('ERROR: Invalid argument type for a variable name')
end