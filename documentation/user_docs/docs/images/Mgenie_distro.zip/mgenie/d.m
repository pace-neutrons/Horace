function [] = d (w, varargin)
% Creates a new plot of a spectrum or an array of spectra, drawing line,
% error bars and markers.
%
% Syntax:
%   >> d w1

global genie_max_spectra_1d

% Check all the arguments
if nargin == 0
    error ('Supply missing arguments')
elseif ~(nargin==1 | nargin==3 |nargin==5)
    error ('Check number of arguments')
end

if nargin >= 1
    try
        w_temp = evalin('caller',w);
    catch
        w_temp = w;
    end
    if (~isa(w_temp,'spectrum'))
        error 'Must provide a spectrum to be plotted')
    end
    % Check spectrum is not too long an array
    if length(w)>genie_max_spectra_1d
        error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
    end
end

if nargin >= 3
    try
        xlo_temp = evalin('caller',xlo);
    catch
        xlo_temp = xlo;
    end
    try
        xhi_temp = evalin('caller',xhi);
    catch
        xhi_temp = xhi;
    end
end

if nargin >= 5
    try
        ylo_temp = evalin('caller',ylo);
    catch
        ylo_temp = ylo;
    end
    try
        yhi_temp = evalin('caller',yhi);
    catch
        yhi_temp = yhi;
    end
end

if nargin >= 6
    try
        ylo_temp = evalin('caller',ylo);
    catch
        ylo_temp = ylo;
    end
    try
        yhi_temp = evalin('caller',yhi);
    catch
        yhi_temp = yhi;
    end
end

% Do the plotting
if nargin==1
    de(w_temp);
elseif nargin==3
    de(w_temp, xlo_temp, xhi_temp);
elseif nargin==5
    de(w_temp, xlo_temp, xhi_temp, ylo_temp, yhi_temp);
end
pm(w_temp)
pl(w_temp)


de(w,varargin{:})
if nargin>1 && ischar(varargin{end})
    fig_name=varargin{end};
    pm(w,fig_name)
    pl(w,fig_name)
else
    pm(w)
    pl(w)
end
