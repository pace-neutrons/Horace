ass(5740)
tic;
dummy = mon(1);
t=toc;
%-------------------------------------------------------------------
tic;
wt = mspec(1,1024);
t_fill=toc;
disp(['     Fill array = ',num2str(t_fill),' s']);
%-------------------------------------------------------------------
tic;
wd = deriv2(wt);
t_deriv2=toc;
disp([' 2nd derivative = ',num2str(t_deriv2),' s']);
%-------------------------------------------------------------------
tic;
wd = deriv(wt);
t_deriv=toc;
disp([' 1st derivative = ',num2str(t_deriv),' s']);
%-------------------------------------------------------------------
tic;
ans = integrate(wt,2000,5000);
t_integrate=toc;
disp(['    integration = ',num2str(t_integrate),' s']);
%-------------------------------------------------------------------
tic;
wd = rebin(wt,1000,50,10000);
t_rebin=toc;
disp(['          rebin = ',num2str(t_rebin),' s']);
%-------------------------------------------------------------------
tic;
wd = rebunch(wt,5);
t_rebunch=toc;
disp(['        rebunch = ',num2str(t_rebunch),' s']);
%-------------------------------------------------------------------
tic;
wd = regroup(wt,1000,50,10000);
t_regroup=toc;
disp(['        regroup = ',num2str(t_regroup),' s']);
%-------------------------------------------------------------------
tic;
wd = shift(wt,5000);
t_shift=toc;
disp(['          shift = ',num2str(t_shift),' s']);
%-------------------------------------------------------------------
tic;
wd = unspike(wt);
t_unspike=toc;
disp(['        unspike = ',num2str(t_unspike),' s']);
%-------------------------------------------------------------------