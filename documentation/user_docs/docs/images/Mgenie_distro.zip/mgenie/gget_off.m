function gget_off
%GGET_OFF
%  Clears global parameters created in gget_init
%  Ensure that the variables in the two functions are synchronised

try
    clear global isisraw_hdr isisraw_run isisraw_field
catch
    error('Error cleaning up the mgenie install')
end
