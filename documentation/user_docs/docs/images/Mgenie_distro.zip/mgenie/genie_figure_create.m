function new_figure=genie_figure_create (fig_name)
% Create a figure frame with a given name e.g. 'Genie_1D' (no white space is permitted)
% Can be used for general graphics purposes, not just mgenie.
%
%   >> new_figure = genie_figure_create (fig_name)
%
%   fig_name        Name of figure to be created. Default name is 'Genie'.
%   new_figure      =0,1 if a new figure with the desired name was opened/already existed

if isempty(fig_name)
    fig_tag = 'Genie_figure';       % default mgenie figure tag
elseif ischar(fig_name)             
    fig_tag = [fig_name,'_figure']; % tag for given mgenie figure type
elseif isstruct(fig_name) && isfield(fig_name,'tag')
    fig_tag = fig_name.tag;         % other tagged window
end

fig=findobj('Tag',fig_tag);
if isempty(fig)
    new_figure=1;
   %=== if genie figure does not exist, create a new one
    colordef white;	% white background
   % === create a new figure with 'Tag' property fig_tag
    colordef white;
    fig=figure('Tag',fig_tag,'PaperPositionMode','auto','Name',fig_name,'Color','white');	
   % === find any old figures and set current figure size to match the dimensions of the 
   % === last old figure of the same type
    oldfig=findobj('Tag',['old_',fig_tag]); 
    if ~isempty(oldfig),
        oldfig=sort(oldfig);
        set(fig,'Position',get(oldfig(end),'Position'));
    end
   % === create menu option to be able to keep figure
    h=uimenu(fig,'Label','Keep','Tag','keep','Enable','on');
    uimenu(h,'Label','Keep figure','Callback','genie_figure_keep(gcf);');
   % === create menu option to be able to make old plot cut figures current
    h=uimenu(fig,'Label','Make Current','Tag','make_cur','Enable','off');
    uimenu(h,'Label','Make Figure Current','Callback','genie_figure_make_cur(gcf);');
else % === genie figure already exists
    new_figure = 0;
  	figure(fig);
end
