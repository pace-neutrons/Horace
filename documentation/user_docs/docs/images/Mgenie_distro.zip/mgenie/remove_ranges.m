function xrem=remove_ranges(xbnd,sel)
% Return array containing lower and upper x values between which points are to be removed from fitting
%
%   >> xrem = remove_ranges (x, sel)
%
%   xbnd    Array of x coordinates (assumed monotonic increasing) that bound the data points
%          i.e. if there are n data points then x has length n+1
%   sel     Logical array, length n (the number of data points), where points to be removed
%          indicated as false
%
%   xrem    m x 2 array of x values between which to remove data points
%          i.e. [x1_lo, x1_hi; x2_lo, x2_hi; ...]
%           If no ranges to be removed, then xrem is empty

if all(sel)         % all points selected
    xrem=[];
elseif ~any(sel)    % no points selected
    xrem=[xbnd(1);xbnd(end)];
else
    jump=diff([sel(1);sel(:);sel(end)]);    % jump(i)=1 or-1 at xbnd(i) start or end of selected range
    ind=find(jump~=0);
    if jump(ind(1))==1, ind=[1;ind]; end
    if jump(ind(end))==-1, ind=[ind;numel(jump)]; end
    xrem=reshape(xbnd(ind),[2,numel(ind)/2]);
end
