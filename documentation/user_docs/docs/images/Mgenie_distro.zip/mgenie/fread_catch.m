function [data, count_out, status_ok, message] = fread_catch (fid, count_in, precision, skip, machineformat)
% Version of fread that catches errors, and allows for an error message to be passed back.
%
% Input arguments same as built-in Matlab fread
%
% To behave just as fread:
%   >> [data, count] = fread_catch (fid,...)
%
% To catch errors:
%   >> [data, count, status_ok] = fread_catch (fid)
%               status_ok = 1 if OK, =0 otherwise
%
%   >> [data, count, status_ok] = fread_catch (fid, count,...)
%               status_ok(1) = 1 if OK, =0 otherwise
%               status_ok(2) = 1 if read the requested number of elements, =0 otherwise
%
% To catch errors and return an error message:
%   >> [data, count, status_ok, message] = fread_catch (fid,...)
%               message = '' if OK, =0 otherwise 
%
%   >> [data, count, status_ok, message] = fread_catch (fid, count,...)
%               message = '' if all(status_ok(1))=1  (i.e. status_ok(1)=status_ok(2)=1)
%                       = failure message of fread if status_ok(1)=0
%                       = message indicating count discrepancy if status_ok(2)=0
%
% The purpose of fread_catch is to have a graceful way of catching errors. The most
% common use will be to return if unable to read the required number of elements or
% there is either a failure in fread, for example:
%
%   function [data, mess] = my_read_routine (fid)
%       :
%   [data, count, ok, mess] = fread (fid, [n1,n2], 'float32');
%   if ~all(ok)
%       return
%   end

% Original author: T.G.Perring
%
% $Revision: * $ ($Date: * $)
%
% Horace v0.1   J. van Duijn, T.G.Perring

try
    if nargin==1
        [data,count_out] = fread(fid);
    elseif nargin==2
        [data,count_out] = fread(fid,count_in);
    elseif nargin==3
        [data,count_out] = fread(fid,count_in,precision);
    elseif nargin==4
        [data,count_out] = fread(fid,count_in,precision,skip);
    elseif nargin==5
        [data,count_out] = fread(fid,count_in,precision,skip,machineformat);
    end
    if nargout>=3
        if nargin>=2    % count_in and count_out both given
            if prod(count_in)~=inf & prod(count_out)~=prod(count_in)
                status_ok = [1,0];
            else
                status_ok = [1,1];
            end
        else
            status_ok = 1;
        end
        if nargout==4
            if all(status_ok)
                message = '';
            else
                message = 'ERROR: Did not read the requested number of data items - check file format';
            end
        end
    end
catch
    data = [];
    count_out = [];
    if nargout>=3
        if nargin>=2    % count_in and count_out both given
            status_ok = [0,0];
        else
            status_ok = 0;
        end
        if nargout==4
            message = lasterr;
        end
    else
        error(lasterr)
    end
end
            
    
