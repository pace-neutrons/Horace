function genie_cmd (cmd)
% GENIE_CMD  Perform a GENIE command
%
global genie_handle
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% Check CMD is a single character string
if(~isa(cmd,'char') | size(cmd,1)~=1)
    error ('Input command must be a character array')
end

% Branch if a number (so spectrum) or a named item:

if ~isempty(genie_handle)
    invoke(genie_handle,'AssignHandle',cmd,'')
else
    error('Command cannot be completed because OpenGenie not found')
end

