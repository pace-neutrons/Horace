function [file_out, exists] = findfile (file_in, status)
% FINDFILE: Return the name of a file, translating any leading path name
%          or environment variable in the name.
%   e.g.
%   >> file = findfile ('data_path:map07482.raw')
%
% Syntax:
%   >> file_out = findfile (file_in)
%   >> file_out = findfile (file_in, status)
%   >> [file_out, exists] = findfile (file_in)
%   >> [file_out, exists] = findfile (file_in, status)
%
%           Checks if the form of the input file name includes a global
%          user path (see >> help set_globalpath) or environment variable:
%           - if so, translates the path or environment variable to return
%            the file name in the conventional form,
%           - if not, then the file name is returned unchanged.
%
%           If the input filename includes a user path or environment
%          variable, then the returned file name depends on whether or not
%          the name of a currently existing file or a new file is wanted:
%
%           - status = 'new': Return file is in the first directory
%                            contained in the path
%           - status = 'old': Return file is the first currently existing
%                            file found on the path. If one is not found
%                            then the output file is returned unchanged
%           - status = 'unknown': [Default] Return name of existing file, 
%                            if one found, else return new file name
%
%           In all cases, the existence status is reported.
%
%
% Example:
%   >> set_globalpath('maps_dir','c:\temp','t:\experiments')
%   >> file_out = findfile ('maps_dir:my_data.dat')
%

% *** CARE MUST BE TAKEN TO ENSURE THAT THIS ROUTINE AND DIRPATH ARE CONSISTENT

% Check input arguments
if nargin<1
    error ('ERROR: Check number of arguments to findfile')
end

if ~(isa(file_in,'char') & size(file_in,1)==1 & length(file_in)>0)
    error ('ERROR: Filename must be a character string')
end
newfile = 0;
oldfile = 0;
unknown = 0;
if nargin==2
    if ~(isa(status,'char') & size(status,1)==1 & length(status)>0)
        error ('ERROR: Status argument must be a character string')
    elseif ~(strcmp(lower(status),'old')|strcmp(lower(status),'new')|strcmp(lower(status),'unknown'))
        error ('ERROR: Status flag must be ''new'' or ''old''')
    elseif strcmp(lower(status),'old')
        oldfile = 1;
    elseif strcmp(lower(status),'new')
        newfile = 1;
    else
        unknown = 1;
    end
else
    unknown = 1;
end

% default return arguments
file_out = '';
exists = 0;

% Find out if file_in has form nnn:mmm
[path_name, file_name] = pathstrip(file_in);

file_new = '';
if ~isempty(path_name)
    % name includes a global path or environment variable
    % check if path is a global user path
    [path, mess] = get_globalpath(path_name);
    if isempty(mess)   % is a global user path
        p = getuserpath(path);
        if length(p)>0 % path not empty
            for i=1:length(p)
                if exist(p{i},'dir')==7   % check directory exists
                    file_out = fullfile(p{i},file_name);
                    if exist(file_out,'dir')==0 & exist(file_out,'file')==2 % check is a file but not a directory
                        exists = 1;
                    end
                    if exists|newfile
                        return
                    elseif unknown & isempty(file_new)
                        file_new = file_out;
                    end
                end
            end
        end
    end
    % check if path is an environment variable pointing to a directory
    trans = getenv(path_name);
    if exist(trans,'dir')==7
        file_out = fullfile(trans,file_name);
        if exist(file_out,'dir')==0 & exist(file_out,'file')==2
            exists = 1;
        end
        if exists|newfile
            return
        elseif unknown & isempty(file_new)
            file_new = file_out;
        end
    end
    if unknown & ~isempty(file_new)
        file_out = file_new;
        return
    end
end

% The only way this point could have been reached is that
% A path was specified, but:
%   - the path is invalid (e.g. neither global userpath nor environment variable exist, or global userpath is empty,
%     or the directories they point to do not exist
%   - the request was for an existing file, but which was not found on the path.
% 
% or the file did not have the format of path:name

% Catch all other cases
file_out = file_in;
if exist(file_out,'dir')==0 & exist(file_out,'file')==2
    exists = 1;
end


