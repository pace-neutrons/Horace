function w = read_spefile (file)
% READ_SPE Reads an .SPE file into an array of MGENIE spectra.
%
% Syntax:
%   >> w = read_spefile (file)    % read from named file
%   >> w = read_spefile           % prompts for file
%
%   w(1) is first spectrum, w(2) is second etc.
%

% Get file name - prompt if file does not exist (using file to set default seach location and extension
% -----------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.spe');
end
if (isempty(file_internal))
    error ('No file given')
end

% Read spe file
% --------------------
spe = get_spe(file_internal);
w = spe_to_spectrum(spe);

