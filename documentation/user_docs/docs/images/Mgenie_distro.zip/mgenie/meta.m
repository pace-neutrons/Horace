function meta(figno)
% Make a copy of the current figure to meta file. On windows, this
% puts the file in the clipboard so can be pasted directly into Word, Powerpoint etc.
%
%   >> meta(fig_number)     % meta file from given figure
%   >> meta                 % current figure

if ~exist('figno','var')
    figno=gcf;
    if isempty(figno)
        error('No current figure - cannot create meta file')
    end
end

print('-dmeta','-noui',['-f',num2str(figno)]);
