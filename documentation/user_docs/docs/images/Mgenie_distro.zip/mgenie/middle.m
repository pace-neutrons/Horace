function xout = middle (x)
% MIDDLE    Take array assumed to be bin boundaries and return bin centres
%
%   xcentre = middle (xboundaries)
%

if (isa(x,'double') & ndims(x)==2 & min(size(x))==1 & max(size(x))>1)
    nx = length(x);
    xout = 0.5.*(x(2:nx)+x(1:nx-1));
else
    error ('Check length of array or data type')
end
    