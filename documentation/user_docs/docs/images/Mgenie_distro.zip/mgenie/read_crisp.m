function w = read_crisp (varargin)
% READ_CRISP reads 'up' and 'down' crisp data files into a pair of mgenie spectra
%
% Syntax:
% Full form:
%   >> w = read_crisp           % prompts for files; tries to determine if hist or point
%   >> w = read_crisp (type)                    % prompts for files
%   >> w = read_crisp (file_up, file_down)      % tries to determine if hist or point
%   >> w = read_crisp (file_up, file_down, type)
%
%   file_up     Name of file containing 'up' data
%   file_down   Name of file containing 'down' data
%   type        'histogram' or 'point': enforce interpretation of data as histogram or point
%              data. Default is to try to determine from the file format,
%              but interpretation is often ambiguous !
%   w           Array of mgenie spectra; w(1)=up spectrum, w(2)=down spectrum
%
%

file_up = '';
file_down = '';
type = 'unknown';

if nargin==1
    type = varargin{1};
elseif nargin==2
    file_up = varargin{1};
    file_down = varargin{2};
elseif nargin==3
    file_up = varargin{1};
    file_down = varargin{2};
    type = varargin{3};
end

if ~isa(type,'char')|~isa(file_up,'char')|~isa(file_down,'char')
    error ('Check argument(s) are character strings')
end


% Get type
% --------
ind = string_find(lower(type),{'histogram','point','unknown'});
if ind==1
    type = 'histogram';
elseif ind==2
    type = 'point';
elseif ind==3
    type = 'unknown';
else
    error ('Type must be ''histogram'', ''point'', ''unknown'' or an abbreviations of one')
end
    

% Get file names - prompt if file does not exist (using file to set default seach location and extension)
% -------------------------------------------------------------------------------------------------------
if strcmp(type,'histogram')
    if isempty(file_up); w(1)=read_hist; else; w(1)=read_hist(file_up); end;
    if isempty(file_down); w(2)=read_hist; else; w(2)=read_hist(file_down); end;
elseif strcmp(type,'point')
    if isempty(file_up); w(1)=read_point; else; w(1)=read_point(file_up); end;
    if isempty(file_down); w(2)=read_point; else; w(2)=read_point(file_down); end;
elseif strcmp(type,'unknown')
    if isempty(file_up); w(1)=read_ascii; else; w(1)=read_ascii(file_up); end;
    if isempty(file_down); w(2)=read_ascii; else; w(2)=read_ascii(file_down); end;
end

% Now perform some checks on the data
% -------------------------------------
nx(1) = length(get(w(1),'x'));
ny(1) = length(get(w(1),'y'));

nx(2) = length(get(w(2),'x'));
ny(2) = length(get(w(2),'y'));

if nx(1)~=nx(2)
    disp('WARNING: lengths of up and down spectra are not the same')
end
if (nx(1)-ny(1))~=(nx(2)-ny(2))
    disp('WARNING: One spectrum is histogram, the other point')
end
