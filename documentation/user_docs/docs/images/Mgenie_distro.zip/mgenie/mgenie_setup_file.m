function mgenie_setup_file (filename)
% Set the user-supplied initialisation file name for mgenie. Ignored if the
% named file does not exist
%
% Syntax:
%   >> mgenie_setup_file (filename)
% 
global genie_setup_file

if nargin==1
    if isa(filename,'char') & size(filename,1)==1
        if (exist(filename)==2)
            genie_setup_file = filename;
        else
            disp (['Warning: mgenie setup file ',filename,' not found'])
            disp ( 'Mgenie setup file name left unchanged.')
            return
        end
    else
        disp ('ERROR: Check mgenie setup file name.')
        disp ( 'Mgenie setup file name left unchanged.')
    end
end


% Display the current mgenie setup file name:
if (~isempty(genie_setup_file))
    if (isa(genie_setup_file,'char') & size(genie_setup_file,1)==1)
        if (exist(genie_setup_file)==2)
            disp (['Mgenie setup file: ',genie_setup_file])
        else
            disp (['Warning: mgenie setup file ',genie_setup_file,' not found'])
        end
    else
        disp ('Warning: variable named "genie_setup_file" is not a single character string')
    end
else
    disp ('Mgenie setup file name not set')
end
          