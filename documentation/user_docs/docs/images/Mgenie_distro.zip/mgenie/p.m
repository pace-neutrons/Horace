function [] = p (w)
% Plots of a spectrum or array of spectra on an existing plot, drawing
% line, error bars and markers.
%
% Syntax:
%   >> p w1

global genie_max_spectra_1d

if nargin == 0
    error ('ERROR - supply missing arguments')
end

if nargin == 1
    try
        w_temp = evalin('caller',w);
    catch
        w_temp = w;
    end
    if (~isa(w_temp,'spectrum'))
        error 'Must provide a spectrum to be plotted')
    end
    % Check spectrum is not too long an array
    if length(w)>genie_max_spectra_1d
        error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
    end
else
    error ('Check number of input arguments')
end
    
pe(w_temp)
pm(w_temp)
pl(w_temp)