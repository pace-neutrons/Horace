function wout=cut_to_spectrum(cut)
% Convert a cut data structure into a spectrum
%
%   >> wout=cut_to_spectrum(cut)
%
%   cut     Cut data structure as read in by get_cut
%
%   wout    Mgenie spectrum. Will be point spectrum

if (isfield(cut,'emode'))   % use the presence of this field to determine if trailing info. appears in cut file
    wout = spectrum(cut.x, cut.y, cut.e, cut.title, cut.x_label, cut.y_label);
else
    wout = spectrum(cut.x, cut.y, cut.e);
    wout = set(wout,'title',file_internal);
    wout = set(wout,'title',avoidtex(file_internal));
end
