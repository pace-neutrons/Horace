function output=ixf_default_properties(varargin)
% ------------- help for GTK default_properties----------------------------
%
% syntax: 
%   >> ixf_default_props('set','variable',variable_value)
% 
%   >> output = ixf_default_props('get')
%   >> output = ixf_default_props('get','variable')
% 
% inputs: 'set/get' can be either 'set' or 'get' depending if you wish to
% set a variable or retrieve it's value, 'variable' the name of the
% variable you wish to set (or get), variable_value - the value of the
% variable you're setting (if set).
%
% output: the value of the variable if using get
%
% default_properties('get') displays a list of current stored variables
%
%--------------11/09/2006, Dean Whittaker----------------------------------
mlock;
persistent var_list         % list of the variables put into the mfile
var_list_flag = true;
 
if nargin==0
    output=var_list';
elseif nargin==1
    switch varargin{1}
        case 'set'
            error('require a variable to set')
        case 'get'
            output=var_list';
        otherwise
            error('incorrect set/get type')
    end
else
    if~isempty(var_list)
        for i=1:length(var_list)
            if strcmp(var_list{i},varargin{2})
                var_list_flag=false;
            end
        end
    end

    if nargin==2
        eval(['persistent ' varargin{2}]);
        switch varargin{1}
            case 'set'
                eval([varargin{2}, ' =[];'])
                if var_list_flag
                var_list=[var_list,{varargin{2}}];
                end
            case 'get'
                if exist(varargin{2},'var')
                    eval(['output = ' varargin{2} ';']);
                else
                    error('variable does not exist');
                end
            otherwise
                 error('incorrect set/get type');
        end
    elseif nargin==3
        eval(['persistent ' varargin{2}]);
        switch varargin{1}
            case 'set'
                eval([varargin{2} ' = varargin{3};']);
                if var_list_flag
                var_list=[var_list,{varargin{2}}];
                end
            case 'get'
                error('too many input arguments for get function');
            otherwise
                 error('incorrect set/get type');
        end
    end
end