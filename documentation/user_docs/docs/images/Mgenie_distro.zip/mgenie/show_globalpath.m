function show_globalpath (name)
% SHOW_GLOBALPATH    Display the global user path
%
% Syntax:
%   >> show_globalpath (name)   % name is a character string containing the
%                               % name of the global user path

% check name of global user path
if nargin < 1
    s = whos('global');
    n = 0;
    for i=1:length(s)
        if strcmp(s(i).class,'userpath')
            if n==0
                disp('Global user paths currently defined:')
                n=1;
            end
            disp(['     ',s(i).name])
        end
    end
    if n==0
        disp('No global user paths currently defined')
    end
    disp(' ')
end

if nargin >= 1
    if ischar(name) & length(name)>0 & size(name,1)==1
        if isvarname(name)
            path = get_global(name);
            if isa(path,'userpath')
                p = getuserpath(path);
                if length(p)==0
                    disp (['Path ''',name,''' is empty'])
                else
                    disp (['Path ''',name,''' has entries:'])
                    for i=1:length(p)
                        disp(['     ',p{i}])
                    end
                end
            else
                error (['ERROR: Global user path ''',name,''' does not exist.'])
            end
        else
            error (['ERROR: Invalid name for a global user path: ''',name,''''])
        end
    else
        error ('ERROR: Invalid argument type for a global user path name')
    end
end
