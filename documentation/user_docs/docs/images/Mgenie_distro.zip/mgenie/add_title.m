function out_title = add_title (title, more_title, n)
% ADD_TITLE  Given a title suitable as a field of a spectrum, append further
%            lines to the title.
%
%   >> title = add_title (title, more_title,where)
%   title       Character string, array of character strings, or cell array
%   more_title  Further title to be added to original title
%   where       Optional argument to indicate where the further title is inserted
%                   = n (integer 1,2,3,...)  insert so additional title starts at line n
%               Blank lines are inserted to ensure that the new title always starts at line n
%               If n<0 is equivalent to n=1.
%               If omitted, then the further title is appended at the end of the title
%

% Check input arguments
if ~(iscellstr(title)|ischar(title))
    error ('ERROR: Title must be a cellstr or character array')
end
if ~(iscellstr(more_title)|ischar(more_title))
    error ('ERROR: Material to be added to label not a cellstr or character array')
end
if nargin==3
    if ~isnumeric(n)
        error ('ERROR: Insertion position must be numeric')
    end
    npos = round(n(1,1));
    if npos < 1
        npos = 1;
    end
else
    npos = 0;   % zero will be used later to signal that the extra titling is appended
end

% Produce new output title
if isempty(title)
    out_title = more_title;
else
    title = cellstr(title);     % ensure is a cellstr
    more_title = cellstr(more_title);
    lt = length(title);
    if npos==1
        out_title = [more_title;title];
    elseif npos==lt+1 | npos==0
        out_title = [title;more_title];
    elseif npos <= lt
        out_title = [title(1:npos-1);more_title;title(npos:lt)];
    else
        out_title = [title;repmat({''},npos-lt-1,1);more_title];
    end
end
