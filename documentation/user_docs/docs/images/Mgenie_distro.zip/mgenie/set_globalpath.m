function mess_out = set_globalpath (name, varargin)
% SET_GLOBALPATH    Set or change the value of the named global user path
%
% e.g.
%   >> set_globalpath('some_stuff','t:\f90','t:\my_progs');
%   >> set_globalpath('map_path','c:\temp;c:\my_progs','some_stuff');
%
%
% Syntax
%   >> set_globalpath (name, path1, path2,...)
%
%   name : the name of the userpath to be set or altered (character string)
%
%   path1, path2, ...:  are valid paths, i.e.
%    - A character string containng a directory name e.g. 'c:\temp\my_work'
%
%    - A valid matlab path i.e. a character string containing a series of
%     directory names separated by the (platform-specific) path separator
%     On windows the separator is ';' so 'c:\temp;c:\my_progs' is valid.
%
%    - A character string containng the name of a system  environment
%     variable. Note that environment variables are translated at the time
%     of the call to userpath, hence subsequent changes to the environment
%     variable using SETENV will not propagate to the user path.
%
%    - A character string containing the name of a global user path
%     defined by set_globalpath (including that given by the first parameter
%     i.e. 'name')
%     
%
%    - A previously defined user path created with userpath
%
%
%   The output pathname is constructed in the order of the input arguments
%  and this will define the order files are searched for.
%
%   To add paths to a global user path, the name used as the first argument
%  can appear as one of path1, path2 ...
%
% See also:
%   adduserpath, clear_userpath, show_globalpath

% Determine failure mode and default return algorithm
if nargout==1; fail_on_error=0; else; fail_on_error=1; end
mess='';

% check name of global user path
if nargin < 1
    mess = 'ERROR: Must give name of global user path that is to be defined';
    if fail_on_error; error(mess); else; mess_out=mess; return; end
end

if nargin >= 1
    if ischar(name) & length(name)>0 & size(name,1)==1
        if isvarname(name)
            if isempty(who(name,'global')) & ~isempty(getenv(name))
                disp ( 'WARNING: A global user path will be created with the same name')
                disp (['        as a system environment variable (''',name,''').'])
                disp ( '         The user path will have precedence in any file name.')
                disp (' ')
                disp (['         Type >> clear_globalpath(',name,') to delete the global userpath.'])
                disp (' ')
            end
        else
            mess = ['ERROR: Invalid name for a global user path: ''',name,''''];
            if fail_on_error; error(mess); else; mess_out=mess; return; end
        end
    else
        mess = 'ERROR: Invalid argument type for a global user path name';
        if fail_on_error; error(mess); else; mess_out=mess; return; end
    end
end

nargs = nargin - 1; % number of elements in varargin
[path,mess] = userpath(varargin);
if ~isempty(mess)
    if fail_on_error; error(mess); else; mess_out=mess; return; end
end
set_global(name,path);
if nargout==1;mess_out=mess;end