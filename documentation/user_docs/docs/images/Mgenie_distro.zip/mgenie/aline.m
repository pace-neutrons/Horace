function [] = aline(varargin)
% ALINE: Change the line type (given by character string) and width in MGENIE plots.
%
% Syntax examples:
%	>> aline(2)
%	>> aline(0.5,':')
%   >> aline('-.')
%	>> aline('-',10)    *** NOT VALID IN COMMAND LINE MODE
%
% Arguments can set a sequence of type and/or size for cascade plots e.g.
%   >> aline (1,2,':','-','-.')
%   >> aline ({'-','--'},1:0.5:4)   % example with a cell array
%
%        Valid line types: type either the Matlab code or text equivalent (as minimum abbreviations)
%                  '-'      solid
%                  '--'     dashed
%                  ':'      dotted
%                  '-.'     ddot (dashed-dot)
%
%        Line width is in points (default size is 0.5)

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

% Create two row vectors, of line widths and line styles:
n = length(varargin);
if n < 1
    genie_line_width
    genie_line_style
    return
end
nwidth = 0;
line_width = [];
ntype = 0;
line_type =[];
for i = 1:n
    try
        temp = evalin('caller',varargin{i});
    catch
        temp = varargin{i};
    end
    if isa_size(temp,'vector','numeric')
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        line_width = [line_width,temp];
    elseif isa_size(temp,'vector','cellstr')
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        line_type = [line_type,temp];
    elseif isa(temp,'char') && length(size(temp))==2
        temp=strtrim(cellstr(temp));
        if size(temp,1)>1; temp=temp'; end  % make argument a row vector
        line_type = [line_type,temp];
    else
        error ('Check argument type(s)')
    end
end

% check validity of input arguments
if length(line_width)>0
    if min(line_width) >= 0.1 & max(line_width) <= 50
        genie_line_width = line_width;
    else
        error ('Line width is too small or too large - left unchanged (aline)')
    end
end

lstyle_char = {'-','--',':','-.'};
lstyle_name = {'solid','dashed','dotted','ddot'};
if length(line_type)>0
    for i=1:length(line_type)
        itype = string_find (line_type{i}, lstyle_char);
        if itype == 0
            itype = string_find (line_type{i}, lstyle_name);
        end
        if itype>0
            line_type(i) = lstyle_char(itype);
        elseif itype==0
            error ('Invalid line style - left unchanged (aline)')
        elseif itype<0
            error ('Ambiguous abbreviation of line style - left unchanged (aline)')
        end
    end
    genie_line_style = line_type;
end
