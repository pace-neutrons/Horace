function write_mask(varargin)
% Write array or arrays of masked spectra to ascii file
%
% Syntax:
%   >> write_mask (mask_arr)                    % prompts for file to write to
%   >> write_mask (mask_arr1, mask_arr_2,...)           
%
%   >> write_mask (mask_arr, file)              % write to named file
%   >> write_mask (mask_arr_1, mask_arr_2, ..., file)     
% 
%   mask_arr    Write an array of integers to ascci file in mask file format i.e.
%               where a sequence of integers m,m+1,m+2,... n  will be written m-n
%
%   file        File name

% Get file name - prompting if necessary
% --------------------------------------
if isempty(varargin)
    error('No arguments provided')
end
    
if ~ischar(varargin{end})   % last argument is not character array
    file_internal = genie_putfile;
    if (isempty(file_internal))
        error ('No file given')
    end
    narr=numel(varargin);
else
    file_internal = varargin{end};
    narr=numel(varargin)-1;
end

% Make arrays a single array
% ---------------------------
for i=1:narr
    varargin{i}=varargin{i}(:)';   % ensure each array is a row vector
end
varargin=varargin(:)';    % ensure row vector
mask=unique(cell2mat(varargin(1:narr)));
str_mask=iarray_to_str(mask);


% Write data to file
% ------------------
fid = fopen (file_internal, 'wt');
if (fid < 0)
    error (['ERROR: cannot open file ' file_internal])
end
for iline=1:numel(str_mask)
    fprintf (fid, '%s\n', str_mask{iline});
end
fclose(fid);
