function wout = interp(w,xi,method,extrap)
% interp    interpolates a spectrum, The output is a point spectrum
%           regardless of the input spectrum being point or histogram.
%
% Syntax:
%   >> wout = interp(w,xi,method,'extrap')
% *OR*
%   >> wout = interp(w,xi,method,extrapval)
%
%   w           Input spectrum
%
%   xi          Values at which interpolated values will be calculated
%               *OR*
%               Another spectrum at from which the x values will be taken
%
%   method          'nearest'   Nearest neighbor interpolation
%                   'linear'    Linear interpolation (default)
%                   'spline'    Cubic spline interpolation
%                   'pchip'     Piecewise cubic Hermite interpolation
%                   'cubic'     (Same as 'pchip')
%                   'v5cubic'   Cubic interpolation used in MATLAB 5
%
%   'extrap'    Extrapolates using the given method. If not given, then
%               the Matlab default behaviour is followed:
%                   no extrapolation: 'nearest', 'linear', 'v5cubic'
%                   extrapolation:    'spline', 'pchip', 'cubic'
%
%   extrapval   Value given to out-of-range points - NaN or 0 often used
%
%
% The behaviour is the same as the Matlab interp1, except that keywowrds
% can be abbreviated to the minimum unambiguous string

% Check input arguments:
if nargin<2; error('Check number of arguments to interp'); end

if isa(xi,'spectrum')
    if length(xi.x)~=length(xi.y)
        xout = 0.5*(xi.x(1:end-1)+xi.x(2:end));
    else
        xout = xi.x;
    end
elseif isa_size(xi,'vector','double')
    xout = xi;
else
    error ('Check interpolating values a numeric vector')
end

methods = {'nearest','linear','spline','pchip','cubic','v5cubic'};
if nargin>=3
    if ~isa_size(method,'row','char'); error('Check interpolation method is a string'); end
    imethod = string_find(lower(method),methods);
    if imethod==0; error('Unrecognised interpolation method'); end
    if imethod<0; error('Ambiguous interpolation method'); end
end

if nargin>=4
    if ~(isa_size(extrap,'row','char') && string_find(lower(extrap),{'extrap'})) & ~isa_size(extrap,[1,1],'double')
        error('Check extrapolation parameter')
    end
end

if length(w.x)~=length(w.y) % hisogram data
    xcent = 0.5*(w.x(1:end-1)+w.x(2:end));
else
    xcent = w.x;
end

if nargin==2
    yout = interp1(xcent, w.y, xout);
elseif nargin==3
    yout = interp1(xcent, w.y, xout, method);
elseif nargin==4
    yout = interp1(xcent, w.y, xout, method, extrap);
end

wout = spectrum(xout,yout,zeros(size(yout)),w.title,w.xlab,w.ylab,w.xunit,w.distribution);











