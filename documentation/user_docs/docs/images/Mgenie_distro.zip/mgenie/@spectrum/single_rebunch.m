function [wout] = single_rebunch(win,nbin_in)
% SPECTRUM/SINGLE_REBUNCH - rebunch data points into groups of n (single spectrum version)
%
% Syntax:
%
%   >> w_out = rebunch(w_in, nbin)   rebunches the data of W_IN in groups of nbin
%
%   >> w_out = rebunch(w_in)         same as NBIN=1 i.e. W_OUT is just a copy of W_IN
%

small = 1.0e-10;
if (nargin >= 1)
    if (~isa(win,'spectrum'))      % check if first argument is also a spectrum
        error ('Check first argument is a spectrum (REBUNCH)')
    end
end

if (nargin == 2)
    if (~(isa(nbin_in,'double') & length(nbin_in)==1 & (abs(nbin_in-round(nbin_in))<small)) & nbin_in > 0)    % check 2nd argument a single number
        error ('Check second argument is a whole number greater or equal to unity (REBUNCH)')
    end
    nbin = round(nbin_in);
else
    error ('Only two arguments (W_IN, NBIN) in REBUNCH')
end

% Catch trivial case
% ----------------------
if ((nargin == 1) | (nargin==2 & nbin==1))
    wout=win;
    return
end

% non-trivial rebunching (note that the following algorithm does not work if NBIN=1 - fails in SUM)
% -------------------------------------------------------------------------------------------------
ny=length(win.y);
nx=length(win.x);

my_total=floor((ny-1)/nbin) + 1;    % total number of bins in rebunched array
my_whole=floor(ny/nbin);            % number of rebunched bins with NBIN bins contributing from original array

%---------------------------------------------------------------------------------------------    
if nx~=ny   % histogram data
    xin_bins=win.x(2:ny+1)-win.x(1:ny);
    ytemp=win.y.*xin_bins;
    etemp=win.e.*xin_bins;

    xout=[win.x(1:nbin:nx-1)',win.x(nx)];
    xout_bins=xout(2:my_total+1)-xout(1:my_total);
    yout=zeros(1,my_total);
    eout=zeros(1,my_total);
    if (my_total-my_whole ~=0) % 1 or more leftover values at end of array
        yout(my_total)=sum(ytemp(my_whole*nbin+1:ny));
        eout(my_total)=sqrt(sum(etemp(my_whole*nbin+1:ny).^2));
    end
    if (my_whole ~= 0)         % 1 or more completely filled new bins
        yout(1:my_whole)=sum(reshape(ytemp(1:my_whole*nbin),nbin,my_whole));
        eout(1:my_whole)=sqrt(sum(reshape(etemp(1:my_whole*nbin).^2,nbin,my_whole)));
    end
    yout=yout./xout_bins;
    eout=eout./xout_bins;
%---------------------------------------------------------------------------------------------    
else        % point data
    xout=zeros(1,my_total);
    yout=zeros(1,my_total);
    eout=zeros(1,my_total);
    if (my_total-my_whole ~=0) % 1 or more leftover values at end of array
        xout(my_total)=sum(win.x(my_whole*nbin+1:ny))/(ny-my_whole*nbin);
        yout(my_total)=sum(win.y(my_whole*nbin+1:ny))/(ny-my_whole*nbin);
        eout(my_total)=sqrt(sum(win.e(my_whole*nbin+1:ny).^2))/(ny-my_whole*nbin);
    end
    if (my_whole ~= 0)         % 1 or more completely filled new bins
        xout(1:my_whole)=sum(reshape(win.x(1:my_whole*nbin),nbin,my_whole))/nbin;
        yout(1:my_whole)=sum(reshape(win.y(1:my_whole*nbin),nbin,my_whole))/nbin;
        eout(1:my_whole)=sqrt(sum(reshape(win.e(1:my_whole*nbin).^2,nbin,my_whole)))/nbin;
    end
%---------------------------------------------------------------------------------------------    
end

wout=spectrum(xout,yout,eout, win.title, win.xlab, win.ylab, win.xunit, win.distribution);