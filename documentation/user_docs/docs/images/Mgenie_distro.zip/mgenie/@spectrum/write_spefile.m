function write_spefile(w,file)
% WRITE_SPE writes an array of spectra in .SPE file format
%
% Can be read back into Mgenie with the function READ_SPEFILE
%
% Syntax:
%   >> write_spefile (w)           % prompts for file to write to
%   >> write_spefile (w, file)     % write to named file
%


% Check that all the spectra have the same length, and are histogram data, and distributions
% -------------------------------------------------------------------------------------------
ndet = size(w,2);
for i=1:ndet
    nx_arr(i)=length(get(w(i),'x'));
    ny_arr(i)=length(get(w(i),'y'));
    h_arr(i)=get(w(i),'distribution');
end
if (min(nx_arr)==max(nx_arr))
    ne = nx_arr(1)-1;
else
    error('Not all spectra have the same length')
end
if (min(nx_arr-ny_arr)==0)
    error('Check all spectra are histogram data')
end
if (min(h_arr)==0)
    error('Check all spectra are distributions')
end


% Get file name - prompting if necessary
% --------------------------------------
if (nargin==1)
    file_internal = genie_putfile('*.spe');
    if (isempty(file_internal))
        error ('No file given')
    end
elseif (nargin==2)
    file_internal = file;
end

% Build data structure for service write routine
data.S=cell(ndet,1);
for i=1:ndet
    data.S=get(w(i),'y');
    data.ERR=get(w(i),'e');
end
data.en=get(w(1),'x');

save_spefile(data,file_internal);
