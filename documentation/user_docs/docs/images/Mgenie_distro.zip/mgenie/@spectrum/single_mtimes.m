function wout = single_mtimes(w1,w2)
% SPECTRUM/MTIMES  Implement w1 * w2 for spectra
%
%   >> w = w1 * w2
%
%   If w1, w2 are spectra:
%       the operation is performed element-by-element
%   if one of w1 or w2 is a double:
%       the operation is applied to each element of the spectrum

small = 1.0e-10;

if (isa(w1,'spectrum') & isa(w2,'spectrum'))
    if length(w1.x) == length(w2.x)
        if abs(max(w1.x-w2.x)) < small
            [ok, title, xlab, ylab, xunit, distribution] = binary_operation_ok (w1,w2);
            if (ok>0)            
                wout.x = w1.x;
                wout.y = w1.y .* w2.y;
                t1 = w1.y.*w2.e;
                t2 = w2.y.*w1.e;
                wout.e = sqrt(t1.^2+t2.^2);
                wout.title = title;
                wout.xlab = xlab;
                wout.ylab = ylab;
                wout.xunit = xunit;
                wout.distribution = distribution;
            else
                error ('inconsistent units in spectra to be multiplied')
            end
        else
            error ('x arrays are not equal')
        end
    else
        error ('Length of spectra are different')
    end
elseif (isa(w1,'spectrum') & isa(w2,'double'))
    wout.x = w1.x;
    wout.y = w2*w1.y;
    wout.e = w2*w1.e;
    wout.title = w1.title;
    wout.xlab = w1.xlab;
    wout.ylab = w1.ylab;
    wout.xunit = w1.xunit;
    wout.distribution = w1.distribution;
elseif (isa(w2,'spectrum') & isa(w1,'double'))
    wout.x = w2.x;
    wout.y = w1*w2.y;
    wout.e = w1*w2.e;
    wout.title = w2.title;
    wout.xlab = w2.xlab;
    wout.ylab = w2.ylab;
    wout.xunit = w2.xunit;
    wout.distribution = w2.distribution;
else
    error ('multiplication of spectra and reals only defined')
end
wout = class(wout,'spectrum');
        