function wout = func_eval (w, func_handle, varargin)
% SPECTRUM/FUNC Evaluate a function at the x values of a spectrum or array of spectra)
% Syntax:
%   >> wout = func_eval (w, func, arg1, arg2,...)
%
%   w               Spectrum or array of spectra at which the function
%                  will be evaluated
%   func            Function to be evaluated at the x values of the spectra
%                  in w. Function must be of form y = my_func(x,arg1,arg2,...)
%                       e.g. y = gauss (x, [height, cent, sig])
%                  and must accept an array of x values, returning an array of
%                  y values.
%   arg1,arg2...    Arguments needed by the function. Typically there is only
%               one argument, which is a numeric array, as in the example above
%
%   wout            Output spectrum or array of spectra
%
% e.g.
%   >> wout = func_eval (w, @gauss, [height, cent, sig])
%
%   where the function gauss appears on the matlab path
%           function y = gauss (x, p)
%           y = (p(1)/(sig*sqrt(2*pi))) * exp(-0.5*((x-p(2))/p(3)).^2);

wout = w;

% Construct function line
n = nargin - 2;
if n > 0    % optional arguments were passed
    str = [];
    for i=1:n
        str = [str,[',varargin{',num2str(i),'}']];
    end
    command = ['func_handle(xtemp',str,')'];
else
    command = 'func_handle(xtemp)';
end

% evaluate function
for i=1:length(w)
    if length(w(i).x)==length(w(i).y)
        xtemp = w(i).x;
    else
        xtemp = 0.5*(w(i).x(2:end)+w(i).x(1:end-1));
    end
    wout(i).y = eval(command);
    wout(i).e = zeros(size(w(i).e));
end