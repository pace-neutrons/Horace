function [ok, title, xlab, ylab, xunit, distribution] = binary_operation_ok (w1,w2)
% Checks if binary operation on spectra is OK.
% Returns OK = 0 if not, =1 or 2 for the spectrum number from which the title etc. are taken
%
% The value of xunit is the sole determinant of validity:
%   - if neither spectrum has units, take properties from first
%   - if only one spectrum has units, use those
%   - if both do, then check that units are the same, and take properties from first spectrum

if (strcmp(w1.xunit,'') & strcmp(w2.xunit,''))
    ok = 1;  % take titles etc. from first spectrum if units blank for both spectra
elseif (strcmp(w1.xunit,''))
    ok = 2;  % take titles etc. from second spectrum if units blank for first spectrum only
elseif (strcmp(w2.xunit,''))
    ok = 1;  % take titles etc. from first spectrum if units blank for second spectrum only
else
    if (strcmp(w1.xunit,w2.xunit))   % units must be equal if both non-blank
        ok = 1;  % ? take titles etc. from the one that is a distribution instead of the first spectrum ?
    else
        ok = 0;
    end
end

if(ok==0)
    title = '';
    xlab = '';
    ylab = '';
    xunit = '';
    distribution = '';
elseif (ok==1)
    title = w1.title;
    xlab = w1.xlab;
    ylab = w1.ylab;
    xunit = w1.xunit;
    distribution = w1.distribution;
elseif (ok==2)
    title = w2.title;
    xlab = w2.xlab;
    ylab = w2.ylab;
    xunit = w2.xunit;
    distribution = w2.distribution;
end
