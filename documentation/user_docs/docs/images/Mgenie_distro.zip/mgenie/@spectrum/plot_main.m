function [] = plot_main (newplot, type, fig_name, w_in, xlo, xhi, ylo, yhi)
%SPECTRUM/PLOT_MAIN Draw a spectrum 

global genie_binning

% Create new graphics window if one does not currently active
new_figure = genie_figure_create (fig_name);
if new_figure
    newplot=1;  % if had to create a new figure window, then create axes etc.
end

% if plot over, hold existing plot
if (~newplot)
    hold on;
else
    delete(gca)
end

% make a copy of w_in for manipulations inside plot routines

if (round(genie_binning) == 1)
    w = w_in;
else
    w = rebunch(w_in,round(genie_binning));
end

% plot data
if (type=='h')
    plot_histogram (w);
elseif (type=='e')
    plot_errors (w)
elseif (type=='l')
    plot_line (w)
elseif (type=='m')
    plot_markers (w)
end
    
% create/change title if a new plot
if (newplot)
 % change titles:
    [tt,tx,ty] = graph_titles(w(1).title,w(1).xlab,w(1).ylab,w(1).xunit,w(1).distribution,genie_binning);
    title(tt);
    xlabel(tx);
    ylabel(ty);
 % calculate space for titles:
    % no cells in titles:
    nt = prod(size(tt));
    nx = prod(size(tx));
    ny = prod(size(ty));
    % units per single height of line (quick fix assuming default aspect ratio and font size)
    h = 0.03833;
    % allow for up to 4 lines in tx and ty, and 5 lines in tt:
    xplo=min(0.13+(ny-1)*h,0.245);  yplo=min(0.11+(nx-1)*h,0.225);  xphi=0.905;   yphi=max(0.925-(nt-1)*h,0.772);
    pos = [xplo,yplo,xphi-xplo,yphi-yplo];
    set(gca,'position',pos)
end

% change limits if they are provided
if (exist('xlo','var') & exist('xhi','var'))
    if (isa(xlo,'double') & isa(xhi,'double'))
        set (gca, 'XLim', [xlo xhi])
    else
        error ('Wrong argument types for xlo, xhi')
    end
end

if (exist('ylo','var') & exist('yhi','var'))
    if (isa(ylo,'double') & isa(yhi,'double'))
        set (gca, 'YLim', [ylo yhi])
    else
        error ('Wrong argument types for ylo, yhi')
    end
end

% if plot over, release plot again
if (~newplot)
    hold off;
end
