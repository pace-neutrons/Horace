function w = mrdivide (w1, w2)
% SPECTRUM/MRDIVIDE  Implement w1 / w2 for spectra
%
%   >> w = w1 / w2
%
%   If w1, w2 are spectra:
%       the operation is performed element-by-element
%   if one of w1 or w2 is a double:
%       the operation is applied to each element of the spectrum
%
%   w1, w2 can be arrays:
%       - if same length, then added element-by-element
%       - if one is an array of length one, or a scalar, then take
%         difference with respect to every element of the other.

% Template of a binary operator that can take array-valued arguments

len1 = length(w1);
len2 = length(w2);
if (len1==len2 & len1==1)
    w = single_mrdivide (w1, w2);
elseif (len1==len2 & len1>1)
    w = spectrum;
    w = repmat(w,1,len1);   % create empty output array
    for i=1:len1
       w(i) = single_mrdivide (w1(i),w2(i));
    end
elseif (len1==1 & len2>1)
    w = spectrum;
    w = repmat(w,1,len2);   % create empty output array
    for i=1:len2
        w(i) = single_mrdivide (w1,w2(i));
    end
elseif (len1>1 & len2==1)
    w = spectrum;
    w = repmat(w,1,len1);   % create empty output array
    for i=1:len1
        w(i) = single_mrdivide (w1(i),w2);
    end
else
    error ('Check lengths of array(s) of input arguments')
end
return
  
