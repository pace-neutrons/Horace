function mplot(w, yval, step)
%
% Plots an array of spectra, with (optionally) the y axis values determined by further arguments.
%
% E.g.: w might be a series of cuts along the x-axis taken at different temperatures,
% in which case, fill an array yval with a list of temperatures (column or row - the 
% function determines which), and enter:
%
%   >> mplot (w, temperature)
%
% Full Syntax:
%
%   >> mplot (w)    % y axis values are spectrum number i.e. 1,2,3 ...length(w)
%                     The bin boundaries along the y-axis are 0.5, 1.5, 2.5, ... length(w)+0.5
%                     However, if there is control information in the title, then this will be used if possible
%
%   >> mplot (w, yval)   % y values are given by the array yval.
%                          Ensure yval is monotonically increasing.
%                          If length(yval) = length(w): 
%                               bin boundaries are given by the half-way points between the values of yval.
%                          if length(yval) = length(w)+1: 
%                               yval contains the bin boundaries
%
%   >> mplot (w, ystart, ystep) % y values are ystart, ystart+ystep, ystart+2*ystep, ystart+3*ystep ...
%                                 Bin boundaries are ystart-step/2, ystart+step/2, ystart+(3/2)*ystep ...
%
%   >> mplot (w, yval, ywidth)  % y values are in the array yval, bin-widths in the array ywidth
%

% Create new genie graphics window if one is not currently active
genie_figure_create ('Genie_2D');
hold off;   % new plot
delete(gca)

% No. spectra:
nspec = length(w);

% No. patches to be plotted:
npatch = 0;
for i=1:nspec
    if (length(w(i).x) <=1)
        error (['Check length of spectrum ' numstr(i) '- must have at least two x values'])
    end
    npatch = npatch + length(w(i).y);
end

% default unit lengths and y axis annotation
tx_temp = w(1).xlab;
ty_temp = 'Spectrum number';
tt_temp = w(1).title;
x_ulen = 0;
y_ulen = 0;

% y values for creating arrays for PATCH function:
%-----------------------------------------------------------------------------------------------------
if (nargin==1)
    % look for mgenie control information in the title
    %   - if first spectrum contains start and step values, these will take precendence
    %   - if not present, then look for y values in each spectrum
    %   - otherwise, label spectra with integers 1,2,3,...
    ytemp = mgenie_control_y_values(w); % read values from control information, if sufficient present
    if size(ytemp,1)==0 % not present
        ytemp_lo = linspace(0.5,length(w)-0.5,length(w));   % default
        ytemp_hi = linspace(1.5,length(w)+0.5,length(w));   % default
    else
        if size(ytemp,1)==1 % bin centres only
            ytemp = boundaries(ytemp);
            ytemp_lo = ytemp(1:end-1);
            ytemp_hi = ytemp(2:end);
        else
            ytemp_lo = ytemp(1,:);
            ytemp_hi = ytemp(2,:);
        end
        control_ref = read_labels(w(1).title);
        if isfield(control_ref,'mgenie_control_y_label')    % y axis label
            ty_temp = control_ref.mgenie_control_y_label;
        else
            ty_temp = 'y value';
        end
        if isfield(control_ref,'mgenie_control_x_unitlength') & isfield(control_ref,'mgenie_control_y_unitlength') % axis units
            x_ulen = str2num(control_ref.mgenie_control_x_unitlength);
            y_ulen = str2num(control_ref.mgenie_control_y_unitlength);
        end
    end

%-----------------------------------------------------------------------------------------------------
elseif (nargin==2)
    if (isa(yval,'double') & ndims(yval)==2 & min(size(yval))==1 & max(size(yval))>1)
        nyval = length(yval);
        if (nyval==nspec)
            ytemp = boundaries(reshape(yval,1,nyval));   % assumes that yval is monotonically increasing
        elseif (nyval==nspec+1)
            ytemp = reshape(yval,1,nyval);
        else
            error('ERROR: Check length of W and YVAL are consistent')
        end
        ytemp_lo = ytemp(1:end-1);
        ytemp_hi = ytemp(2:end);
    else
        error ('Check input arguments')
    end

%-----------------------------------------------------------------------------------------------------
elseif (nargin==3)
    if (isa(yval,'double') & length(yval)==1 & isa(step,'double') & length(step)==1)
        ytemp = yval+step*(linspace(0,nspec,nspec+1)-0.5);
        ytemp_lo = ytemp(1:end-1);
        ytemp_hi = ytemp(2:end);
    elseif (isa(yval,'double') & length(yval)==length(w) & isa(step,'double') & length(step)==length(w))
        nyval = length(yval);
        ytemp_lo = reshape(yval,1,nyval) - 0.5.*reshape(step,1,nyval);
        ytemp_hi = reshape(yval,1,nyval) + 0.5.*reshape(step,1,nyval);
    else
        error ('Check sizes of YVAL and YWIDTH')
    end
end
%-----------------------------------------------------------------------------------------------------

% Create dummy arrays for PATCH function
x = zeros(4,npatch);
y = zeros(4,npatch);
c = zeros(1,npatch);

% fill arrays
nhi = 0;
for i=1:nspec
    if (length(w(i).x)==length(w(i).y))
        xtemp = boundaries(w(i).x)';
    else
        xtemp = w(i).x';
    end
    np = length(xtemp)-1;
    nlo = nhi + 1;
    nhi = nhi + np;
    x(1,nlo:nhi) = xtemp(1:np);
    x(2,nlo:nhi) = xtemp(2:np+1);
    x(3,nlo:nhi) = xtemp(2:np+1);
    x(4,nlo:nhi) = xtemp(1:np);
    y(1,nlo:nhi) = ytemp_lo(i);
    y(2,nlo:nhi) = ytemp_lo(i);
    y(3,nlo:nhi) = ytemp_hi(i);
    y(4,nlo:nhi) = ytemp_hi(i);
    c(nlo:nhi) = w(i).y;
end
xlo = min(min(x));
xhi = max(max(x));
ylo = min(min(y));
yhi = max(max(y));

% Create graphics output
axis([xlo xhi ylo yhi]);
box;

[tt,tx,ty] = graph_titles (tt_temp, tx_temp, ty_temp, w(1).xunit, 0, 0);
xlabel(tx);
ylabel(ty);
title(tt);

if (x_ulen ~= 0 & y_ulen ~=0)
    set(gca,'DataAspectRatioMode','manual');
    a=get(gca,'DataAspectRatio');
    set(gca,'DataAspectRatio',[1/x_ulen 1/y_ulen (1/x_ulen+1/y_ulen)/(a(1)+a(2))*a(3)]);
end

patch(x,y,c,'facecolor','flat','cdatamapping','scaled','edgecolor','none');
colorbar;
drawnow;
