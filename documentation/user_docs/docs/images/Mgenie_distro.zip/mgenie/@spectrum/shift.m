function [wout] = shift(win, xval)
% SPECTRUM/SHIFT - Moves a spectrum along the x-axis
%
% Syntax:
%   >> w_out = shift(w_in, delta)
%
% If DELTA is positive, then the spectrum starts and ends at more positive
% values of x.
%

% Catch trivial case:
if (nargin == 1)
    wout = win;
    return
end

if (nargin == 2)
    if (~isa(win,'spectrum'))      % check if first argument is also a spectrum
        error ('Check first argument is a spectrum (SHIFT)')
    end
    if (~(isa(xval,'double') & size(xval)==[1,1]))      % check 2nd argument a single number
        error ('Check second argument is a number (SHIFT)')
    end
else
    error ('Only two arguments (W_IN, DELTA) required (SHIFT)')
end

nw = length(win);
if nw==1
    wout=spectrum(win.x+xval, win.y, win.e, win.title, win.xlab, win.ylab, win.xunit, win.distribution);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        wout(i)=spectrum(win(i).x+xval, win(i).y, win(i).e, win(i).title, win(i).xlab, win(i).ylab, win(i).xunit, win(i).distribution);
    end
end
