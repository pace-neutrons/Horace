function w_tomfit (w, xrange, p, fixed)
% This function is used to send data contained in an mgenie spectrum to Mfit
% to be be fitted interactively.
%
% *** The function has been renamed from: w_tomfit  to: tomfit
%     Please type >> help tomfit    for how to use the function.

if nargin==1
    tomfit (w);
elseif nargin==2
    tomfit (w, xrange);
elseif nargin==3
    tomfit (w, xrange, p);
elseif nargin==4
    tomfit (w, xrange, p, fixed);
else
    error ('Check number of arguments')
end
