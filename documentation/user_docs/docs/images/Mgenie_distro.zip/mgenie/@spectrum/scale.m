function [wout] = scale(win, fac)
% SPECTRUM/SCALE - Multiplies the x-axis by the factor fac
%
% Syntax:
%   >> w_out = scale (w_in, fac)
%
%

% Catch trivial case:
if (nargin == 1)
    wout = win;
    return
end

if (nargin == 2)
    if (~isa(win,'spectrum'))      % check if first argument is also a spectrum
        error ('Check first argument is a spectrum (SCALE)')
    end
    if (~(isa(fac,'double') & size(fac)==[1,1]))      % check 2nd argument a single number
        error ('Check second argument is a number (SCALE)')
    end
else
    error ('Only two arguments (W_IN, FAC) required (SCALE)')
end

nw = length(win);
if nw==1
    wout=spectrum(win.x*fac, win.y, win.e, win.title, win.xlab, win.ylab, win.xunit, win.distribution);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        wout(i)=spectrum(win(i).x*fac, win(i).y, win(i).e, win(i).title, win(i).xlab, win(i).ylab, win(i).xunit, win(i).distribution);
    end
end
