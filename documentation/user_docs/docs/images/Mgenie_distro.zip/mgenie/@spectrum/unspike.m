function wout = unspike(w1,ymin,ymax,fac,sfac)
% SPECTRUM/UNSPIKE  Removes spikes from a spectrum
%
% There are four optional parameters: 
%
%   YMIN    If y < ymin then the point is considered a spike [Default: NaN i.e. ignored]
%   YMAX    If y > ymax then the point is considered a spike [Default: NaN i.e. ignored]
%   FAC     If a point is within a factor FAC of both of its neighbours
%          then is NOT a spike [Default: FAC = 2]
%   SFAC    If the difference of a point w.r.t. both of its neighbours is
%          less than SFAC standard deviations then the point is NOT a spike
%          [Default: 5]
%
% Use NaN to skip over an optional parameter (see examples below).
%
% Syntax:
%   >> wout = unspike (w1)
%   >> wout = unspike (w1, NaN, NaN, 1.5)   % to alter FAC to 1.5

options = [0;0;1;1];    % FAC and SFAC present by default
values  = [0;0;2;5];     % 3rd and 4th are default values for FAC and SFAC

if (isa(w1,'spectrum'))
    if (nargin > 5)
        error ('Too many arguments (UNSPIKE)')
    end
    if (nargin > 1)
        if (isa(ymin,'double') & size(ymin)==[1,1]) 
            if (isfinite(ymin))
                options(1)=1;
                values(1)=ymin;
            end
        else
            error ('Check YMIN for type and/or number of elements')
        end
    end
    if (nargin > 2)
        if (isa(ymax,'double') & size(ymax)==[1,1]) 
            if (isfinite(ymax))
                options(2)=1;
                values(2)=ymax;
            end
        else
            error ('Check YMAX for type and/or number of elements')
        end
    end
    if (nargin > 3)
        if (isa(fac,'double') & size(fac)==[1,1]) 
            if (isfinite(fac))
                options(3)=1;
                values(3)=fac;
            end
        else
            error ('Check FAC for type and/or number of elements')
        end
    end
    if (nargin > 4)
        if (isa(sfac,'double') & size(sfac)==[1,1]) 
            if (isfinite(sfac))
                options(4)=1;
                values(4)=sfac;
            end
        else
            error ('Check SFAC for type and/or number of elements')
        end
    end

else
    error ('Unspike a spectrum only')
end

% Valid input arguments for unspiking:

nw = length(w1);
if nw==1
    [yu,eu] = spectrum_unspike (w1.x, w1.y, w1.e, options, values);
    wout = spectrum(w1.x, yu, eu, w1.title, w1.xlab, w1.ylab, w1.xunit, w1.distribution);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        [yu,eu] = spectrum_unspike (w1(i).x, w1(i).y, w1(i).e, options, values);
        wout(i) = spectrum(w1(i).x, yu, eu, w1(i).title, w1(i).xlab, w1(i).ylab, w1(i).xunit, w1(i).distribution);
    end
end

        