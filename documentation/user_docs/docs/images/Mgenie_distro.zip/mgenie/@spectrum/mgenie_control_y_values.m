function yout = mgenie_control_y_values(w)
% mgenie_control_y_values:  Get y values from control information for an array of spectra
%   >> yout = mgenie_control_y_values(w)
%
% - values of mgenie_control_y_start and mgenie_control_y_step if exist for first spectrum in the array
%       yout(1:nw) = positions on y axis for each spectrum
% - otherwise from mgenie_control_y_val
%   * if one value in each spectrum
%       yout(1:nw) = positions on y axis for each spectrum
%   * if two values in each spectrum
%       yout(1:2,1:nw) = lower and upper boundaries of each spectrum
%
% Output is empty array otherwise

control_ref = read_labels(w(1).title);
nw = length(w);

yout = [];
if isfield(control_ref,'mgenie_control_y_start') & isfield(control_ref,'mgenie_control_y_step') % y plot positions
    ystart = str2num(control_ref.mgenie_control_y_start);
    step = str2num(control_ref.mgenie_control_y_step);
    yout = ystart + step*linspace(0,nw-1,nw);
else
    for iw = 1:nw
        control = read_labels(w(iw).title);
        if isfield(control,'mgenie_control_y_val')
            yval = str2num(control.mgenie_control_y_val);
            if iw==1
                nval = length(yval);
                if nval==1 | nval==2
                    yout_temp = zeros(nval,nw);
                else
                    return
                end
            end
            if length(yval)==nval
                yout_temp(:,iw)=yval;
            else
                return
            end
        else
            return
        end
    end
    yout = yout_temp;
end
