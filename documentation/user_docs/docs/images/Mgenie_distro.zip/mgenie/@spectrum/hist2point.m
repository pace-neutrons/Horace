function wout = hist2point(w)
% SPECTRUM/HIST2POINT converts histogram spectrum to point data
% If already point data, then does not alter

nw = length(w);
if nw==1
    s=get(w);
    if length(s.x)~=length(s.y) % is histogram data
        s.x = 0.5*(s.x(2:end)+s.x(1:end-1));
    end
    wout = spectrum(s);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        s=get(w(i));
        if length(s.x)~=length(s.y) % is histogram data
            s.x = 0.5*(s.x(2:end)+s.x(1:end-1));
        end
        wout(i) = spectrum(s);
    end
end
 