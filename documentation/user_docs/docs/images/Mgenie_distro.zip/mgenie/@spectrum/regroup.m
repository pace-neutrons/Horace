function [wout] = regroup(w, v1, v2, v3)
% SPECTRUM/REGROUP  Rebins a histogram spectrum so that the new bin boundaries are
%                   always coincident with boundaries in the input spectrum. This avoids
%                   correlated error bars between the contents of the bins.
%
%                   Point data is treated idnetically to REBIN (see rebin help for the
%                   full syntax for this case).
%
% Syntax :
%
%   >> wout = regroup (w1,xlo,dx,xhi)
%
%   >> wout = regroup (w1,[xlo,dx,xhi])
%
% If DX +ve: then the bins are linear i.e. wout.x(i+1) >= wout.x(i) + dx
% If DX -ve: then the bins are logarithmic i.e. wout.x(i+1) >= wout.x(i)*(1+|dx|)
%
% The value of wout.x(i+1) is chosen to be the smallest w1.x(j) that satisfies the RHS of the
% equations above. Each of the new bin bondaries therefore always conincides with an input
% bin boundary. This ensures that the data in output bins are uncorrelated with the
% data in its neighbours. There has to be at least one input histogram bin entirely
% contained within the range XLO to XHI i.e.
%
%          xhi =< wout.x(1) < wout.x(nout) =< xhi
%


if (~isa(w,'spectrum'))
    error ('Check first argument is a spectrum')
end

% Catch trivial case:
if (nargin == 1)
    wout = w;
    return
end

% Perform regroup:
if (nargin >= 2 & nargin <=4)
    nw = length(w);
    if (nw==1)
        if (nargin == 2)
            wout = single_regroup (w, v1);
        elseif (nargin==3)
            wout = single_regroup (w, v1, v2);
        elseif (nargin==4)
            wout = single_regroup (w, v1, v2, v3);
        end
    else
        wout(1) = spectrum;
        wout = repmat(wout,1,nw);
        for i=1:nw
            if (nargin == 2)
                wout(i) = single_regroup (w(i), v1);
            elseif (nargin==3)
                wout(i) = single_regroup (w(i), v1, v2);
            elseif (nargin==4)
                wout(i) = single_regroup (w(i), v1, v2, v3);
            end
        end
    end
else
    error ('Check number of arguments')
end
