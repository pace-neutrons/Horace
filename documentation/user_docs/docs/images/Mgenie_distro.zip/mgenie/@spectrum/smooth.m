function wout = smooth (win, varargin)
% Smooths a spectrum
%
%Syntax:
%   >> wout = smooth (win)                  % smooths with hat function, FWHH=3
%   >> wout = smooth (win, width, shape)    % Finer control on smoothing
%
% Input:
% ------
%   win     Input spectrum
%   width   Sets the extent of the smoothing along each dimension. The interpretation
%          of width depends on the argument 'shape' described below.
%
%   shape   Shape of smoothing function
%               'hat'           hat function
%                                   - width gives FWHH along each dimension
%                                   - width = 1,3,5,...;  n=0 or 1 => no smoothing
%               'gaussian'      Gaussian; width gives FWHH along each dimension
%                                   - elements where more than 2% of peak intensity
%                                     are retained
%
% Output:
% -------
%   wout    Smoothed spectrum


% List available functions and set defaults. If more functions are to be
% added as smoothing options, then place in the Horace private directory
shapes = {'hat'; 'gaussian'};       % available functions for convolution
shape_handle = {@hat; @gaussian};   % corresponding function handles
width_default = 3;
shape_default = 'hat';
ishape = 1;


if nargin==1
    nargs = 0;
elseif nargin==2 & iscell(varargin{1}) % interpret as having been passed a varargin (as cell array is not a valid type to be passed to dnd_smooth)
    args = varargin{1};
    nargs= length(args);
else
    args = varargin;
    nargs= length(args);
end

if nargs==0
    width = width_default;
    shape = shape_default;
end
    
if nargs>=1
    % Check size of width
    width = args{1};
    if ~isa_size(width,[1,1],'double')
        error ('ERROR: argument ''width'' must be a scalar')
    end
    if nargs==1
        shape = shape_default;
    else
        shape = args{2};
    end
end

% check shape
if isa_size(shape,'row','char')
    ishape = string_find (shape,shapes);
    if ishape<0
        error ('ERROR: Ambiguous convolution function name')
    elseif ishape==0
        error (['ERROR: Function ''',shape,''' is not recognised as an available option'])
    end
else
    error ('ERROR: argument ''shape'' must be a character string')
end

% Copy output
wout = win;

% Create convolution array
c = shape_handle{ishape}(width);    % use function handles to create matrix - can add further functions above wihout altering remaining code

% Smooth data structure
index = ~isnan(win.y);  % elements with non-zero counts
wout.y(~index) = 0;     % put zero signal in y array so that it does not contribute to smoothing
wout.e(~index) = 0;     % likewise

weight = convn(double(index),c,'same');     % weight function including only points where there is data
weight(~index) = NaN;                       % normalisation by weight will ensure that points with NaN signal restored to NaN
wout.y = convn(wout.y,c,'same')./weight;    % points with no data (i.e. signal = 0) do not contribute to convolution
wout.e = sqrt(convn((wout.e).^2,c.^2,'same'))./weight;
