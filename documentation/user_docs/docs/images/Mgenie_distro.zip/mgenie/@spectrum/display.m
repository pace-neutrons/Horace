function display(w)
% SPECTRUM/DISPLAY Command window listing of a spectrum
%
% Syntax:
%   >> display(w)
%

% Get name of input spectrum
if (strcmp(inputname(1),''))
    string = 'spectrum';
else
    string = inputname(1);
end

% If array of spectra
if (max(size(w))>1)
    if (length(size(w))<=2)
        disp(['           ',string,' = [',num2str(size(w,1)),'x',num2str(size(w,2)),' spectrum]'])
    else
        disp(['           ',string,' = [',num2str(length(size(w))),'-dimensional array of class spectrum]'])
    end
    disp(' ')
    return
end


% Write x,y,e arrays
if (size(w.x,1) <=2)
    disp([string,'.x ='])
    disp(w.x')
    disp([string,'.y ='])
    disp(w.y')
    disp([string,'.e ='])
    disp(w.e')
else
    disp(['           ',string,'.x = [',num2str(size(w.x,1)),'x1',' double]'])
    disp(['           ',string,'.y = [',num2str(size(w.y,1)),'x1',' double]'])
    disp(['           ',string,'.e = [',num2str(size(w.e,1)),'x1',' double]'])
end

if (size(char(w.title),1)==1)
    disp(['       ',string,'.title = ''',char(w.title),''''])
else
    disp(['       ',string,'.title = '])
    disp(w.title)
end

if (size(char(w.xlab),1)==1)
    disp(['        ' string,'.xlab = ''',char(w.xlab),''''])
else
    disp(['        ',string,'.xlab = '])
    disp(w.xlab)
end

if (size(char(w.ylab),1)==1)
    disp(['        ',string,'.ylab = ''',char(w.ylab),''''])
else
    disp(['        ',string,'.ylab = '])
    disp(w.ylab)
end

if (size(w.xunit,1)==1)
    disp(['       ',string,'.xunit = ''',char(w.xunit),''''])
else
    disp(['       ',string,'.xunit = '])
    disp(w.xunit)
end

disp([string,'.distribution = ',num2str(w.distribution)])

disp(' ')