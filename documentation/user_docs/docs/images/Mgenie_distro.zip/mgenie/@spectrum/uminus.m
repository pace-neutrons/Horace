function wout = uminus(w1)
% SPECTRUM/UMINUS  Implement -w1

nw = length(w1);

if nw==1
    wout.x = w1.x;
    wout.y = -w1.y;
    wout.e = w1.e;
    wout.title = w1.title;
    wout.xlab = w1.xlab;
    wout.ylab = w1.ylab;
    wout.xunit = w1.xunit;
    wout.distribution = w1.distribution;
    wout = class(wout,'spectrum');
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:length(w1)
        wout(i).x = w1(i).x;
        wout(i).y = -w1(i).y;
        wout(i).e = w1(i).e;
        wout(i).title = w1(i).title;
        wout(i).xlab = w1(i).xlab;
        wout(i).ylab = w1(i).ylab;
        wout(i).xunit = w1(i).xunit;
        wout(i).distribution = w1(i).distribution;
    end
end
        