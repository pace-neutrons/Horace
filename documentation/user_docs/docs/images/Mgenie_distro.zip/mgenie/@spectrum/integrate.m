function ans = integrate(w1,xlo,xhi)
% SPECTRUM/INTEGRATE  Integrate W1 between XLO and XHI:
%    >> ans = integrate(w,xlo,xhi)
%       - If w is a single spectrum, then ans=[integral, error]
%       - If w is an array of spectra, then ans is a spectrum, with the x,y,e arrays
%         being the spectrum index i=1,2...length(w)); y(i), e(i) the integral and error.
%
% Syntax:
%   >> ans = integrate (w)              % integrate over full spectrum
%   >> ans = integrate (w, xlo, xhi)    % integrate between selected range

if (nargin==1)
    xlo = w1(1).x(1);
    xhi = w1(1).x(end);
elseif (nargin==3)
    if (~isa(xlo,'double') | ~isa(xhi,'double'))
        error ('integration limits must be real')
    end
else
    error ('wrong number of arguments')
end


if (length(w1)==1)  % single spectrum
    [ans.val,ans.err] = spectrum_integrate(w1.x, w1.y, w1.e, xlo, xhi);
else                % if array of spectra, produce spectrum as output
    n = length(w1);
    % look for mgenie control information in the title, and if present use this to set output x array:
    control = read_labels(w1(1).title);
    if isfield(control,'mgenie_control_y_start') & isfield(control,'mgenie_control_y_step') % y plot positions
        ystart = str2num(control.mgenie_control_y_start);
        step   = str2num(control.mgenie_control_y_step);
        x=linspace(ystart,ystart+(n-1)*step,n);
        if isfield(control,'mgenie_control_y_label')    % y axis label
            xtitle = control.mgenie_control_y_label;
        else
            xtitle = 'y value';
        end
        if isfield(control,'mgenie_control_x_label')    % y axis label
            xlab = control.mgenie_control_x_label;
        else
            xlab = 'x-axis';
        end
    else
        x=linspace(1,n,n);
        xtitle = 'Spectrum index';
        xlab = 'x-axis';
    end
    y=zeros(1,n);
    e=zeros(1,n);
    for i = 1: n
        [y(i),e(i)] = spectrum_integrate(w1(i).x, w1(i).y, w1(i).e, xlo, xhi);
    end
    ans = spectrum(x,y,e,w1(1).title,xtitle,...
             ['Integral from ' num2str(xlo) ' to ' num2str(xhi) ' ' w1(1).xunit ' along ' xlab], '', 0);
end
