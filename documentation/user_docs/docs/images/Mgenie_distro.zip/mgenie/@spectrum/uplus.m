function wout = uplus(w1)
% SPECTRUM/PLUS  Implement +w1
wout = w1
        