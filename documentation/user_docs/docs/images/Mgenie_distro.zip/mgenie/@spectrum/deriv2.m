function wout = deriv2(w)
% SPECTRUM/DERIV2  Numerical second derivative of a spectrum

warning off;    % suppress warning messages

nw = length(w);
if nw==1
    [yd,ed] = spectrum_deriv2(w.x, w.y, w.e);
    wout = spectrum(w.x, yd, ed, w.title, w.xlab, w.ylab, w.xunit, w.distribution);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        [yd,ed] = spectrum_deriv2(w(i).x, w(i).y, w(i).e);
        wout(i) = spectrum(w(i).x, yd, ed, w(i).title, w(i).xlab, w(i).ylab, w(i).xunit, w(i).distribution);
    end
end

warning on;
