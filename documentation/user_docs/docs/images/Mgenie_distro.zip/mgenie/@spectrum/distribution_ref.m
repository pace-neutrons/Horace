function wdist = distribution_ref (w, factor_in, nbin_in)
% Finds the distribution of values in a spectrum.
% The output is itself a histogram.
%
% Syntax:
%   >> wdist = distribution(w)
%
%   >> wdist = distribution(w, range_factor, nbins)
%
%       x range is 0 - range_factor*median
%       THe range is split into nbins
%
%       Default: range_factor = 4
%       nbins = no. points / 100 (i.e. on average the value in a bin of the
%                                distribution will be 100)
%

% Default values for limits and no. bins over-ridden if input provided
factor = 4;
nbin = round(length(w.y)/100);
if (nargin>1)
    factor = factor_in;
end
if (nargin>2)
    nbin = nbin_in;
end

% Ranges for the plot
xlo = 0;
xhi = factor*median(w.y(~isnan(w.y)));    % remove NaN elements from the calculation of the range
x=[-inf;linspace(xlo,xhi,nbin+1)';inf];
n = histc(w.y,x);
x(1) = xlo - (xhi-xlo)/nbin;
x(end) = xhi + (xhi-xlo)/nbin;
e=zeros(size(x));
wdist = spectrum (x,n(1:end-1),e(1:end-1));

