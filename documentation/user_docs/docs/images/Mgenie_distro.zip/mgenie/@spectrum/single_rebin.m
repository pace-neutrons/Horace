function wout = single_rebin(w1,v1,v2,v3)
% SPECTRUM/SINGLE_REBIN  Rebins a spectrum (single spectrum version)
%
% Syntax:
%
%  wout = rebin(w1,w2)      rebin w1 with the bin boundaries of w2 (*** Note: reverse of Genie-2)
%  -------------------
%
%  wout = rebin(w1,x_array)  x_array is an array of boundaries and intervals. Linear or logarithmic
%  ------------------------ rebinning can be accommodated by conventionally specifying the rebin
%                           interval as positive or negative respectively:
%   e.g. rebin(w1,[2000,10,3000])  rebins from 2000 to 3000 in bins of 10
%
%   e.g. rebin(w1,[5,-0.01,3000])  rebins from 5 to 3000 with logarithmically spaced bins with
%                                 width equal to 0.01 the lower bin boundary 
%  The conventions can be mixed on one line:
%   e.g. rebin(w1,[5,-0.01,1000,20,4000,50,20000])
%
%  Rebinning between two limits maintaining the existing bin boundaries between those limits
%  is achieved with
%        rebin(w1,[xlo,xhi])
%
%
%  wout = rebin(w1,xlo,xhi)  retain only the data between XLO and XHI, otherwise maintaining the
%  ------------------------ existing bin boundaries. Abbreviated form of rebin(w1,[xlo,xhi])
%
%  wout = rebin(w1,xlo,dx,xhi)  Abbreviated form of rebin(w1,[xlo,dx,xhi])
%  ---------------------------
%

if (~isa(w1,'spectrum'))
    error ('Check first argument is a spectrum')
end

% Catch trivial case:
if (nargin==1)
    wout = w1;
    return
end

%---------------------------------------------------------------------------------------------
if (length(w1.x)==length(w1.y)+1)     % histogram
    if (nargin==2)
        if (isa(v1,'spectrum'))      % check if second argument is also a spectrum
            if length(v1.x)~=length(v1.y)   % is a histogram
                wout.x = v1.x;
            else                            % is point data
                if length(v1.x)>1
                    wout.x = boundaries(v1.x);
                else
                    error ('ERROR: Spectrum providing boundaries is point data with only one point')
                end
            end
            [wout.y,wout.e] = spectrum_rebin_by_spectrum (w1.x, w1.y, w1.e, wout.x);
        elseif (isa(v1,'double'))    % check if second argument is a double array
            xbounds = v1';
            [wout.x,wout.y,wout.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
        else
            error ('Second argument must be a spectrum or real array (REBIN)')
        end
    elseif (nargin==3)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & length(v1)==1 & length(v2)==1)
            xbounds=[v1;v2];
        else
            error ('Second and third arguments must be XLO, XHI (REBIN)')
        end
        [wout.x,wout.y,wout.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    elseif (nargin==4)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & isa(v3,'double') & length(v1)==1 & length(v2)==1 & length(v3)==1)
            xbounds=[v1;v2;v3];
        else
            error ('Second, third and fourth arguments must be XLO, DEL, XHI (REBIN)')
        end
        [wout.x,wout.y,wout.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    else
        error ('Check rebin arguments (REBIN)')
    end
    
%---------------------------------------------------------------------------------------------    
elseif (length(w1.x)==length(w1.y)) % point mode 
    % Get boundaries for rebinning: Not very efficient, as also rebins data, but quick 'n easy way of getting boundaries
    % IF DEBUG HERE, MAKE IDENTICAL CHANGES TO REGROUP IN POINT MODE.
    if (nargin==2)
        if (isa(v1,'spectrum'))      % check if second argument is also a spectrum
            if length(v1.x)~=length(v1.y)   % is a histogram
                xtemp = v1.x;
            else                            % is point data
                if length(v1.x)>1
                    xtemp = boundaries(v1.x);
                else
                    error ('ERROR: Spectrum providing boundaries is point data with only one point')
                end
            end
        elseif (isa(v1,'double'))    % check if second argument is a double array
            xbounds = v1';
            [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
        else
            error ('Second argument must be a spectrum or real array (REBIN)')
        end
    elseif (nargin==3)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & length(v1)==1 & length(v2)==1)
            xbounds=[v1;v2];
        else
            error ('Second and third arguments must be XLO, XHI (REBIN)')
        end
        [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    elseif (nargin==4)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & isa(v3,'double') & length(v1)==1 & length(v2)==1 & length(v3)==1)
            xbounds=[v1;v2;v3];
        else
            error ('Second, third and fourth arguments must be XLO, DEL, XHI (REBIN)')
        end
        [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    else
        error ('Check rebin arguments (REBIN)')
    end
        
    ibin = bin_index (w1.x, xtemp);
    np = length(xtemp)-1;
    wout.x = zeros(np,1);
    wout.y = zeros(np,1);
    wout.e = zeros(np,1);
    npix = zeros(np,1);
    for i = find(ibin>0)
        wout.x(ibin(i)) = wout.x(ibin(i)) + w1.x(i);
        wout.y(ibin(i)) = wout.y(ibin(i)) + w1.y(i);
        wout.e(ibin(i)) = wout.e(ibin(i)) + w1.e(i)^2;
        npix(ibin(i)) = npix(ibin(i)) + 1;
    end
    mask = npix>0;
    wout.x = wout.x(mask)./npix(mask);
    wout.y = wout.y(mask)./npix(mask);
    wout.e = sqrt(wout.e(mask))./npix(mask);    
    
%---------------------------------------------------------------------------------------------    
end

wout = spectrum(wout.x,wout.y,wout.e, w1.title, w1.xlab, w1.ylab, w1.xunit, w1.distribution);
        