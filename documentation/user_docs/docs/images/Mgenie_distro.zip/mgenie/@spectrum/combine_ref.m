function wout= combine(w1,varargin)

% COMBINE(w1, x1, w2, ..., xn-1, wn, delta)
% Combines workspaces with identical x axes into a new workspace.
% The data set are "glued" together at the points x1,x2..xn-1
% with a smoothing function that extends +/-(delta/2) about those points.
%
% Syntax:
%   >> wout = combine (w1, x1, w2, delta)                   % minimum case
%
%   >> wout = combine (w1, x1, w2, x2 ... xn-1, wn, delta)  % general case

% Joost van Duijn: 28-08-03
%
% Modified: T.G.Perring 27-01-2007
%   - enhance argument checking
%   - now calculates smoothing function correctly for point spectra as well as
%    histogram data
%   - corrects error at the ends of the x range when one or both limits were
%    negative
%   - corrected bug in calculation of error bars
%   - for a given spectrum, ignores any points that lie outside the range
%    of the non-zero parts of the smoothing function. This cures a problem that
%    NaN in a spectrum cause a NaN in the output, even if the point is way
%    outside the range that the spectrum contributes to.

% Get parameters from the first spectrum
if length(w1)~=1
    error(['Input argument 1 must be a single spectrum, not an array']);
end
w = get(w1);
nx=length(w.x);
ny=length(w.y);

if rem(nargin,2)~=0
    error ('Check number of arguments to spectrum combine function')
end

nwork= floor(nargin/2); %number of workspaces that will be combined
if nwork<=1
    error(['Not enough input paramters given! Minimum input consists'...
        ' of e.g. wout= combine(w1,x1,w2,delta)']);
end

% Check if input parameters in the varargin 2, 4, 6, ..., 2*(nwork-1) are of type spectrum
% and all have the same x-axis.
j=1;
for i=2:2:2*(nwork-1)
    j= j+1;
    if ~isa(varargin{i} , 'spectrum'),
        error(['Input argument ' 1+int2str(i) ' is not a spectrum']);
    elseif length(varargin{i})~=1
        error(['Input argument ' 1+int2str(i) ' must be a single spectrum, not an array']);
    else
        w(j)= get(varargin{i});
    end
    if length(w(j).x)~=nx || any(w(j).x~=w(1).x)
        error('Input spectra do not have identical xrange');
    end
    if length(w(j).y)~=ny
        error ('Cannot combine histogram and point data');
    end
end

% Check if the input paramters in the varargin 1, 3, ..., 2*nwork-3 are double, these
% paramters contain the boundaries of the different spectra, and
% are in increasing oder. Will give x1, x2, x3, ..., xn-1.
j=0;
for i=1:2:2*nwork-3,
    j= j+1;
    if ~isa(varargin{i}, 'double'),
        error(['Input agument ' 1+int2str(i) ' is not a number']);
    elseif length(varargin{i})>1
        error(['Input agument ' 1+int2str(i) ' must be a scalar']);
    else
        x(j)= varargin{i};
    end
    if (j==1)&(x(j)<w(1).x(1)),
        error('The first merge point does not lie within the xrange');
    elseif (j>1)&(x(j-1)>x(j)),
        error('The merge points are not in increasing order');
    elseif (i==2*nwork-2)&(x(j)>w(1).x(nx)),
        error('The final merge point does not lie within the xrange');
    end
end

% Check if the last agument is a double. This is the delta that will be
% used in the smoothing function, determines the range over which data
% is smoothed near the boundaries.
if ~isa(varargin{2*nwork-1}, 'double')||length(varargin{2*nwork-1})>1||(varargin{2*nwork-1}<0),
    error('The final input argument must be a positive number');
else
    delta=varargin{2*nwork-1};
end

% Calculate the smoothing functions for the different data sets. The two hat
% functions are going to be defined as:
% 1) width= width of each region, height=1;
% 2) width= delta, height= 1/delta;
if nx==ny
    xrange = w(1).x;
else
    xrange = 0.5*(w(1).x(1:nx-1)+w(1).x(2:nx));
end
wy=zeros(size(w(1).y));
we=zeros(size(w(1).e));
for i=1:nwork,
    if i==1,
        cent = xrange(1);
        width = 2*(x(1)-xrange(1));
    elseif i==nwork,
        cent = xrange(ny);
        width = 2*(xrange(ny)-x(nwork-1));
    else
        cent = 0.5*(x(i)+x(i-1));
        width = x(i)-x(i-1);
    end
    smooth= hat2(width, 1, delta, 1/delta, xrange(1:ny)-cent);
    ind = find(smooth>0); % those points inside the smoothing range
    wy(ind) = wy(ind) + smooth(ind).*(w(i).y(ind));
    we(ind) = we(ind) + (smooth(ind).*(w(i).e(ind))).^2;
end
we= sqrt(we);
wout=spectrum(w(1).x, wy, we, w(1).title, w(1).xlab, w(1).ylab, w(1).xunit, w(1).distribution);