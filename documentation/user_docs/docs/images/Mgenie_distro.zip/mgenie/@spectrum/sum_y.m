function wout = sum_y(w1,ylo,yhi)
% SPECTRUM/SUM_Y  Sum the spectra in an array w1 whose y values lie in the range 
%                ylo to yhi. The output is a spectrum.
%
% Differs from sum_work:
%   sum_work - sums over a range of spectrum indices; sum_y
%   sum_y    - sums over a range of y values.
%
% Syntax:
%   >> ans = sum_y (w)              % sum all spectra
%   >> ans = sum_y (w, ylo, yhi)    % sum over selected range

% *** IDENTICAL CODE FOR SPECTRUM/SUM_Y AND TOFSPECTRUM/SUM_Y apart from setting the final
% output object

if (nargin==1) % make the summation over all the spectra
    ylo = 1;
    yhi = length(w1);
elseif (nargin==3)
    if (~isa(ylo,'double') | ~isa(yhi,'double'))
        error ('integration limits must be real')
    end
else
    error ('wrong number of arguments')
end

% Get the summation range
n = length(w1);
y = mgenie_control_y_values(w1); % read values from control information, if sufficient present
control_ref = read_labels(w1(1).title);
if size(y,1)==0 % not present
    ylabel = ['Summation of spectra with index ', num2str(ylo), ' to ', num2str(yhi)];
    y=1:n;  % label spectra by their index
else
    ylabel = ['Summation of spectra in range ', num2str(ylo), ' to ', num2str(yhi)];
    if isfield(control_ref,'mgenie_control_y_short_label')
        ylabel = [ylabel, ' along ', control_ref.mgenie_control_y_short_label];
    else
        ylabel = [ylabel, ' along y-axis'];
    end
    if size(y,1)==2 % boundaries
        y = 0.5*sum(y,2);
    end
end

iw_lo = lower_index(y,ylo);
iw_hi = upper_index(y,yhi);

if (iw_lo > n | iw_hi < 1)
    error (['ERROR: The summation range must lie in the range ',num2str(y(1)),' to ',num2str(y(end))])
end

if iw_lo == iw_hi
    wout = w1(iw_lo);
else
    wout = w1(iw_lo);
    for i=iw_lo+1:iw_hi
        wout = wout + rebin(w1(i),wout);
    end
end

% x-axis annotation:
if isfield(control_ref,'mgenie_control_x_label')    % y axis label
    xlabel = control_ref.mgenie_control_x_label;
else
    xlabel = w1(1).xlab;
end

% create main title:
% --------------------
% If there is a custom title for the array of spectra, keep just that; else strip away all
% mgenie_control information to avoid misleading interpretations later on
if isfield(control_ref,'mgenie_control_title')
    title = cellstr(control_ref.mgenie_control_title);
else
    temp = w1(1).title;
    if ischar(w1(1).title)  % can be cellarray of strings, or array of character strings
        temp = cellstr(temp);
    end
    % strip out any lines beginning mgenie_control (mgenie control information) from title
    j = 1;
    for i=1:length(temp)
        if isempty(strfind(temp{i},'mgenie_control'))
            title(j) = temp(i);
            j = j + 1;
        end
    end
end

wout = set (wout, 'title', title, 'xlab', xlabel, 'ylab', add_title(get(wout,'ylab'),ylabel,0));
