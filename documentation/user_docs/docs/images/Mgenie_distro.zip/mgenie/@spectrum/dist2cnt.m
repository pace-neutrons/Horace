function wout = dist2cnt (w)
% Converts a histogram spectrum that is a distribution, i.e. counts
% per unit x, to a spectrum that gives counts per channel
%
%   >> wout = dist2cnt(w)

nw = length(w);
if nw==1
    dbin = diff(w.x);
    if w.distribution > 0.5 & length(w.x)>length(w.y)
        wout = spectrum(w.x, w.y.*dbin, w.e.*dbin, w.title, w.xlab, w.ylab, w.xunit, 0);
    else
        error ('dist2cnt works only for histogram data in a distribution')
    end
else
    for i=1:nw
        if w(i).distribution < 0.5 & length(w(i).x)==length(w(i).y)
            error (['dist2cnt works only for histogram data in a distribution - check workspace ',num2str(i)])
        end
    end
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        dbin = diff(w(i).x);
        wout(i) = spectrum(w(i).x, w(i).y.*dbin, w(i).e.*dbin, w(i).title, w(i).xlab, w(i).ylab, w(i).xunit, 0);
    end
end
