function p = polynom (win, coeff)
% Calculates a poloynomial function from the points of an input spectrum
%
% Syntax:
%   >> p = polynom (win, coeffs)
%
% e.g.
%   >> p = polynom (win, [0.006, 0.03, -0.02])
%
% p is the polynomial 0.006 + 0.03.x -0.02.x^2
%

nx = length(win.x)
ny = length(win.y)
if (nx~=ny)
    x = middle(win.x);
else
    x = win.x;
end

np = length(coeff);
if np==1
    y = ones(ny,1).*coeff(1)
else
    y = zeros(ny,1);
    for i=1:np-1
        y = (y + coeff(np-i+1)).*x;
    end
    y = y + coeff(1);
end

p = spectrum(win.x,y);