function ibin = bin_index (x,p)
% P is an array of bin boundaries, x an array of x values.
% ibin will contain the bin number for each of the values of x
% Assume that x, p are monotonically increasing

ibin = zeros(1,length(x));

% Get range of x values contained in bins defined by p:
ilo = lower_index (x,p(1));
ihi = upper_index (x,p(end));
if ilo>ihi
    return
end

% Get range of p that contains that range of x:
jlo = upper_index (p, x(ilo));
jhi = lower_index (p, x(ihi));

% We now have:  p(jlo) =< x(ilo) < p(jlo+1);  p(jhi-1) < x(ihi) =< p(jhi)
% We may still have jlo = jhi with ilo = ihi
if jlo==jhi
    return
end

% Deal with one bin as a special case:
if jlo == jhi-1
    ibin(ilo:ihi) = jlo;
end

% 2 or more bins:
ibeg = ilo;
j = jlo;
for i=ilo:ihi
    if x(i) >= p(j+1)
        if i>ibeg
            ibin(ibeg:i-1)=j;
        end
        ibeg = i;       % first data point in next bin
        for jj=j+2:jhi  % jj will be index of upper bin boundary
            if x(i) < p(jj)
                j = jj-1;
                break
            end
            j = jhi-1;   % if gets here, then x(i)=p(jhi)
        end
        if j==jhi-1         % last bin, all remaining points are in the last bin
            ibin(ibeg:ihi) = j;
            break
        end
    end
%    disp(['j, ibeg: ',num2str(j),'  ',num2str(ibeg)])
end

            
            
