function plot_line (w)
% SPECTRUM/PLOT_LINE Draws a line plot of a spectrum

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

nw = length(w);
icol = mod(0:nw-1,length(genie_color))+1;
ilin = mod(0:nw-1,length(genie_line_style))+1;
iwid = mod(0:nw-1,length(genie_line_width))+1;
for i=1:nw
    if i>1; hold on; end
    nx=length(w(i).x);
    ny=length(w(i).y);
    % plot data
    if (nx == ny)   % point data
        plot(w(i).x,w(i).y,'Color',genie_color{icol(i)},'LineStyle',...
            genie_line_style{ilin(i)},'LineWidth',genie_line_width(iwid(i)));
    else
        temp=0.5*(w(i).x(2:nx) + w(i).x(1:nx-1));
        plot(temp,w(i).y,'Color',genie_color{icol(i)},'LineStyle',...
            genie_line_style{ilin(i)},'LineWidth',genie_line_width(iwid(i)));
    end
end

set (gca, 'XScale', genie_xscale);
set (gca, 'YScale', genie_yscale);