function plot_markers (w)
% SPECTRUM/PLOT_MARKERS Draws a marker plot of a spectrum

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

nw = length(w);
icol = mod(0:nw-1,length(genie_color))+1;
isiz = mod(0:nw-1,length(genie_marker_size))+1;
ityp = mod(0:nw-1,length(genie_marker))+1;
for i=1:nw
    if i>1; hold on; end
    nx=length(w(i).x);
    ny=length(w(i).y);
    % plot data
    if (nx == ny)   % point data
        plot(w(i).x,w(i).y,'LineStyle','none','Color',genie_color{icol(i)},...
            'Marker',genie_marker{ityp(i)},'MarkerSize',genie_marker_size(isiz(i)));
    else
        temp=0.5*(w(i).x(2:nx) + w(i).x(1:nx-1));
        plot(temp,w(i).y,'LineStyle','none','Color',genie_color{icol(i)},...
            'Marker',genie_marker{ityp(i)},'MarkerSize',genie_marker_size(isiz(i)));
    end
end

set (gca, 'XScale', genie_xscale);
set (gca, 'YScale', genie_yscale);  