function [tt,tx,ty] = graph_titles (title, xlab, ylab, xunit, distribution, binning)
% make graph titles from components of a spectrum and the plot binning
% If the title contains control information (strings beginning 'mgenie_control...') then
% these are stripped out.
% If binning = 0, then the binning is NOT appended to the title.

% create x-axis label:
% --------------------
if ischar(xlab)  % can be cellarray of strings, or array of character strings
    tx = cellstr(xlab);
else
    tx = xlab;
end
m = length(tx);
if (length(deblank(xunit)) > 0)
    tx{m} = [deblank(tx{m}) ' (' deblank(xunit) ')'];
end

% create y-axis label:
% --------------------
if ischar(ylab)  % can be cellarray of strings, or array of character strings
    ty = cellstr(ylab);
else
    ty = ylab;
end
m = length(ty);
if (length(deblank(xunit)) > 0 & distribution~=0)
    ty{m} = [deblank(ty{m}) ' / ' deblank(xunit)];
end

% create main title:
% --------------------
control_ref = read_labels(title);
if isfield(control_ref,'mgenie_control_title')
    tt = cellstr(control_ref.mgenie_control_title);
else
    if ischar(title)  % can be cellarray of strings, or array of character strings
        temp = cellstr(title);
    else
        temp = title;
    end
    % strip out any lines beginning mgenie_control (mgenie control information)
    j = 1;
    for i=1:length(temp)
        if isempty(strfind(temp{i},'mgenie_control'))
            tt(j) = temp(i);
            j = j + 1;
        end
    end
end

if exist('tt')  % there may be no lines left after filtering out mgenie_control lines
    m = length(tt);
else
    m = 0;
end
if round(binning) > 0
    tt{m+1}=strcat(['Binning: ' num2str(round(binning))]);
end
if ~exist('tt')
    tt = {''};
end