function plot_errors (w)
% SPECTRUM/PLOT_ERRORS Draws a plot of error bars for a spectrum

global genie_color genie_line_style genie_line_width genie_marker genie_marker_size genie_xscale genie_yscale

nw = length(w);
icol = mod(0:nw-1,length(genie_color))+1;
iwid = mod(0:nw-1,length(genie_line_width))+1;
for i=1:nw
    if i>1; hold on; end
    nx=length(w(i).x);
    ny=length(w(i).y);
    xb=zeros(1,3*ny);       % x array for plotting error bars
    if (nx == ny)           % point data
        xb(1:3:end)=w(i).x;
        xb(2:3:end)=w(i).x;
        xb(3:3:end)=NaN;
    else
        temp=0.5*(w(i).x(2:nx) + w(i).x(1:nx-1));
        xb(1:3:end)=temp;
        xb(2:3:end)=temp;
        xb(3:3:end)=NaN;
    end
    yb=zeros(1,3*ny);       % y array for plotting error bars
    yb(1:3:end)=w(i).y-w(i).e;
    yb(2:3:end)=w(i).y+w(i).e;
    yb(3:3:end)=NaN;

% plots data
    plot(xb,yb,'Color',genie_color{icol(i)},'LineWidth',genie_line_width(iwid(i)));
end

set (gca, 'XScale', genie_xscale);
set (gca, 'YScale', genie_yscale);