function val = get(w,prop_name)
% SPECTRUM/GET  Get a field from a spectrum
%
% Syntax:
%   >> val = get (w, 'x')   Gets x array
%   >> val = get (w)        Gets a structure containing all fields of spectrum w
%
% Valid fields are:
%
%    x, y, e, title, xlab, ylab, xunit, distribution
%

% if a single input argument, return whole structure:
if nargin==1
    val.x=w.x;
    val.y=w.y;
    val.e=w.e;
    val.title=w.title;
    val.xlab=w.xlab;
    val.ylab=w.ylab;
    val.xunit=w.xunit;
    val.distribution=w.distribution;
    return
end

% if property name given as well, extract value of just that property:
if (isa(prop_name,'char') & size(prop_name,1)==1)
    switch prop_name
        case 'x'
            val = w.x;
        case 'y'
            val = w.y;
        case 'e'
            val = w.e;
        case 'title'
            val = w.title;
        case 'xlab'
            val = w.xlab;
        case 'ylab'
            val = w.ylab;
        case 'xunit'
            val = w.xunit;
        case 'distribution'
            val = w.distribution;
        otherwise
            disp('Valid fields for a spectrum are')
            disp('x, y, e, title, xlab, ylab, xunit, distribution')
            error([prop_name,' is not a valid spectrum property'])
    end
else        
    error ('property name is not a character string')
end
        