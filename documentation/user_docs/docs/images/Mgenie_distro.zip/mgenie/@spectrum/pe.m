function pe(w,name)
% SPECTRUM/PE Draws a plot of error bars for a spectrum or array of spectra on an
% existing plot
%
%   >> pe(w)
%
% Advanced use:
%   >> pe(w,fig_name)       % plot on the fgure with name = fig_name

global genie_max_spectra_1d

% Check spectrum is not too long an array
if length(w)>genie_max_spectra_1d
    error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
end

newplot = 0;
type = 'e';
fig_name='Genie_1D';
if nargin==2
    tmp = genie_figure_name(name);
    if ~isempty(tmp), fig_name=tmp; end
end
plot_main (newplot,type,fig_name,w);
