function w = set(w, varargin)
% SPECTRUM/SET  Set fields in a spectrum.
%
% Syntax:
%   The output spectrum name must the same as the input spectrum name.
%   Valid fields are:  x, y, e, title, xlab, ylab, xunit, distribution
%   (For further description of the fields type >> help spectrum)
%
%   Checks are performed on the consistency of the input - for example, the net result 
%   after any changes to the x, y, and e arrays must be that the lengths of y and e are
%   the same, and that the length of x must be the same or one greater than y & e.
%
% e.g.
%   >> xx = [3,4,5,6,7,8,9,10]
%   >> w = set (w, 'x', xx)
%
%   >> yy = [4,2,6,9,4,7,1,15]
%   >> new_title = 'Hello there'
%   >> w = set (w, 'title', new_title, 'y', yy)

m = floor(length(varargin)/2);
if (length(varargin)-2*m == 1)  % must have even number of argumnents
    error ('Check number of arguments to set')
end

% check all input properties are OK before changing the spectrum properties:
xstr='w.x';
ystr='w.y';
estr='w.e';
titlestr='w.title';
xlabstr='w.xlab';
ylabstr='w.ylab';
xunitstr='w.xunit';
distributionstr='w.distribution';
for i = 1:m
    prop_name = varargin{2*i-1};
    if (isa(prop_name,'char') & size(prop_name,1)==1)
        switch prop_name
            case 'x'
                xstr = ['varargin{' num2str(2*i) '}'];
            case 'y'
                ystr = ['varargin{' num2str(2*i) '}'];
            case 'e'
                estr = ['varargin{' num2str(2*i) '}'];
            case 'title'
                titlestr = ['varargin{' num2str(2*i) '}'];
            case 'xlab'
                xlabstr = ['varargin{' num2str(2*i) '}'];
            case 'ylab'
                ylabstr = ['varargin{' num2str(2*i) '}'];
            case 'xunit'
                xunitstr = ['varargin{' num2str(2*i) '}'];
            case 'distribution'
                distributionstr = ['varargin{' num2str(2*i) '}'];
            otherwise
                error ([prop_name ' is not a valid property of a spectrum'])
        end
    else
        error ('property name is not a character string')
    end
end

% construct string to evaluate
command_string = ['spectrum(' xstr ',' ystr ',' estr ',' titlestr ',' xlabstr ',' ylabstr ',' xunitstr ',' distributionstr ')'];
w = eval(command_string);