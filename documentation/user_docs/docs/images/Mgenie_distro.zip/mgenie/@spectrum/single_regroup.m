function wout = single_regroup (w1,v1,v2,v3)
% SPECTRUM/REGROUP  Rebins a histogram spectrum so that the new bin boundaries are
%                   always coincident with boundaries in the input spectrum. This avoids
%                   correlated error bars between the contents of the bins.
%
%                   Point data is treated identically to REBIN (see rebin help for the
%                   full syntax for this case).
%
% Syntax :
%
%   >> wout = regroup (w1,xlo,dx,xhi)
%
%   >> wout = regroup (w1,[xlo,dx,xhi])
%
% If DX +ve: then the bins are linear i.e. wout.x(i+1) >= wout.x(i) + dx
% If DX -ve: then the bins are logarithmic i.e. wout.x(i+1) >= wout.x(i)*(1+|dx|)
%
% The value of wout.x(i+1) is chosen to be the smallest w1.x(j) that satisfies the RHS of the
% equations above. Each of the new bin bondaries therefore always conincides with an input
% bin boundary. This ensures that the data in output bins are uncorrelated with the
% data in its neighbours. There has to be at least one input histogram bin entirely
% contained within the range XLO to XHI i.e.
%
%          xhi =< wout.x(1) < wout.x(nout) =< xhi
%
% 


if (~isa(w1,'spectrum'))
    error ('Check first argument is a spectrum')
end

% Catch trivial case:
if (nargin==1)
    wout = w1;
    return
end

%---------------------------------------------------------------------------------------------
if (length(w1.x)==length(w1.y)+1)     % histogram

    if (nargin==2)
        if (isa(v1,'double') & length(v1)==3)    % check if second argument is a double array length 3
            xlo_regroup = v1(1);
            dx_regroup  = v1(2);
            xhi_regroup = v1(3);
        else
            error ('Second argument must be a real array length 3 (REGROUP)')
        end
    elseif (nargin==4)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & isa(v3,'double') & length(v1)==1 & length(v2)==1 & length(v3)==1)
            xlo_regroup = v1;
            dx_regroup  = v2;
            xhi_regroup = v3;
        else
            error ('Second, third and fourth arguments must be XLO, DEL, XHI (REGROUP)')
        end
    else
        error ('Check rebin arguments (REGROUP)')
    end

    [wout.x,wout.y,wout.e] = spectrum_regroup (w1.x, w1.y, w1.e, xlo_regroup, dx_regroup, xhi_regroup);
    
%---------------------------------------------------------------------------------------------    
else % point mode
    % Get boundaries for rebinning: Not very efficient, as also rebins data, but quick 'n easy way of getting boundaries
    % THIS CODE IS IDENTICAL TO THAT FOR POINT MODE WITH REBIN. IT IS REPRODUCED SOLELY THAT ERROR MESSAGES MENTION THE
    % CORRECT SUBROUTINE
    if (nargin==2)
        if (isa(v1,'spectrum'))      % check if second argument is also a spectrum
            if length(v1.x)~=length(v1.y)   % is a histogram
                xtemp = v1.x;
            else                            % is point data
                if length(v1.x)>1
                    xtemp = boundaries(v1.x);
                else
                    error ('ERROR: Spectrum providing boundaries is point data with only one point')
                end
            end
        elseif (isa(v1,'double'))    % check if second argument is a double array
            xbounds = v1';
            [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
        else
            error ('Second argument must be a spectrum or real array (REGROUP)')
        end
    elseif (nargin==3)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & length(v1)==1 & length(v2)==1)
            xbounds=[v1;v2];
        else
            error ('Second and third arguments must be XLO, XHI (REGROUP)')
        end
        [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    elseif (nargin==4)              % check that the three additional arguments are all single numbers
        if (isa(v1,'double') & isa(v2,'double') & isa(v3,'double') & length(v1)==1 & length(v2)==1 & length(v3)==1)
            xbounds=[v1;v2;v3];
        else
            error ('Second, third and fourth arguments must be XLO, DEL, XHI (REGROUP)')
        end
        [xtemp,dum_out.y,dum_out.e] = spectrum_rebin_by_descriptor (w1.x, w1.y, w1.e, xbounds);
    else
        error ('Check rebin arguments (REGROUP)')
    end
        
    ibin = bin_index (w1.x, xtemp);
    np = length(xtemp)-1;
    wout.x = zeros(np,1);
    wout.y = zeros(np,1);
    wout.e = zeros(np,1);
    npix = zeros(np,1);
    for i = find(ibin>0)
        wout.x(ibin(i)) = wout.x(ibin(i)) + w1.x(i);
        wout.y(ibin(i)) = wout.y(ibin(i)) + w1.y(i);
        wout.e(ibin(i)) = wout.e(ibin(i)) + w1.e(i)^2;
        npix(ibin(i)) = npix(ibin(i)) + 1;
    end
    mask = npix>0;
    wout.x = wout.x(mask)./npix(mask);
    wout.y = wout.y(mask)./npix(mask);
    wout.e = sqrt(wout.e(mask))./npix(mask);    
    
%---------------------------------------------------------------------------------------------    
end

wout = spectrum(wout.x,wout.y,wout.e, w1.title, w1.xlab, w1.ylab, w1.xunit, w1.distribution);    
