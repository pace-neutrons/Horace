function [wcalc, p, dp, fixed]= w_fromfit (win)
% Returns a spectrum with the y values calculated at the x-values of an
% input spectrum using the latest parameters and function in Mfit.
%
% *** The function has been renamed from: w_fromfit  to: fromfit
%     Please type >> help fromfit    for how to use the function.

if nargout==1
    [wcalc]= fromfit (win);
elseif nargout==2
    [wcalc, p]= fromfit (win);
elseif nargout==3
    [wcalc, p, dp]= fromfit (win);
elseif nargout==4
    [wcalc, p, dp, fixed]= fromfit (win);
else
    error ('Check number of output arguments')
end
