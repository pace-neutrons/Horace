function wout = flip(w)
% SPECTRUM/FLIP  Reverses the order of the data in the x,y,e arrays
%                Handy if the data has been read from a file

warning off;    % suppress warning messages

nw = length(w);
if nw==1
    s=get(w);
    s.x = flipud(s.x); s.y = flipud(s.y); s.e = flipud(s.e);
    wout = spectrum(s);
else
    wout(1) = spectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        s=get(w(i));
        s.x = flipud(s.x); s.y = flipud(s.y); s.e = flipud(s.e);
        wout(i) = spectrum(s);
    end
end

warning on;
        