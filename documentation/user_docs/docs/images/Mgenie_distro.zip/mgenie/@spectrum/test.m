function [wout] = test(win,arg1,arg2,arg3)
% SPECTRUM/TEST - test rebin for point spectra
%
% Permitted formats:
%
%  w_out = test(w_in, delta)  rebins the data of W_IN into bins of width delta
%
%  w_out = test(w_in, xlo, delta, xhi)  rebins the data of W_IN into bins of width delta
%
%  w_out = test(w_in)         same as NBIN=1 i.e. W_OUT is just a copy of W_IN 
%
small = 1.0e-10;
if (nargin >= 1)
    if (~isa(win,'spectrum'))      % check if first argument is also a spectrum
        error ('Check first argument is a spectrum')
    end
end

if (nargin == 2)
    if (~isa(arg1,'double')| ~(length(arg1)==1 & (arg1>small)))      % check 2nd argument a single number
        error ('Check second argument is > 0')
    end
    xlo = min(win.x);
    xhi = max(win.x);
    delta = arg1;
elseif (nargin==4)
    xlo = arg1;
    delta = arg2;
    xhi = arg3;
else
    error ('Only two arguments (W_IN, DELTA)')
end
%
% Catch trivial case
% ----------------------
if (nargin == 1)
    wout=win;
    return
end
%
% non-trivial rebinning
% -------------------------
ny=length(win.y);
nx=length(win.x);
if (nx~=ny)
    error('Only permitted on point data')
end

nout = floor((xhi-xlo)/delta)+1;
xout = zeros(1,nout);
yout = zeros(1,nout);
eout = zeros(1,nout);
npix = zeros(1,nout);
ibin = floor((win.x-xlo)./delta)+1; % bin index for each point
for i=1:length(win.x)
    if (win.x(i) >= xlo & win.x(i) <= xhi)
        npix(ibin(i)) = npix(ibin(i)) + 1;
        xout(ibin(i)) = xout(ibin(i)) + win.x(i);
        yout(ibin(i)) = yout(ibin(i)) + win.y(i);
        eout(ibin(i)) = eout(ibin(i)) + win.e(i)^2;
    end
end
mask = npix>0;
xout = xout(mask)./npix(mask);
yout = yout(mask)./npix(mask);
eout = sqrt(eout(mask))./npix(mask);
%
wout=spectrum(xout,yout,eout, win.title, win.xlab, win.ylab, win.xunit, win.distribution);