function dl(w,xlo,xhi,ylo,yhi)
% SPECTRUM/DL Draws a line plot of a spectrum or array of spectra
%
%   >> dl(w)
%   >> dl(w,xlo,xhi)
%   >> dl(w,xlo,xhi,ylo,yhi)

global genie_max_spectra_1d

% Check spectrum is not too long an array
if length(w)>genie_max_spectra_1d
    error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
end

newplot = 1;
type = 'l';
fig_name='Genie_1D';
if (nargin==1)
    plot_main (newplot,type,fig_name,w);
elseif (nargin==3)
    plot_main (newplot,type,fig_name,w,xlo,xhi);
elseif (nargin==5)
    plot_main (newplot,type,fig_name,w,xlo,xhi,ylo,yhi);
else
    error ('Wrong number of arguments to DL')
end
