function tomfit (w, xrange, p, fixed)
% This function is used to send data contained in an mgenie spectrum to Mfit
% to be be fitted interactively.
%
% Syntax:
%   >> tomfit (w)
%
%   >> tomfit (w, xrange)
%
%   >> tomfit (w, xrange, p)
%
%   >> tomfit (w, xrange, p, fixed)
%
% where:
%   w       Mgenie spectrum to be fitted
%
%   xrange  Array giving values to be retained for fitting:
%           e.g. [12.3,14.5]            keep data in the range 12.3 =< x =< 14.5
%           e.g. [4.1,5.6;11.2,14.5]    keep 4.1=<x=<5.6 & 11.2=<x=<14.5
%
%   p       Starting parameter values
% 
%   fixed   Array of length(p), the fixed parameters (0: free, 1: fixed)
%           e.g. if 5 parameters, [0,1,1,0,1]  fix 2nd, 3rd, 5th.
%
% If you want to pass parameter values and/or fixed values, but not limit the
% x range, then call as
%
%   >> tomfit (w, [], p, fixed)
% or
%   >> tomfit (w, '', p, fixed)

% Original: JvD: 08-07-03
% Extended: TGP: 26-01-05


win= get(w);
xarr = win.x';
yarr = win.y';
earr = win.e';

% Data gets sent to mfit in point data format. In case of histogram data this means the bin centres.
if (length(xarr)~=length(yarr))
    xarr= 0.5*(xarr(1:end-1)+xarr(2:end));
end

% Remove data points with zero or negative error bars
ok_ebars = isfinite(earr) & earr>0;
if length(find(ok_ebars>0))==0
    error ('All points have error bars less than or equal to zero')
elseif length(find(ok_ebars==0))>0
    disp ('Points with zero, negative or undefined (infinite or NaN) error bars have been removed from fit')
end

% Remove data points with non-finite y values
ok_yvals = isfinite(yarr);
if length(find(ok_yvals>0))==0
    error ('All points have undefined (infinite or NaN) y-values')
elseif length(find(ok_ebars==0))>0
    disp ('Points with undefined (infinite or NaN) y-values have been removed from fit')
end

% Remove data points outside selected ranges
if nargin >=2
    if isnumeric(xrange) & size(xrange,2)==2 & length(xrange)>0
        ok_range = zeros(1,length(xarr));
        for i = 1:size(xrange,1)
            if xrange(i,2)-xrange(i,1) > 0
                ok_range(find(xarr>=xrange(i,1) & xarr<=xrange(i,2))) = 1;
            end
        end
        if length(find(ok_range>0))==0
            error ('No points lie inside the selected range(s)')
        end
    else
        ok_range = ones(1,length(xarr));
    end
else
    ok_range = ones(1,length(xarr));
end

% Get list of points to fit
sel = ok_ebars & ok_yvals & ok_range;
if length(find(sel>0))==0
    error ('No points left to fit')
end

if nargin==1|nargin==2
    tomfit(xarr, yarr, earr, sel);
elseif nargin==3
    tomfit(xarr, yarr, earr, sel, p);
elseif nargin==4
    tomfit(xarr, yarr, earr, sel, p, fixed);
else
    error ('Check number of arguments passed to tomfit')
end