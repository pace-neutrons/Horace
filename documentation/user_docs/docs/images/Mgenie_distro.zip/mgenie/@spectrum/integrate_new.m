function ans = integrate_new(w1,xlo,xhi)
% SPECTRUM/INTEGRATE  Integrate spectrum W between XLO and XHI:
%    >> ans = integrate(w,xlo,xhi)
%       - If w is a single spectrum, then ans=[integral, error]
%       - If w is an array of spectra, then ans is a spectrum, with the x,y,e arrays
%         being the spectrum index i=1,2...length(w)); y(i), e(i) the integral and error.
%
% Syntax:
%   >> ans = integrate (w)              % integrate over full spectrum
%   >> ans = integrate (w, xlo, xhi)    % integrate between selected range

if (nargin==1)
    xlo = w1(1).x(1);
    xhi = w1(1).x(end);
elseif (nargin==3)
    if (~isa(xlo,'double') | ~isa(xhi,'double'))
        error ('integration limits must be real')
    end
else
    error ('wrong number of arguments')
end


if (length(w1)==1)  % single spectrum
    [ans.val,ans.err] = spectrum_integrate(w1.x, w1.y, w1.e, xlo, xhi);
    
else                % if array of spectra, produce spectrum as output
    control_ref = read_labels(w1(1).title);
    n = length(w1);
    x = mgenie_control_y_values(w1); % read values from control information, if sufficient present
    if size(x,1)==0 % not present
        x=linspace(0.5,n+0.5,n+1);
        xlabel = 'Spectrum index';
    else
        if size(x,1)==2 % boundaries
            if n > 1    % more than one spectrum
                if x(1,2:n)==x(2,1:n-1)   % form a single set of bin boundaries
                    x = [x(1,1),x(2,1:n)];  % create array of bin boundaries
                else
                    x = 0.5*sum(x,2);   % must get centres and treat as point data
                end
            else
                x = x'; % make a row vector
            end
        end
        if isfield(control_ref,'mgenie_control_y_label')    % y axis label
            xlabel = control_ref.mgenie_control_y_label;
        else
            xlabel = 'Spectrum y value';
        end
    end    
    y=zeros(1,n);
    e=zeros(1,n);
    for i = 1:n
        [y(i),e(i)] = spectrum_integrate(w1(i).x, w1(i).y, w1(i).e, xlo, xhi);
    end
    ylabel = ['Integral from ', num2str(xlo), ' to ', num2str(xhi), ' ', w1(1).xunit];
    if isfield(control_ref,'mgenie_control_x_short_label')    % x axis short label for 
        ylabel = [ylabel,' along ',control_ref.mgenie_control_x_short_label];
    else
        ylabel = [ylabel,' along x-axis'];
    end
    
    % create main title:
    % --------------------
    % If there is a custom title for the array of spectra, keep just that; else strip away all
    % mgenie_control information to avoid misleading interpretations later on
    if isfield(control_ref,'mgenie_control_title')
        title = cellstr(control_ref.mgenie_control_title);
    else
        temp = w1(1).title;
        if ischar(w1(1).title)  % can be cellarray of strings, or array of character strings
            temp = cellstr(temp);
        end
        % strip out any lines beginning mgenie_control (mgenie control information) from title
        j = 1;
        for i=1:length(temp)
            if isempty(strfind(temp{i},'mgenie_control'))
                title(j) = temp(i);
                j = j + 1;
            end
        end
    end

    ans = spectrum(x,y,e,title,xlabel,ylabel,'',0);
end
