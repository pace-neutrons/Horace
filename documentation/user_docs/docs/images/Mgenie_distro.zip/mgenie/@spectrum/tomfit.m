function tomfit (w, xrange, p, fixed)
% This function is used to send data contained in an mgenie spectrum to Mfit
% to be be fitted interactively.
%
% Syntax:
%   >> tomfit (w)
%
%   >> tomfit (w, xrange)
%
%   >> tomfit (w, xrange, p)
%
%   >> tomfit (w, xrange, p, fixed)
%
% where:
%   w       Mgenie spectrum to be fitted
%
%   xrange  Array giving values to be retained for fitting:
%           e.g. [12.3,14.5]            keep data in the range 12.3 =< x =< 14.5
%           e.g. [4.1,5.6;11.2,14.5]    keep 4.1=<x=<5.6 & 11.2=<x=<14.5
%
%   p       Starting parameter values
% 
%   fixed   Array of length(p), the fixed parameters (0: free, 1: fixed)
%           e.g. if 5 parameters, [0,1,1,0,1]  fix 2nd, 3rd, 5th.
%
% If you want to pass parameter values and/or fixed values, but not limit the
% x range, then call as
%
%   >> tomfit (w, [], p, fixed)
% or
%   >> tomfit (w, '', p, fixed)

% Original: JvD: 08-07-03
% Extended: TGP: 26-01-05


win= get(w);
xarr = win.x';
yarr = win.y';
earr = win.e';

% Data gets sent to mfit in point data format. In case of histogram data this means the bin centres.
if (length(xarr)~=length(yarr))
    xarr= 0.5*(xarr(1:end-1)+xarr(2:end));
end

% Determine which points to fit
if exist('xrange')
    sel = retain_for_fit(num2cell(xarr,1), yarr, earr, xrange, [], []);
else
    sel = retain_for_fit(num2cell(xarr,1), yarr, earr, [], [], []);
end
if ~any(sel)
    error ('Abandoning fit as no points left to fit')
end

if nargin==1|nargin==2
    tomfit(xarr, yarr, earr, sel);
elseif nargin==3
    tomfit(xarr, yarr, earr, sel, p);
elseif nargin==4
    tomfit(xarr, yarr, earr, sel, p, fixed);
else
    error ('Check number of arguments passed to tomfit')
end
