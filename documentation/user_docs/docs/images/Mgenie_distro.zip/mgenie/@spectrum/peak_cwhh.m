function [xcent,xpeak,fwhh,xneg,xpos,ypeak]=peak_cwhh(w,fac)
% Find centre of half-width half height in a spectrum
%
%   >> [xcent,xpeak,fwhh,xneg,xpos,ypeak]=peak_cwhh(w,fac)
%
%   w       mgenie spectrum
%   fac     Factor of peak height at which to determine the centre-height position
%           (default=0.5 i.e. centre-fwhh)
%   
%   xcent   centre of factor-of-height
%   xpeak   Peak position
%   ypeak   Peak height
%   fwhh    full width at factor-of-height
%   xneg    factor-of-height on lower x side
%   xpos    factor-of-height on higher x side

if nargin==1
    fac=0.5;
end

nw = length(w);
if nw==1
    [xcent,xpeak,fwhh,xneg,xpos,ypeak]=peak_cwhh_internal(w,fac);
    if isnan(xcent)
        warning('No peak defined by half-height points')
    end
else
    xpeak=zeros(size(w));
    xcent=zeros(size(w));
    fwhh=zeros(size(w));
    xneg=zeros(size(w));
    xpos=zeros(size(w));
    ypeak=zeros(size(w));
    for i=1:nw
        [xcent(i),xpeak(i),fwhh(i),xneg(i),xpos(i),ypeak(i)]=peak_cwhh_internal(w(i),fac);
        if isnan(xcent)
            warning(['No peak defined by half-height points - spectrum',num2str(i)])
        end
    end
end


function [xcent,xpeak,fwhh,xneg,xpos,ypeak]=peak_cwhh_internal(w,fac)
% centres of bins
if length(w.x)~=length(w.y)
    xc=0.5*(w.x(1:end-1)+w.x(2:end));
else
    xc=w.x;
end

% Find the points that straddle the half-height
[ymax,imax]=max(w.y);
xpeak=xc(imax);
ypeak=w.y(imax);
im=max(find((w.y(1:imax)-fac*ymax)<0));
ip=min(find((w.y(imax:end)-fac*ymax)<0))+imax-1;

% ensure peak is defined
if isempty(im)||isempty(ip)
    xcent=nan; fwhh=nan; xneg=nan; xpos=nan;
    return
end

% interpolate to get half-height position
xneg = (xc(im)*(w.y(im+1)-fac*ymax)+xc(im+1)*(fac*ymax-w.y(im)))/(w.y(im+1)-w.y(im));
xpos = (xc(ip-1)*(w.y(ip)-fac*ymax)+xc(ip)*(fac*ymax-w.y(ip-1)))/(w.y(ip)-w.y(ip-1));

xcent = 0.5*(xneg+xpos);
fwhh = xpos-xneg;
