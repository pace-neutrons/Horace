function [wout] = sum_work(w, iw_lo_in, iw_hi_in)
% SPECTRUM/SUM_WORK - Sums the spectra between IW_LO and IW_HI in the array of 
%                     spectra, W. The output is also a spectrum. The routine
%                     rebins the data to the x values of W(IW_LO).
%
% Syntax:
%   >> wout = sum_work (w)                  % adds all spectra
%   >> wout = sum_work (w, iw_lo, iw_hi)    % adds from iw_lo to iw_hi
%

if (~isa(w,'spectrum'))
    error ('Check first argument is a spectrum')
end

if (nargin <=3)
    % check that the input arguments are valid
    if (nargin==1)  % just the tofspectrum
        iw_lo = 1;
        iw_hi = length(w);
    else
        if isa(iw_lo_in,'double')
            iw_lo = iw_lo_in;
        else
            error ('Check argument type of IW_LO')
        end
        if nargin==3
            if isa(iw_hi_in,'double')
                iw_hi = iw_hi_in;
            else
                error ('Check argument type of IW_HI')
            end
        else
            iw_hi = iw_lo;
        end
        nw = length(w);
        if (iw_lo<1|iw_lo>iw_hi|iw_hi>nw)
            error (['Check 1=< IW_LO =< IW_HI =< length(W)=',num2str(nw)])
        end
    end

    if iw_lo == iw_hi
        wout = w(iw_lo);
    else
        wout = w(iw_lo);
        for i=iw_lo+1:iw_hi
            wtemp = rebin(w(i),wout);
            wout = wout + wtemp;
        end
    end
else
    error ('Check number of arguments')
end
