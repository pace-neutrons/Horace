function [wout] = rebunch(w, nbin)
% SPECTRUM/REBUNCH - rebunch data points into groups of nbin points.
%
% Syntax:
%
%   >> w_out = rebunch(w_in, nbin)   rebunches the data of W_IN in groups of nbin
%
%   >> w_out = rebunch(w_in)         same as NBIN=1 i.e. W_OUT is just a copy of W_IN
%

if (~isa(w,'spectrum'))
    error ('Check first argument is a spectrum')
end

% Catch trivial case:
if (nargin==1)
    wout = w;
    return
end

% Perform rebunch:
if (nargin == 2)
    nw = length(w);
    if (nw==1)
        wout = single_rebunch (w, nbin);
    else
        wout(1) = spectrum;
        wout = repmat(wout,1,nw);
        for i=1:nw
            wout(i) = single_rebunch (w(i), nbin);
        end
    end
else
    error ('Check number of arguments')
end
