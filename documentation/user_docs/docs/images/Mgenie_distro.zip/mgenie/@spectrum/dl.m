function dl(w,varargin)
% SPECTRUM/DL Draws a line plot of a spectrum or array of spectra
%
%   >> dl(w)
%   >> dl(w,xlo,xhi)
%   >> dl(w,xlo,xhi,ylo,yhi)
%
% Advanced use:
%   >> dl(w,...,fig_name)       % draw with name = fig_name

global genie_max_spectra_1d

% Check spectrum is not too long an array
if length(w)>genie_max_spectra_1d
    error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
end

newplot = 1;
type = 'l';
fig_name='Genie_1D';

narg=nargin-1;
if nargin>1 && ischar(varargin{end}) && ~isempty(varargin{end})
    fig_name=varargin{end};
    narg=narg-1;
end
if (narg==0)
    plot_main (newplot,type,fig_name,w);
elseif (narg==2)
    plot_main (newplot,type,fig_name,w,varargin{1:2});
elseif (narg==4)
    plot_main (newplot,type,fig_name,w,varargin{1:4});
else
    error ('Wrong number of arguments to DL')
end
