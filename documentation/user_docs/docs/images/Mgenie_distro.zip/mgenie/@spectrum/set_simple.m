function w = set_simple(w, varargin)
% SPECTRUM/SET_SIMPLE  Set fields in a spectrum.
%
%   *** DOES NOT CHECK TYPE OR FOR CONSISTENCY OF INPUT
%       FOR USE INSIDE CAREFULLY CHECKED RUNCTIONS ONLY ***
%
% Syntax:
%   The output spectrum name must the same as the input spectrum name.
%   Valid fields are:  x, y, e, title, xlab, ylab, xunit, distribution
%   (For further description of the fields type >> help spectrum)
%
%   Checks are performed on the consistency of the input - for example, the net result 
%   after any changes to the x, y, and e arrays must be that the lengths of y and e are
%   the same, and that the length of x must be the same or one greater than y & e.
%
% e.g.
%   >> xx = [3,4,5,6,7,8,9,10]
%   >> w = set (w, 'x', xx)
%
%   >> yy = [4,2,6,9,4,7,1,15]
%   >> new_title = 'Hello there'
%   >> w = set (w, 'title', new_title, 'y', yy)

m = floor(length(varargin)/2);
if (length(varargin)-2*m == 1)  % must have even number of argumnents
    error ('Check number of arguments to set')
end

for i = 1:m
    prop_name = varargin{2*i-1};
    switch prop_name
        case 'x'
            w.x = varargin{2*i};
        case 'y'
            w.y = varargin{2*i};
        case 'e'
            w.e = varargin{2*i};
        case 'title'
            w.title = varargin{2*i};
        case 'xlab'
            w.xlab = varargin{2*i};
        case 'ylab'
            w.ylab = varargin{2*i};
        case 'xunit'
            w.xunit = varargin{2*i};
        case 'distribution'
            w.distribution = varargin{2*i};
        otherwise
            error ([prop_name ' is not a valid property of a spectrum'])
        end
end