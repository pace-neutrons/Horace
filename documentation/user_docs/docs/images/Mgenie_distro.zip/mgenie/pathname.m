function path = pathname (disk_in, dir_in)
% pathname - makes path from disk and directory list properly looking after
%           the insertion of file separator characters (including one at the
%           end of the path)
%
%           In particular, if '\' or '\\' or '/' is used a file separator, then
%           these are replaced with the correct system file separator
% 
% Syntax:
%   >> file_name = pathname (disk, dir)
%
%   disk    Disk or userpath (see >> help set_globalpath)
%   dir     Directory path
%
% e.g.
%   >> file_name = pathname ('c:', 'f90')   % if a directory is given, assumes
%       file_name = 'c:\f90\'               % that 1st argument is a disk
%
%   >> file_name = pathname ('data_path', '')   if no disk given, assumes is a path
%
%   >> file_name = pathname ('c:\','')      % to force interpretation as a disk
%
disk = fliplr(deblank(fliplr(deblank(disk_in))));  % in matlab 7 can use strtrim
if nargin==2
    dir = fliplr(deblank(fliplr(deblank(dir_in))));  % in matlab 7 can use strtrim
else
    dir = '';
end

disk = strrep(disk,'\\',filesep);
disk = strrep(disk,'\',filesep);
disk = strrep(disk,'/',filesep);
if ~isempty(disk)
    if disk(end:end)==filesep
        if ~isempty(dir)
            disk = disk(1:end-1);
        end
    elseif disk(end:end)~=':'
        disk = [disk,':'];
    end
end

dir = strrep(dir,'\\',filesep);
dir = strrep(dir,'\',filesep);
dir = strrep(dir,'/',filesep);
if ~isempty(dir)
    if dir(1:1)~=filesep; dir = [filesep,dir]; end
    if dir(end:end)~=filesep; dir = [dir,filesep]; end
end

path = [disk, dir];