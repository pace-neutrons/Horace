function x1 = get_primary
% Get primary flight path. Inverse function of SET_PRIMARY
%
% Syntax:
%   >> x1 = get_primary (efix) 
%
% To view current value, use set_primary with no arguments:
%   >> set_efix


global genie_handle
global genie_efix genie_x1 genie_emode
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

x1 = genie_x1;
