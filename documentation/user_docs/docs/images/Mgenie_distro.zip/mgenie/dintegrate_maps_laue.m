function wsum = dintegrate_maps_laue (w,dlo,dhi)
% Integrate the output of dspace_maps_laue over a dspacing range, and create
% an array of spectra that can be plotted with mplot command
%
% Syntax:
%   >> wsum = dintegrate_maps_laue (w,dlo,dhi)
%
%

wtemp = integrate(w,dlo,dhi);
temp = get(wtemp);

npix = 64;
ndet = length(temp.y)/npix;

xx = 0.5+(0:ndet);
yy=reshape(temp.y,npix,ndet);
ee=reshape(temp.e,npix,ndet);

wsum = spectrum(xx,zeros(1,ndet),zeros(1,ndet),add_title(temp.title,temp.ylab),'Detector number','Pixel number','',0);
wsum = repmat(wsum,1,npix);
for i=1:npix
    irow = npix-i+1;    % reverse row order, spectra are numbered from top to bottom in the 4to1 mapping
    wsum(i) = set(wsum(i),'y',yy(irow,:),'e',ee(irow,:));
end