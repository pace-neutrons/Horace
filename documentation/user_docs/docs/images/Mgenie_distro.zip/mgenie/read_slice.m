function w = read_slice (file)
% READ_SLICE Reads the x,y,e arrays of x coordinate, corresponding y values, errors on y from a slice file
%
% Syntax:
%   >> w = read_slice (file)    % read from named file
%   >> w = read_slice           % prompts for file
%

% Get file name - prompt if file does not exist (using file to set default seach location and extension
% -----------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.slc');
end
if (isempty(file_internal))
    error ('No file given')
end

% Read slice
% --------------------
slice = get_slice(file_internal);
w = slice_to_spectrum(slice);
