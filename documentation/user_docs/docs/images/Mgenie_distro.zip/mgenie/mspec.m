function warr = mspec (varargin)

% Read a group of spectra into an array of time-of-flight spectra
%
% Syntax:
%
%   >> w = mspec(is)                    Load spectrum IS into workspace W
%   >> w = mspec(is_lo, is_hi)          Loads spectra IS_LO to IS_HI into array of workspaces,
%                                      one workspace per spectrum
%   >> w = mspec(is_lo, is_hi, step)    Loads spectra IS_LO to IS_HI into array of workspaces,
%                                      one workspace per STEP spectra
%
%   >> w = mspec(map)                   Map is a cell array of 1D arrays, each array containing
%                                      the spectrum numbers for one workspace.
%                                       The map cell array can be read from a file using the
%                                      function load_map (type >> help load_map)
%
%   The arguments can be vectors. The result is equivalent to the concatenation
%   of mspec applied to the arguments element-by-element i.e.
%       >> w = mspec (is_lo, is_hi, step)
%   is equivalent to [
%       >> mspec(is_lo(1),is_hi(1),step(1)), mspec(is_lo(2),is_hi(2),step(2)), ...]
%
%
% The function can take further optional arguments that control the masking, how the
% detector parameters are averaged over the spectra contributing to a workspace, and
% using mapping and mask information for the just first period to get data from subsequent periods:
%
%   >> w = mspec (mapping_description [,'mask', mask_array] [,av_mode] [,'period', iperiod )
%
%       mask_array          Optional array of masked spectra (default is no masking)
%
%   By default, the time-of-flight parameters are returned as the average for the spectra in
%   each block. The method by which the averaging is performed can be controlled with a
%   final parameter:
%
%       av_mode             Averaging scheme (default is 'average'):
%               = 'average'         take the average for all spectra in a group
%               = 'min_twotheta'    take parameters from the detector element with minimum twotheta
%               = 'max_twotheta'    take parameters from the detector element with minimum twotheta
%               = 'none'            dummy call - no parameters calculated, and w is returned as a double
%                                   with value zero.
%
%       iperiod             If a period number is given, then if the map and mask information apply 
%                           to the first period then that information is used to get an array of spectra
%                           from the period iperiod. That is, the spectrum numbers are offset by the
%                           appropriate number to correspond to period iperiod. If the mapping and mask
%                           spectra are not confined to the first period when using this qualifier, then
%                           an error message is returned.
%
%                           An array of period numbers can be given. In this case an array of output
%                           is produced according to the rules above, and then is repeated for each
%                           period so that the final result is equivalent to the concatenation of repeated
%                           calls to mspec, once for each period in turn.

%tic

if nargin==0
    error ('Must give arguments')
end


% Find qualifiers and their values, and check number of parameters
qualifier = {'mask','period','min_twotheta','max_twotheta','average','none'};
takes_value = [1,1,0,0,0,0];
nstart = 1;
[par,present,index,message]=parse_qualifiers(qualifier,takes_value,varargin,nstart);
if ~isempty(message)
    error(message)
end
if length(par)<1
    error ('Check input arguments to mspec')
elseif length(par)~=par(end) | par(end)>3
    error ('Check input arguments to mspec')    % must have parameters must appear before qualifiers, and no more than three parameters
else
    narg_map = length(par);
end

if present.mask
    mask = varargin{index.mask};
    if ~isempty(mask)
        if ~(length(size(mask))==2 & min(size(mask))==1)|~isnumeric(mask)
            error ('ERROR: List of masked spectra must be 1D array')
        end
    else
        mask = [];
    end
else
    mask = [];
end

if present.min_twotheta+present.max_twotheta+present.average+present.none > 1
    error ('ERROR: Choose only one averaging mode')
elseif present.min_twotheta
    av_mode = 'min_twotheta';
elseif present.max_twotheta
    av_mode = 'max_twotheta';
elseif present.average
    av_mode = 'average';
elseif present.none
    av_mode = 'none';
else
    av_mode = '';
end

if present.period
    iperiod = varargin{index.period};
    if ~isnumeric(iperiod)|~(length(size(iperiod))==2 & min(size(iperiod))==1)
        error ('ERROR: Period must be a scalar number or 1D array')
    elseif iperiod < 1
        error ('ERROR: Period must be a positive integer or array of positive integers')
    end
end

% check remaining arguments are valid. To be valid, they must all be numeric, and number 1,2 or 3
% *** ANY CHANGES HERE SHOULD BE PROPAGATED ACCORDINGLY TO MSPEC, WHICH DOES VERY SIMILAR PREPARATION FOR THE CALL TO MSPEC_CORE ***

nsp = double(genie_get('nsp1'));
nper= double(genie_get('nper'));
nsptot = nper*(nsp+1) - 1;    % maximum spectrum number in a multi-period run

if narg_map==1 & iscell(varargin{1})
    map = varargin{1};
    ok = zeros(1,length(map));
    for i=1:length(map)
        ok = isnumeric(map{i}) & length(size(map{i}))==2 & min(size(map{i}))==1;
    end
    if min(ok)>0.5
        nw = length(map);
        ns = zeros(1,nw);
        for i=1:nw
            ns(i)=length(map{i});
        end
        nscum=[0,cumsum(ns)];
        s = zeros(1,nscum(end));
        for i=1:nw
            s(nscum(i)+1:nscum(i+1)) = map{i};
        end
    else
        error ('Check contents of map cellarray ')
    end
elseif narg_map==1
    if isnumeric(varargin{1}) & length(size(varargin{1}))==2 & min(size(varargin{1}))==1
        s  = varargin{1};
        ns = ones(1,length(s));
    else
        error ('Check size or type of mapping arrays')
    end
elseif narg_map==2
    if isnumeric(varargin{1}) & length(size(varargin{1}))==2 & min(size(varargin{1}))==1 ...
            & isnumeric(varargin{2}) & length(size(varargin{2}))==2 & min(size(varargin{2}))==1
        is_lo = varargin{1};
        is_hi = varargin{2};
        if length(is_lo)~=length(is_hi)
            error ('Check length of arrays is_lo and is_hi are the same')
        elseif min(is_lo) < 0 | max(is_hi)>nsptot
            error (['Check spectrum numbers lie in range 0 - ',num2str(nsptot)])
        end

        nsper = is_hi-is_lo+1;      % no. spectra in each range
        if min(nsper) < 1
            error ('Check that is_lo <= is_hi')
        end
        nscum = [0,cumsum(nsper)];   
        s = zeros(1,nscum(end));    % initialise array to hold spectrum numbers
        for i = 1:length(is_lo)
            s(nscum(i)+1:nscum(i+1)) = linspace(is_lo(i),is_hi(i),nsper(i));    % fill array with spectrum numbers
        end
        
        ns = ones(1,nscum(end));
    else
        error ('Check size or type of mapping arrays')
    end       
elseif narg_map==3
    if isnumeric(varargin{1}) & length(size(varargin{1}))==2 & min(size(varargin{1}))==1 ...
            & isnumeric(varargin{2}) & length(size(varargin{2}))==2 & min(size(varargin{2}))==1 ...
            & isnumeric(varargin{3}) & length(size(varargin{3}))==2 & min(size(varargin{3}))==1
        is_lo = varargin{1};
        is_hi = varargin{2};
        step  = varargin{3};
        if length(is_lo)~=length(is_hi)
            error ('Check length of arrays is_lo and is_hi are the same')
        elseif min(is_lo) < 0 | max(is_hi)>nsptot
            error (['Check spectrum numbers lie in range 0 - ',num2str(nsptot)])
        elseif min(step)<1
            error ('Check step > 0')
        end
        if length(step)==1  % if step is a scalar, apply to all paris of elements of is_lo, is_hi
            step = repmat(step,1,length(is_lo));
        end
        
        nsper = is_hi-is_lo+1;      % no. spectra in each range
        if min(nsper) < 1
            error ('Check that is_lo <= is_hi')
        end
        nscum = [0,cumsum(nsper)];   
        s = zeros(1,nscum(end));    % initialise array to hold spectrum numbers
        for i = 1:length(is_lo)
            s(nscum(i)+1:nscum(i+1)) = linspace(is_lo(i),is_hi(i),nsper(i));    % fill array with spectrum numbers
        end

        nwper = 1 + floor((is_hi-is_lo)./step);  % no. workspaces in each range
        nwsum = [0,cumsum(nwper)];
        ns = zeros(1,nwsum(end));               % initialise array to hold no. spectra in each workspace
        last_step = nsper - step.*(nwper-1);    % no. spectra in last step
        for i = 1:length(is_lo)
            ns(nwsum(i)+1:nwsum(i+1)) = step(i);
            ns(nwsum(i+1)) = last_step(i);
        end
    else
        error ('Check size or type of mapping arrays')
    end        
end

% If period number given, offset the spectrum numbers accordingly. The mapping and masking information must be for the first period only
% if a period number is given.
if present.period
    if min(iperiod) < 1 | max(iperiod) > nper
        error (['ERROR: Period number must lie in range 1-',num2str(nper)])
    else
        s_min = min(s);
        s_max = max(s);
        if s_min<0 | s_max>nsp
            error (['ERROR: Spectra in mapping must lie in range 1-',num2str(nsp),' if period number given'])
        end
        m_min = min(s);
        m_max = max(s);
        if m_min<0 | m_max>nsp
            error (['ERROR: Spectra in mask array must lie in range 1-',num2str(nsp),' if period number given'])
        end

        np = length(iperiod);
        offset = (nsp+1)*(iperiod-1);
        ns = repmat(ns,1,np);   % the array of output spectra is repeated for each period
        s = repmat(s',1,np);    % repeat s as a series of column vectors
        for i=1:np
            s(:,i)=s(:,i)+offset(i);
        end
        s = reshape(s,1,prod(size(s)));
        if length(mask)~=0
            if size(mask,2)~=1
                mask = mask';       % ensure column vector
            end
            mask = repmat(mask,1,np);   % repeat mask as a series of column vectors
            for i=1:np
                mask(:,i)=mask(:,i)+offset(i);
            end
            mask = reshape(mask,1,prod(size(mask)));
        end
    end
end
        

% t=toc;
% disp('------------------------------------------------------------------')
% disp(['   preparation of input parameters: ',num2str(t)])
% disp('------------------------------------------------------------------')        

warr = mspec_core (ns, s, mask, av_mode);

% t=toc;
% disp(['         Time to read data (mspec): ',num2str(t)])