function display(w)
% test
%
%   display(w)
%
% If array of spectra
if (max(size(w))>1)
    if (length(size(w))<=2)
        disp(['           ',inputname(1),' = [',num2str(size(w,1)),'x',num2str(size(w,2)),' tofspectrum]'])
    else
        disp(['           ',inputname(1),' = [',num2str(length(size(w))),'-dimensional array of class tofspectrum]'])
    end
    disp(' ')
    return
end

disp([inputname(1),'.spectrum ='])
display(w.spectrum)
disp(' ')
disp(['  ', inputname(1),'.tofpar ='])
display(w.tofpar)
disp(' ')
disp(['   ',inputname(1),'.units = ',w.units])