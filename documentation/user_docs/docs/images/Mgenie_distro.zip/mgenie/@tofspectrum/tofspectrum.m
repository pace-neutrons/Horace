function w = tofspectrum(varargin)
% TOFSPECTRUM create a time-of-flight spectrum, w
%
% w has three objects: w.units (a character array), w.spectrum (a spectrum object) and w.tofpar(time-of-flight parameters)
%
% Syntax
%   w = tofspectrum (w_in)  
%   if w_in is a tofspectrum , then makes a copy of w_in
%      w_in is a spectrum, then appends a dummy set of tof parameters and blank units to create a tofspectrum
%      w_in is a structure that has the fields that constitute a spectrum or a tofspectrum, then
%    creates an output tofspectrum object.
%
%   w = tofspectrum (spec, par, units)
%      spec is a spectrum, par is time-of-flight parameter object, and units is the units
%

% use a trick to get field names and remove field names to make this routine independent of changes
% to spectrum or tofpar fields

superiorto('spectrum');
switch nargin
case 0  % default spectrum - empty fields
    w.units = '';
    s = spectrum;
    p = tofpar;
    w = class (w, 'tofspectrum', s, p);
case 1
    if (isa(varargin{1},'tofspectrum'))
        w = varargin{1};
    elseif (isa(varargin{1},'spectrum'))
        w.units = '';
        p = tofpar;
        w = class (w, 'tofspectrum', varargin{1}, p);
    elseif (isa(varargin{1},'struct'))
        fields_in = fieldnames(varargin{1});
        fields_spectrum = fieldnames(spectrum);
        fields_tofpar = fieldnames(tofpar);
        fields_tofspectrum = [{'units'}; fields_spectrum; fields_tofpar];
        fields_tofspectrum_also_ok = [fields_spectrum; fields_tofpar; {'units'}];
        if (length(fields_in)==length(fields_spectrum))
            if (min(strcmp(fields_in,fields_spectrum))==1)  % fields are the same as those for a spectrum
                w.units = '';
                s = spectrum (varargin{1});
                p = tofpar;
                w = class (w, 'tofspectrum', s, p);
            else
                error ('Check fields of input structure - A')
            end
        elseif (length(fields_in)==length(fields_tofspectrum))
            if (min(strcmp(fields_in,fields_tofspectrum))==1||min(strcmp(fields_in,fields_tofspectrum_also_ok))==1)  % fields are the same as those for a tofspectrum
                s = spectrum(rmfield(varargin{1}, [{'units'};fields_tofpar]));  % create spectrum after removing tofpar fields
                rmfield(varargin{1}, fields_spectrum)
                p = tofpar(rmfield(varargin{1}, [{'units'};fields_spectrum]));  % create tofpar after removing spectrum fields
                if (isa(varargin{1}.units,'char') & size(varargin{1}.units,1)==1) % single character row
                    w.units = varargin{1}.units;
                else
                    error ('Wrong type for units field')
                end
                w = class (w, 'tofspectrum', s, p);
            else
                error ('Check fields of input structure - B')
            end
        else
            error ('Check fields of input structure - C')
        end
    else
        error ('Wrong argument type for tofspectrum constructor')
    end
    
case 3
    % must check that varargin{1} is a spectrum, but not a tofspectrum. As tofspectrum is a child of a spectrum, then
    % isa(x,'spectrum') is true if x is a tofspectrum. Similarly, isa(x,'tofpar') is true.
    if ((isa(varargin{1},'spectrum') & ~isa(varargin{1},'tofspectrum')) & (isa(varargin{2},'tofpar') & ~isa(varargin{2},'tofspectrum')) ...
            & (isa(varargin{3},'char') & (size(varargin{3},1)==0|size(varargin{3},1)==1)))
        w.units = varargin{3};
        w = class (w, 'tofspectrum', varargin{1}, varargin{2});
    else
        error ('Wrong argument types for tofspectrum constructor')
    end
    
otherwise
    error ('Wrong number of input arguments for spectrum constructor')
end
