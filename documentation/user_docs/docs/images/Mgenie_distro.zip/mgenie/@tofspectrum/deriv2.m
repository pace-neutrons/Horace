function wout = deriv2(w)
% TOFSPECTRUM/DERIV2  Numerical second derivative of a tofspectrum

nw = length(w);
wout(1) = tofspectrum;
wout = repmat(wout,1,nw);
for i=1:nw
    spectrum = deriv2 (w(i).spectrum);
    par = w(i).tofpar;
    wtemp.units = w(i).units;
    wout(i) = class(wtemp, 'tofspectrum', spectrum, par);
end
