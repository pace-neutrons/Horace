function w = set_par (w, varargin)
% TOFSPECTRUM/SET_PAR  Set a tofspectrum with parameters for units conversion
%
% Input and output arguments must be the same.
% Values can be entered in two ways:
%  - Follow the name of the tof spectrum (w) with numerical values for emode, delta, x1, x2, twotheta, azimuth, efix
%    If values are omitted, then the user is prompted for them
%
%  e.g.  w_a1 = set_par (w_a1, 1, 1.7, 12, 6, 3.2626, 180, 55)
%
%  - Follow the name of the tof spectrum (w) with a time-of-flight parameter object
%
%  e.g.  w_a1 = set_par (w_a1, par)
%
%  - Follow the name of the tof spectrum (w) with the name and value for any number of emode, delta, ... efix
%
%  e.g.  >> w_a1 = set_par (w_a1, 'efix', 55, 'delta', 1.7)
%

% check if input following a tofspectrum is up to 7 numbers

nargin = length(varargin);
numeric_values = 0;
for i=1:nargin
    numeric_values = numeric_values + (max(size(varargin{i}))==1 & isa(varargin{i},'double'));
end
nargin_even = (nargin-2*floor(nargin/2))==0;
    
if (nargin==1 & isa(varargin{1},'tofpar'))
    par = varargin{1};
    
elseif ( nargin <=7 & numeric_values==nargin )
    par = get(w.tofpar);
    % --------- Emode ----------------
    if (numeric_values>=1)
        emode = varargin{1};
    else
        emode = input ('Enter EMODE (0=elastic, 1=direct geometry, 2=indirect geometry : ');
        if (isempty(emode))
           emode = par.emode;
         end
    end
    if (emode <0 | emode > 2)
         error ('EMODE must equal 0,1 or 2 for elastic, direct geometry or indirect geometry')
    end
     % --------- Delta ----------------
    if (numeric_values>=2)
        delta = varargin{2};
    else
        delta = input ('Enter detector offset time (microseconds) : ');
        if (isempty(delta))
            delta = par.delta;
        end
    end
    % --------- X1 ----------------
    if (numeric_values>=3)
        x1 = varargin{3};
    else
        x1 = input ('   Enter primary flight path (m) : ');
        if (isempty(x1))
            x1 = par.x1;
        end
    end
    if (x1 <=0)
        error ('Secondary flight path must be greater than zero')
    end
    % --------- X2 ----------------
    if (numeric_values>=4)
        x2 = varargin{4};
    else
        x2 = input (' Enter secondary flight path (m) : ');
        if (isempty(x2))
            x2 = par.x2;
        end
    end
    if (x2 <=0)
        error ('Secondary flight path must be greater than zero')
    end
    % --------- Twotheta ----------------
    if (numeric_values>=5)
        twotheta = varargin{5};
    else
        twotheta = input ('    Enter scattering angle (deg) : ');
        if (isempty(twotheta))
            twotheta = par.twotheta;
        end
    end
    % --------- Azimuth ----------------
    if (numeric_values>=6)
        azimuth = varargin{6};
    else
        azimuth = input ('     Enter azimuthal angle (deg) : ');
        if (isempty(azimuth))
            azimuth = par.azimuth;
        end
    end
    % --------- Efix ----------------
    if (numeric_values>=7)
        efix = varargin{7};
    else
        if (emode ~= 0)
            efix = input ('Enter fixed neutron energy (meV) : ');
            if (isempty(efix))
                efix = par.efix;
            end
        else
            efix = 0;
        end
    end
    par = tofpar (emode, delta, x1, x2, twotheta, azimuth, efix);
                
elseif (nargin_even)
    % the following is essentially the same as TOFPAR/SET. We have to repeat the code, as cannot pass
    % the varargin to TOFPAR/SET
    m = floor(nargin)/2;
    % check all input properties are OK before changing the spectrum properties:
    par = get(w.tofpar);
    emode_str   ='par.emode';
    delta_str   ='par.delta';
    x1_str      ='par.x1';
    x2_str      ='par.x2';
    twotheta_str='par.twotheta';
    azimuth_str ='par.azimuth';
    efix_str    ='par.efix';
    units = w.units;
    for i = 1:m
        prop_name = varargin{2*i-1};
        if (isa(prop_name,'char') & size(prop_name,1)==1)
            switch prop_name
                case 'emode'
                    emode_str = ['varargin{' num2str(2*i) '}'];
                case 'delta'
                    delta_str = ['varargin{' num2str(2*i) '}'];
                case 'x1'
                    x1_str = ['varargin{' num2str(2*i) '}'];
                case 'x2'
                    x2_str = ['varargin{' num2str(2*i) '}'];
                case 'twotheta'
                    twotheta_str = ['varargin{' num2str(2*i) '}'];
                case 'azimuth'
                    azimuth_str = ['varargin{' num2str(2*i) '}'];
                case 'efix'
                    efix_str = ['varargin{' num2str(2*i) '}'];
                case 'units'
                    if (isa(varargin{2*i},'char') & size(varargin{2*i},1)==1)
                        units = varargin{2*i};
                    else
                        error ('units must be character')
                    end
                otherwise
                    error ([prop_name ' is not a valid property of a time-of-flight spectrum'])
            end
        else
            error ('property name is not a character string')
        end
    end
    % construct string to evaluate
    command_string = ['tofpar(' emode_str ',' delta_str ',' x1_str ',' x2_str ',' twotheta_str ',' azimuth_str ',' efix_str ')'];
    par = eval(command_string);
else
    error ('Check input arguments')
end

%w = tofspectrum (w.spectrum, par, w.units);
w.tofpar = par;