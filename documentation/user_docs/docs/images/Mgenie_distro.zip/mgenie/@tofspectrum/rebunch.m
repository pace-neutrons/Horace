function [wout] = rebunch(w, v1)
% TOFSPECTRUM/REBUNCH - rebunch data points into groups of nbin points.
%
% Syntax:
%
%   >> w_out = rebunch(w_in, nbin)   rebunches the data of W_IN in groups of nbin
%
%   >> w_out = rebunch(w_in)         same as NBIN=1 i.e. W_OUT is just a copy of W_IN
%

% The help section above should be identical to that for spectrum/rebunch

if (~isa(w,'tofspectrum'))
    error ('Check first argument is a tofspectrum')
end

if (nargin==1)
    wout = w;
    return
end

if (nargin == 2)
    nw = length(w);
    wout(1) = tofspectrum;
    wout = repmat(wout,1,nw);
    for i=1:nw
        spectrum = rebunch (w(i).spectrum, v1);
        par = w(i).tofpar;
        wtemp.units = w(i).units;
        wout(i) = class(wtemp, 'tofspectrum', spectrum, par);
    end
else
    error ('Check number of arguments')
end
