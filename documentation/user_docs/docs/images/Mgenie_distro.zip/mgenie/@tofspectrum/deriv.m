function wout = deriv(w)
% TOFSPECTRUM/DERIV  Numerical first derivative of a tofspectrum

nw = length(w);
wout(1) = tofspectrum;
wout = repmat(wout,1,nw);
for i=1:nw
    spectrum = deriv (w(i).spectrum);
    par = w(i).tofpar;
    wtemp.units = w(i).units;
    wout(i) = class(wtemp, 'tofspectrum', spectrum, par);
end
        