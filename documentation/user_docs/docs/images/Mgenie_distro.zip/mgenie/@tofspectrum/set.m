function w = set (w, sp, par, units)
% TOFSPECTRUM/SET Set a tofspectrum with a different spectrum,
% time-of-flight parameters and units.
%
%  e.g.  w_a1 = set (w_a1, spec, par, u)
%

if (isa(sp,'spectrum') & size(sp,1)==1) & (isa(par,'tofpar') & size(par,1)==1) & ischar(units)
    w.spectrum = sp;
    w.tofpar = par;
    w.units = units;
else
    error ('Must have a spectrum, tofpar and units as input')
end
