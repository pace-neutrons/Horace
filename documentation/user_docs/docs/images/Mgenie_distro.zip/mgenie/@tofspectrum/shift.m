function [wout] = shift(w, xval)
% TOFSPECTRUM/SHIFT - Moves a tofspectrum along the x-axis
%
% Format:   w_out = shift(w_in, delta)
%
% If DELTA is positive, then the spectrum starts and ends at more positive
% values of x.
%

if (~isa(w,'tofspectrum'))
    error ('Check first argument is a tofspectrum')
end

if (nargin==1)
    wout = w;
    return
end

if (nargin == 2)
    nw = length(w);
    wout(1) = tofspectrum;
    wout = repmat(wout,1,nw);
    for i=1:length(w)
        spectrum = shift (w(i).spectrum, xval);
        par = w(i).tofpar;
        wtemp.units = w(i).units;
        wout(i) = class(wtemp, 'tofspectrum', spectrum, par);
    end
else
    error ('Check number of arguments')
end
