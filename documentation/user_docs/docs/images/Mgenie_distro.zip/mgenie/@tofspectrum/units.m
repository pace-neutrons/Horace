function wout = units(win, units_out)
% TOFSPECTRUM/UNITS  Changes units of a workspace
%
% Syntax:
%       >> wout = units(win, units_out)
%
% e.g.  >> w1   = units (w1, 'thz')
%       >> wout = units (w1, 'd')
%
% Valid units (depending on the energy mode) are:
%     t       time-of-flight
%     d       d-spacing
%     v       neutron velocity
%     tau     inverse neutron velocity
%     lam     wavelength
%     k       wavevector
%     e       neutron energy
%     d       d-spacing
%     w       energy transfer (meV)
%     wn      energy transfer (cm^-1)
%     thz     energy transfer (THz)
%     q       momentum transfer
%     sq      square of momentum transfer
%

if (~isa(win,'tofspectrum'))
    error ('Check first argument is a tofspectrum')
end

if (nargin==1)
    wout = win;
    return
end

if (nargin == 2)
    if (~isa(win,'tofspectrum'))
        error ('Check first argument is a tofspectrum')
    end
    nw = length(win);
    wout(1) = tofspectrum;
    wout = repmat(wout,1,nw);
    for i=1:length(win)
        spec = get(win(i).spectrum);
        par = get(win(i).tofpar);
        [wtemp.x, wtemp.y, wtemp.e] = spectrum_units (spec.x, spec.y, spec.e, win(i).units, ...
                  par.emode, par.delta, par.x1, par.x2, par.twotheta*pi/180, par.efix, units_out);
        [wtemp.xlab, wtemp.xunit] = units_to_caption (units_out, par.emode);
        spec = spectrum (wtemp.x, wtemp.y, wtemp.e, spec.title, wtemp.xlab, spec.ylab, wtemp.xunit, spec.distribution);
        wout(i) = tofspectrum (spec,win(i).tofpar,units_out);
    end
else
    error ('Check number of arguments')
end
