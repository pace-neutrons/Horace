function wout = uplus(w1)
% TOFSPECTRUM/UPLUS  Implement +w for time-of-flight spectra

wout = w1;
