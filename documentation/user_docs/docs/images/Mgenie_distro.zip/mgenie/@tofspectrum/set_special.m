function w = set_special (w, y, e, delta, x2, twotheta, azimuth)
% Special function for changing components of a tofspectrum needed by data reading routine(s)

w.spectrum = set_simple (w.spectrum, 'y', y, 'e', e);
w.tofpar = set_simple (w.tofpar, 'delta', delta, 'x2', x2, 'twotheta', twotheta, 'azimuth', azimuth);