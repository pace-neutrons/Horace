function val = get(w, prop_name)
% TOFSPECTRUM/GET  Get a field from a time-of-flight spectrum
%
% Syntax:
%   >> val = get (w)              Gets a structure containing all fields of par
%
% or, for example:
%   >> val = get (w, 'spectrum')     Gets spectrum object
%   >> val = get (w, 'tofpar')       Gets time-of-flight parameter object
%   >> val = get (w, 'units')        Gets units
%

% if a single input argument, return whole structure:
if nargin==1
    % get spectrum fields
    val = get(w.spectrum);
    % append tofpar fields
    tofpar_struct = get(w.tofpar);
    tofpar_names = fieldnames(tofpar_struct);
    for i=1:length(tofpar_names)
        val.(tofpar_names{i}) = tofpar_struct.(tofpar_names{i});
    end
    % append units
    val.units = w.units;
    return
end

% if property name given as well, extract value of just that property:

if (isa(prop_name,'char') & size(prop_name,1)==1)
    switch prop_name
        case 'spectrum'
            val = w.spectrum;
        case 'tofpar'
            val = w.tofpar;
        case 'units'
            val = w.units;
        otherwise
            disp('Valid fields for a tofspectrum object are:')
            disp('spectrum, tofpar, units')
            error([prop_name,' is not a valid tofspectrum property'])
    end
else
    error ('property name is not a character string')
end
