function wout = single_mtimes(w1,w2)
% TOFSPECTRUM/MTIMES  Implement w1 * w2 for time-of-flight spectra
%
%   >> w = w1 * w2
%
%   If w1, w2 are both time-of-flight spectra, or one is an mgenie spectrum:
%       the operation is performed element-by-element
%   if one of w1 or w2 is a double:
%       the operation is applied to each element of the spectrum

% units checking needs to be more careful
if (isa(w1,'tofspectrum') & isa(w2,'tofspectrum'))
    spectrum = w1.spectrum * w2.spectrum;
    if (w1.tofpar==w2.tofpar)
        par = w1.tofpar;
    else
        par = tofpar;
    end
    if (strcmp(w1.units,w2.units))
        wout.units = w1.units;
    else
        wout.units = '';
    end
    
elseif (isa(w1,'tofspectrum') & (isa(w2,'spectrum')|isa(w2,'double')))
    spectrum = w1.spectrum * w2;
    par = w1.tofpar;
    wout.units = w1.units;
    
elseif ((isa(w1,'spectrum')|isa(w1,'double')) & isa(w2,'tofspectrum'))
    spectrum = w1 * w2.spectrum;
    par = w2.tofpar;
    wout.units = w2.units;
    
else
    error ('only multiplication of tofspectra and spectra or reals defined')
end

wout = class(wout,'tofspectrum',spectrum,par);
        