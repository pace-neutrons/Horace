function wout = uminus(w1)
% TOFSPECTRUM/UMINUS  Implement -w for time-of-flight spectra

nw = length(w1);

if nw==1
    wout.units = w1.units;
    wout = class(wout,'tofspectrum',-w1.spectrum,w1.tofpar);
else
    wout(1) = tofspectrum;
    wout = repmat(wout,1,nw);
    for i=1:length(w1)
        wtemp.units = w1(i).units;
        wout(i) = class(wtemp, 'tofspectrum', -w1(i).spectrum, w1(i).tofpar);
    end
end