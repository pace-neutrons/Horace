function specno = dget_spec(w,val)
%
% Given the output of DSPACE_MAPS, DSPACE_MARI etc. and a value of the scan parameter,
% returns the spectrum number with corresponding value of the scan parameter
% which lies closest to the input value
%
% Syntax:
%   >> specno = dget_spec (w_array, value)

% get array of spectrum numbers:

spec_arr = zeros(1,length(w));
val_arr  = zeros(1,length(w));
for i=1:length(w)
    temp = get(get(w(i),'spectrum'));
    if isempty(temp.title)
        str='';
    elseif isa(temp.title,'cell')
        lt = length(temp.title);
        str = char(temp.title{lt});
    elseif isa(temp.title,'char')
        str = temp.title;
    else
        error ('Something screwy with titles')
    end
    str = strrep(str,'Spectrum','');
    if isempty(str)
        error ('Check origin of spectrum array - no scan variable information available')
    else
        spec_arr(i)=sscanf(str,'%g');
    end
    val_arr(i) = get(get(w(i),'tofpar'),'efix');
end
[temp, i] = min(abs(val_arr-val));
specno = spec_arr(i);
disp (['Closest spectrum number : ',num2str(specno),';  scan value = ',num2str(val_arr(i))])
