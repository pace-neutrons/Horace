function w = set_units (w, units)
% TOFSPECTRUM/SET_UNITS  Set a tofspectrum with units
%
% Input and output arguments must be the same. Type >> help ofspectrum/units for valid units
%
%  e.g.  w_a1 = set_units (w_a1, 'lam')

% check if input following a tofspectrum is up to 6 numbers

if (isa(units,'char') & size(units,1)==1)
    w.units = units;
else
    error ('units must be a character array')
end
