function w = set_spectrum (w, sp)
% TOFSPECTRUM/SET_SPECTRUM  Set a tofspectrum with a differnet spectrum
%
%  e.g.  w_a1 = set_spectrum (w_a1, spec)
%
% where spec is an object of type spectrum

% check if input following a tofspectrum is up to 6 numbers

if (isa(sp,'spectrum') & size(sp,1)==1)
    w.spectrum = sp;
else
    error ('Must have a spectrum as input')
end
