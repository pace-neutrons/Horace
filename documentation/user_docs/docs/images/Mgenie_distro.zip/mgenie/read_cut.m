function w = read_cut (file)
% READ_CUT Reads the x,y,e arrays of x coordinate, corresponding y values, errors on y from
%          a file with the format of and Mslice .cut file.
%
% Syntax:
%   >> w = read_cut (file)    % read from named file
%   >> w = read_cut           % prompts for file
%

% Get file name - prompt if file does not exist (using file to set default seach location and extension
% -----------------------------------------------------------------------------------------------------
if (nargin==1)
    if (exist(file,'file')==2)
        file_internal = file;
    else
        file_internal = genie_getfile(file);
    end
else
    file_internal = genie_getfile('*.cut');
end
if (isempty(file_internal))
    error ('No file given')
end

% Read cut
% --------------------
cut = get_cut(file_internal);
w = cut_to_spectrum(cut);

