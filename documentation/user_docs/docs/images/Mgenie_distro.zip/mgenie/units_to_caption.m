function [varargout] = units_to_caption (varargin)
% For converting xlab and xunit to/from  time-of-flight unit code and emode
% Creates x-axis label and units for a spectrum object given the time-of-flight spectrum unit and energy mode

persistent u

if (isempty(u))
    % enforce to become a structure:
    u.unit='';, u.emode=0;, u.xlab='';,u.xunit='';
    % now fill up:
    u(1) =struct('unit', 't',    'emode', 0, 'xlab', 'Time-of-flight', 'xunit', '{\mu}s');
    u(2) =struct('unit', 't',    'emode', 1, 'xlab', 'Time-of-flight', 'xunit', '{\mu}s');
    u(3) =struct('unit', 't',    'emode', 2, 'xlab', 'Time-of-flight', 'xunit', '{\mu}s');

    u(4) =struct('unit', 'v',    'emode', 0, 'xlab', 'Velocity',          'xunit', 'm/s');
    u(5) =struct('unit', 'v',    'emode', 1, 'xlab', 'Final velocity',    'xunit', 'm/s');
    u(6) =struct('unit', 'v',    'emode', 2, 'xlab', 'Incident velocity', 'xunit', 'm/s');
    u(7) =struct('unit', 'v1',   'emode', 1, 'xlab', 'Final velocity',    'xunit', 'm/s');
    u(8) =struct('unit', 'v2',   'emode', 2, 'xlab', 'Incident velocity', 'xunit', 'm/s');
    
    u(9) =struct('unit', 'tau',  'emode', 0, 'xlab', 'Reciprocal velocity',          'xunit', 's/m');
    u(10)=struct('unit', 'tau',  'emode', 1, 'xlab', 'Final reciprocal velocity',    'xunit', 's/m');
    u(11)=struct('unit', 'tau',  'emode', 2, 'xlab', 'Incident reciprocal velocity', 'xunit', 's/m');
    u(12)=struct('unit', 'tau1', 'emode', 1, 'xlab', 'Final reciprocal velocity',    'xunit', 's/m');
    u(13)=struct('unit', 'tau2', 'emode', 2, 'xlab', 'Incident reciprocal velocity', 'xunit', 's/m');
    
    u(14)=struct('unit', 'lam',  'emode', 0, 'xlab', 'Wavelength',          'xunit', '�');
    u(15)=struct('unit', 'lam',  'emode', 1, 'xlab', 'Final wavelength',    'xunit', '�');
    u(16)=struct('unit', 'lam',  'emode', 2, 'xlab', 'Incident wavelength', 'xunit', '�');
    u(17)=struct('unit', 'lam1', 'emode', 1, 'xlab', 'Final wavelength',    'xunit', '�');
    u(18)=struct('unit', 'lam2', 'emode', 2, 'xlab', 'Incident wavelength', 'xunit', '�');
    
    u(19)=struct('unit', 'k',    'emode', 0, 'xlab', 'Wavelength',          'xunit', '�^{-1}');
    u(20)=struct('unit', 'k',    'emode', 1, 'xlab', 'Final wavelength',    'xunit', '�^{-1}');
    u(21)=struct('unit', 'k',    'emode', 2, 'xlab', 'Incident wavelength', 'xunit', '�^{-1}');
    u(22)=struct('unit', 'k1',   'emode', 1, 'xlab', 'Final wavelength',    'xunit', '�^{-1}');
    u(23)=struct('unit', 'k2',   'emode', 2, 'xlab', 'Incident wavelength', 'xunit', '�^{-1}');
    
    u(24)=struct('unit', 'e',    'emode', 0, 'xlab', 'Energy',          'xunit', 'meV');
    u(25)=struct('unit', 'e',    'emode', 1, 'xlab', 'Final energy',    'xunit', 'meV');
    u(26)=struct('unit', 'e',    'emode', 2, 'xlab', 'Incident energy', 'xunit', 'meV');
    u(27)=struct('unit', 'e1',   'emode', 1, 'xlab', 'Final energy',    'xunit', 'meV');
    u(28)=struct('unit', 'e2',   'emode', 2, 'xlab', 'Incident energy', 'xunit', 'meV');
    
    u(29)=struct('unit', 'w',    'emode', 1, 'xlab', 'Energy transfer',          'xunit', 'meV');
    u(30)=struct('unit', 'w',    'emode', 2, 'xlab', 'Energy transfer',          'xunit', 'meV');
    u(31)=struct('unit', 'wn',   'emode', 1, 'xlab', 'Energy transfer',          'xunit', 'cm^{-1}');
    u(32)=struct('unit', 'wn',   'emode', 2, 'xlab', 'Energy transfer',          'xunit', 'cm^{-1}');
    u(33)=struct('unit', 'thz',  'emode', 1, 'xlab', 'Energy transfer',          'xunit', 'THz');
    u(34)=struct('unit', 'thz',  'emode', 2, 'xlab', 'Energy transfer',          'xunit', 'THz');
    
    u(35)=struct('unit', 'q',  'emode', 0, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(36)=struct('unit', 'q',  'emode', 1, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(37)=struct('unit', 'q',  'emode', 2, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(38)=struct('unit', 'q-', 'emode', 1, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(39)=struct('unit', 'q+', 'emode', 2, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(40)=struct('unit', 'q-', 'emode', 1, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    u(41)=struct('unit', 'q+', 'emode', 2, 'xlab', 'Momentum transfer', 'xunit', '�^{-1}');
    
    u(42)=struct('unit', 'sq',  'emode', 0, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(43)=struct('unit', 'sq',  'emode', 1, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(44)=struct('unit', 'sq',  'emode', 2, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(45)=struct('unit', 'sq-', 'emode', 1, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(46)=struct('unit', 'sq-', 'emode', 2, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(47)=struct('unit', 'sq+', 'emode', 1, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');
    u(48)=struct('unit', 'sq+', 'emode', 2, 'xlab', 'Momentum transfer squared', 'xunit', '�^{-2}');

    u(49)=struct('unit', 'd', 'emode', 0, 'xlab', 'D-spacing', 'xunit', '�');
end

if (nargout==2) % [xlab,xunit]=units_to_caption(unit,emode)
    for i=1:length(u)
        if (strcmp(varargin{1},u(i).unit) & varargin{2}==u(i).emode)
            varargout{1} = u(i).xlab;
            varargout{2}= u(i).xunit;
            return
        end
    end
    error ('Unrecognised time-of-flight unit')
else            % [unit]=units_to_caption(xlab,xunit)
    for i=1:length(u)
        if (strcmp(varargin{1},u(i).xlab) & strcmp(varargin{2},u(i).xunit))
            varargout{1} = u(i).unit;
            return
        end
    end
    error ('Unrecognised time-of-flight unit')
end

