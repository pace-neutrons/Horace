function [path, mess] = get_globalpath (name)
% GET_GLOBALPATH    Return the named global user path as a (local) userpath object
%
% Syntax:
%   >> path = get_globalpath (name)   % name is a character string containing
%                                     % the name of the global user path

% Determine failure mode and default return algorithm
if nargout==2; fail_on_error=0; else; fail_on_error=1; end
p_default=userpath({});
mess='';

% check name of global user path
if nargin < 1
    mess = 'ERROR: Must give name of global user path that is to be displayed';
    path = p_default;
    if fail_on_error; error(mess); else; return; end
end

if nargin >= 1
    if ischar(name) & length(name)>0 & size(name,1)==1
        if isvarname(name)
            path = get_global(name);
            if isa(path,'userpath')
                return
            else
                path = p_default;
                mess = ['ERROR: Global user path ''',name,''' does not exist.'];
                if fail_on_error; error(mess); else; return; end
            end
        else
            path = p_default;
            mess = ['ERROR: Invalid name for a global user path: ''',name,''''];
            if fail_on_error; error(mess); else; return; end
        end
    else
        path = p_default;
        mess = 'ERROR: Invalid argument type for a global user path name';
        if fail_on_error; error(mess); else; return; end
    end
end
