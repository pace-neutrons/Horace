function ff=magff(qsqr,ion)
% Get isotropic magnetic form factor for given q and ion
%
% Syntax:
%   >> ff = magff(q,ion)    % calculate for given ion
%   >> ff = magff(q)        % calculate for the most recently set ion
%
%   qsqr    Array containing square of momentum (Angstrom^-1) at which to
%          calculate magnetic form factor
%   ion     Atomic number and valence e.g. 25.3 for atomic number=25, valence=+3
%
%   ff      Magnetic form factor; same size as q. Needs to be squared to compare 
%          with neutron scattering cross-section data.

persistent ion_saved j0_pars_saved

if nargin==2
    j0_pars=magff_pars(ion);
    if ~isempty(j0_pars)
        ion_saved = ion;
        j0_pars_saved = j0_pars;
    end
end
    
if ~isempty(j0_pars_saved)
    ff=(j0_pars_saved(1).*exp(-(j0_pars_saved(2)/((4*pi)^2))*qsqr) + ...
        j0_pars_saved(3).*exp(-(j0_pars_saved(4)/((4*pi)^2))*qsqr) + ...
        j0_pars_saved(5).*exp(-(j0_pars_saved(6)/((4*pi)^2))*qsqr) + j0_pars_saved(7));
else
    error('Invalid or non-existent ion')
end
    