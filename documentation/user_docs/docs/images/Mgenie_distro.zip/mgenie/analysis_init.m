function [] = analysis_init (mon_norm, mon_tlo, mon_thi, mon_norm_constant)
% ANALYSIS_INIT 
%  Set up default parameters for analysis utilities
%
% Syntax:
%   To view current settings:
%       >> analysis_init        
%   To change settings:
%       >> analysis_init (mon_norm, mon_tlo, mon_thi, mon_norm_constant)
%
%           mon_norm                    % Default monitor for normalisation
%           mon_tlo                     % Lower time integration limit
%           mon_thi                     % Upper time integration limit
%           mon_norm_constant           % Normalisation constant.

% Dont forget to propagate any changes to the global variable list to analysis_off so that
% a clean 'uninstall' can be made

global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant

if (nargin == 4)
    if (isa(mon_norm,'double') & isa(mon_tlo,'double') & isa(mon_thi,'double') & isa(mon_norm_constant,'double'))
        analysis_mon_norm   = mon_norm;
        analysis_mon_tlo    = mon_tlo;
        analysis_mon_thi    = mon_thi;
        analysis_mon_norm_constant = mon_norm_constant;
    else
        error ('Check types of parameters')
    end
elseif (nargin~=0)
    error ('Check number of parameters')
end

disp(['                Monitor for normalisation : ',num2str(analysis_mon_norm)])
disp(['             Lower time integration limit : ',num2str(analysis_mon_tlo)])
disp(['             Upper time integration limit : ',num2str(analysis_mon_thi)])
disp(['Normalise by monitor integral in units of : ',num2str(analysis_mon_norm_constant)])
disp(' ')
