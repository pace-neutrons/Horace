function [] = set_efix (varargin)
% Set energy for the run:
%     efix  - incident or final energy (meV)
%     emode - 0,1,2 for elastic, direct geometry, indirect geometry
%
% Syntax:
%   >> set_efix (efix)      efix = +ve for direct geometry (sets emode=1)
%                           efix = -ve for indirect geometry (sets emode=2)
%                           efix = 0   for elastic (sets emode=0)
% or:
%   >> set_efix (efix, emode)    explicitly set both
%                               (efix > 0 if inelastic; set to zero if elastic)
%
% To view current values, use with no arguments:
%   >> set_efix
%
%

global genie_handle
global genie_efix genie_x1 genie_emode
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% check arguments and set parameters:
small = 1.0e-10;
if (nargin==1)
    if isa(varargin{1},'double')
        efix = varargin{1};
        if (efix == 0)
            genie_efix = 0;
            genie_emode = 0;
        elseif (efix > small)
            genie_efix = efix;
            genie_emode = 1;
        elseif (efix < -small)
            genie_efix = -efix;
            genie_emode = 2;
        else
            error ('Check value of EFIX')
        end
    else
        error('Check parameter type(s)')
    end
elseif (nargin==2)
    if isa(varargin{1},'double') & isa(varargin{2},'double')
        efix = varargin{1};
        emode = varargin{2};
        if ~(emode == 0 | emode == 1| emode == 2)
            error ('EMODE must be 0,1,2')
        end
        if (efix < small & emode > 0)  % inelastic and fixed energy close to zero
            error ('Fixed energy must be positive if inelastic (i.e. EMODE > 0)')
        end
        if (emode~=0)
            genie_efix = efix;
        else
            genie_efix = 0; % explicily set to zero for clarity wehen debugging.
        end
        genie_emode = emode;
    end
elseif (nargin > 2)
    error ('Check number of arguments')
end

% Print values to screen
disp(['                       Fixed energy (meV) : ',num2str(genie_efix,5)])
disp(['            Moderator-sample distance (m) : ',num2str(genie_x1,5)])
disp(['                              Energy mode : ',num2str(genie_emode)])
disp(' ')