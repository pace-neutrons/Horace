function [path, file] = pathstrip (file_in)
% PATHSTRIP: Find out if a file name starts with a userpath or environment
%            variable.
% Syntax:
%   >> [path, file] = pathstrip ('data_path:map07284.raw')
%       path = 'data_path'
%       file = 'map07284.raw'
%
% * If not of the form ppp:fff, then returns path = '', file = file_in
% * No checks are performed on whether or not the path or file name are valid.


% Find out if file_in has form nnn:mmm. The requirement is that the last ':'
% is not followed by FILESEP, '/' or '\', and that the string upto the
% last ':' is a valid variable name.

path = '';
file = file_in;
pos = strfind(file_in,':');
if ~isempty(pos)
    if pos(end)>1 & pos(end)<length(file_in)
        i = pos(end);
        if ~(file_in(i+1:i+1)==filesep & file_in(i+1:i+1)=='/' & file_in(i+1:i+1)=='\') & isvarname(file_in(1:i-1))
            path = file_in(1:i-1);
            file = file_in(i+1:end);
        end
    end
end
