function wout=slice_to_spectrum(slice)
% Convert a slice data structure into an array of mgenie spectra
%
%   >> wout=slice_to_spectrum(slice)
%
%   slice   Slice data structure as read in by get_slice
%
%   wout    Array of Mgenie spectra. Will be histogram spectra

nx = length(slice.xbounds) - 1;
ny = length(slice.ybounds) - 1;
yorig=0.5*(slice.ybounds(2)+slice.ybounds(1));
ylo  = slice.ybounds(1);
yhi  = slice.ybounds(end);
step = slice.ybounds(2)-slice.ybounds(1);

% set titles:
temp = cellstr(slice.title);   % add file name to top of the title
ltemp = length(temp);
ltitle = ltemp + 1;
title{1} = avoidtex(fullfile(slice.SliceDir,slice.SliceFile));
title(2:ltitle) = temp(1:ltemp);
title{ltitle+1} = ['mgenie_control_y_label = ',slice.y_label];
title{ltitle+2} = ['mgenie_control_x_unitlength = ',slice.x_unitlength];
title{ltitle+3} = ['mgenie_control_y_unitlength = ',slice.y_unitlength];
title{ltitle+4} = ['mgenie_control_y_start = ',num2str(yorig)];
title{ltitle+5} = ['mgenie_control_y_step = ',num2str(step)];

% fill spectra:
if (ny==1)    % just one y-strip in the slice file
    temp = [slice.z_label,' [',num2str(ylo),' to ',num2str(yhi),']'];
    wout = spectrum(slice.xbounds,slice.c,slice.e,title,slice.x_label,temp);
else
    wout = spectrum(slice.xbounds,slice.c(1:nx),slice.e(1:nx),title,slice.x_label,slice.z_label);
    wout = repmat(wout,1,ny);
    for i=1:ny
        ib = 1 + (i-1)*nx;
        ie = i*nx;
        temp = [slice.z_label,' [',num2str(slice.ybounds(i)),' to ',num2str(slice.ybounds(i+1)),']'];
        wout(i) = set_simple (wout(i), 'y', slice.c(ib:ie), 'e', slice.e(ib:ie), 'ylab', temp);
    end
end

