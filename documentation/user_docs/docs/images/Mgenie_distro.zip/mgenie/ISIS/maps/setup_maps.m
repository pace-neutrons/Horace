% Set up default parameters for MAPS
set_primary(12.0);
analysis_init(1,1000,2000,1.0e6);