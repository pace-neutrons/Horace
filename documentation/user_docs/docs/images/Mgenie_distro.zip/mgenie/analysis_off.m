function analysis_off
%ANALYSIS_OFF
%  Clears global parameters created in analysis_init
%  Ensure that the variables in the two functions are synchronised

try
    clear global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant
catch
    error('Error cleaning up the mgenie install')
end
