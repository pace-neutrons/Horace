function wout = tomgenie(d)
% Function to copy a dataset_2d with only one y value into an MGENIE
% spectrum
ny = get(d,'ny');
if ny==1
    wout = spectrum(d.x',d.signal,d.error,d.title,d.x_label,d.y_label,d.x_units,real(d.x_distribution));
end