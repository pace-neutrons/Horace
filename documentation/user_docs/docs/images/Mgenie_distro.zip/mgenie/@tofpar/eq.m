function ans = eq (par1, par2)
% TOFPAR/EQ     Check for equality of two time-of-flight parameter objects

% independent of the number of fields, but they must all have '==' defined (so excludes e.g. char, cell)
ans = 0;
if (isa(par1,'tofpar') & isa(par2,'tofpar'))
    names = fieldnames(par1);
    for i=1:length(names)
        if (par1.(names{i})~=par2.(names{i}))
            return
        end
    end
    ans = 1;
end