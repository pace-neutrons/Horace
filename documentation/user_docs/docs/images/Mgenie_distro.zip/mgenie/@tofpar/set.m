function w = set(par, varargin)
% TOFPAR/SET  Set fields in a time-of-flight object
%
% Syntax:
%   The name of the output time-of-flight parameter object must the same as the input name.
%   Valid fields are: emode, delta, x1, x2, twotheta, azimuth, efix
%   (For further description of the fields type >> help tofpar)
%
% e.g.
%   >> par = set (par, 'efix', 65)
%   >> angle = 29.63
%   >> delay = 6.3
%   >> par = set (par, 'twotheta', angle, 'delta', delay)
%

% A general set command could be written for this and any other object, if the fieldnames
% were extracted using fieldnames

m = floor(length(varargin)/2);
if (length(varargin)-2*m == 1)  % must have even number of arguments
    error ('Check number of arguments to set')
end

% Create a string to be evaluated using eval. The checking  of argumnet types will be done
% by the call to tofpar that will be performed in this evaluation.
emode_str    = 'par.emode';
delta_str    = 'par.delta';
x1_str       = 'par.x1';
x2_str       = 'par.x2';
twotheta_str = 'par.twotheta';
azimuth_str  = 'par.azimuth';
efix_str     = 'par.efix';

for i = 1:m
    prop_name = varargin{2*i-1};
    if (isa(prop_name,'char') & size(prop_name,1)==1)
        switch prop_name
            case 'emode'
                emode_str    = ['varargin{' num2str(2*i) '}'];
            case 'delta'
                delta_str    = ['varargin{' num2str(2*i) '}'];
            case 'x1'
                x1_str       = ['varargin{' num2str(2*i) '}'];
            case 'x2'
                x2_str       = ['varargin{' num2str(2*i) '}'];
            case 'twotheta'
                twotheta_str = ['varargin{' num2str(2*i) '}'];
            case 'azimuth'
                azimuth_str  = ['varargin{' num2str(2*i) '}'];
            case 'efix'
                efix_str     = ['varargin{' num2str(2*i) '}'];
            otherwise
                error ([prop_name ' is not a valid property of a spectrum'])
        end
    else
        error ('property name is not a character string')
    end
end

% construct string to evaluate
command_string = ['tofpar(' emode_str ',' delta_str ',' x1_str ',' x2_str ',' twotheta_str ',' azimuth_str ',' efix_str ')'];
w = eval(command_string);