function display (par)
% TOFPAR/DISPLAY Command window display of a time-of-flight parameter file
%
% Syntax:
%   >> display (par)
%

% Get name of input object
if (strcmp(inputname(1),''))
    string = 'tofpar';
else
    string = inputname(1);
end

% If array of spectra
if (max(size(par))>1)
    if (length(size(par))<=2)
        disp(['           ',string,' = [',num2str(size(par,1)),'x',num2str(size(par,2)),' tofpar]'])
    else
        disp(['           ',string,' = [',num2str(length(size(par))),'-dimensional array of class tofpar]'])
    end
    disp(' ')
    return
end

disp(['   ',string,'.emode = ',num2str(par.emode)])
disp(['   ',string,'.delta = ',num2str(par.delta)])
disp(['      ',string,'.x1 = ',num2str(par.x1)])
disp(['      ',string,'.x2 = ',num2str(par.x2)])
disp([   string,'.twotheta = ',num2str(par.twotheta)])
disp([' ',string,'.azimuth = ',num2str(par.azimuth)])
disp(['    ',string,'.efix = ',num2str(par.efix)])
disp(' ')
