function [ok,mess] = write_ascii (w, file)
% WRITE_ASCII writes time-of-flight parameters to an ascii file. 
%
% Syntax (basic useage):
%   >> write_ascii (w)           % prompts for file to write to
%   >> write_ascii (w, file)     % write to named file
%
% The output file format is, for example:
%
%   emode = 1
%   delta = 0.5
%   x1 = 12.0
%   x2 = 6.0
%   twotheta = 3.26
%   azimuth = 0.0
%   efix = 45
%
%  - If w is an array of tofpar, tben the spectra will be written out in series
%  - Can be read back into mgenie with the function READ_ASCII
%
% Advanced useage
% ---------------
%   >> write_ascii (w, fid)         % writes w to currently open text file
%   >> ok = write_ascii (w, fid)    % returns status (ok=1 all fine; ok=0 otherwise)
%   

ok = 1;
mess = '';

% Check first input is a spectrum
% -------------------------------
if (~isa(w,'tofpar'))
    error ('ERROR: Object must be a tofpar (write_ascii)')
end

% Get file name - prompting if necessary
% --------------------------------------
if (nargin==1)
    file_internal = genie_putfile;
    if (isempty(file_internal))
        ok = 0;
        mess = 'No file given';
    end
elseif (nargin==2)
    file_internal = file;
end

if isa_size(file_internal,'row','char')
    fid_given = 0;
    fid = fopen (file_internal, 'wt');
    if (fid < 0)
        ok = 0;
        mess = ['Cannot open file ' file_internal];
    end
elseif isnumeric(file_internal)
    fid_given = 1;
    fid = file_internal;
    [file, mode] = fopen(fid);
    if isempty(file)||~strcmp(lower(mode),'wt')
        ok = 0;
        mess = 'Check file is open and its mode is "wt"';
    end
else
    ok = 0;
    mess = 'File ID passed to write_ascii is non-numeric';
end
if ~ok; if nargout==0; error(mess); else; return; end; end;


% write data to file
% ------------------
for i=1:length(w)
    [ok,mess] = write_ascii(w(i).emode,fid,'emode'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).delta,fid,'delta'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).x1,fid,'x1'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).x2,fid,'x2'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).twotheta,fid,'twotheta'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).azimuth,fid,'azimuth'); if ~ok; if nargout==0; error(mess); else; return; end; end;
    [ok,mess] = write_ascii(w(i).efix,fid,'efix'); if ~ok; if nargout==0; error(mess); else; return; end; end;
end

% Close file if function was given a file name, not fid:
if ~fid_given
    fclose(fid);
end

% ensure that if no arguments, do not get any output (otherwise from command line
% a succesful >> write_acsii(w) would print "ans = 1")
if nargout==0
    clear ok mess
end
