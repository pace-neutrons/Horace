function w = set_simple(w, varargin)
% TOFPAR/SET_SIMPLE  Set fields in a tofpar.
%
%   *** DOES NOT CHECK TYPE OR FOR CONSISTENCY OF INPUT
%       FOR USE INSIDE CAREFULLY CHECKED RUNCTIONS ONLY ***
%
% Syntax:
%   The output spectrum name must the same as the input spectrum name.
%   Valid fields are:  emode, delta, x1, 2, twotheta, azimuth, efix
%   (For further description of the fields type >> help tofpar)
% e.g.
%   >> ei = 160.3
%   >> w = set (w, 'emode', 1, 'efix', ei)

m = floor(length(varargin)/2);
if (length(varargin)-2*m == 1)  % must have even number of argumnents
    error ('Check number of arguments to set')
end

for i = 1:m
    prop_name = varargin{2*i-1};
    switch prop_name
        case 'emode'
            w.emode = varargin{2*i};
        case 'delta'
            w.delta = varargin{2*i};
        case 'x1'
            w.x1 = varargin{2*i};
        case 'x2'
            w.x2 = varargin{2*i};
        case 'twotheta'
            w.twotheta = varargin{2*i};
        case 'azimuth'
            w.azimuth = varargin{2*i};
        case 'efix'
            w.efix = varargin{2*i};
        otherwise
            error ([prop_name ' is not a valid property of a tofpar'])
        end
end