function val = get(par,prop_name)
% TOFPAR/GET  Get a field from a time-of-flight parameter object
%
% Syntax:
%   >> val = get (par)              Gets a structure containing all fields of par
%
% or, for example:
%   >> val = get (par, 'emode')     Gets energy mode
%   >> val = get (par, 'efix')      Gets value of fixed energy
%
% Valid fields are:
%    emode  delta  x1  x2  twotheta  azimuth efix
%

% if a single input argument, return whole structure:
if nargin==1
    val.emode=par.emode;
    val.delta=par.delta;
    val.x1=par.x1;
    val.x2=par.x2;
    val.twotheta=par.twotheta;
    val.azimuth=par.azimuth;
    val.efix=par.efix;
    return
end

% if property name given as well, extract value of just that property:

if (isa(prop_name,'char') & size(prop_name,1)==1)
    switch prop_name
        case 'emode'
            val = par.emode;
        case 'delta'
            val = par.delta;
        case 'x1'
            val = par.x1;
        case 'x2'
            val = par.x2;
        case 'twotheta'
            val = par.twotheta;
        case 'azimuth'
            val = par.azimuth;
        case 'efix'
            val = par.efix;
        otherwise
            disp('Valid fields for a tofpar object are')
            disp('emode, delta, x1, x2, twotheta, azimuth, efix')
            error([prop_name,' is not a valid spectrum property'])
    end
else
    error ('property name is not a character string')
end
