function par = tofpar (varargin)
% TOFPAR/TOFPAR  Sets an object with time-of-flight parameters for units conversion
%
% Fields are:
%   emode   = 0,1 or 2 for elastic, direct geometry or indirect geometry
%   delta   = detector delay time (microseconds)
%   x1      = primary flight path (m)
%   x2      = secondary flight path (m)
%   twotheta= scattering angle (deg)
%   azimuth = azimuthal angle (deg)
%   efix    = fixed incident energy (meV)
%
%
% Syntax:
%   >> par = tofpar (emode, delta, ... ,twotheta, azimuth, efix)    % efix can be omitted if emode=0;
%                                                         it will be set to zero in this instance
%
%   >> par = tofpar (parin)    % parin is a structure with fields emode, delta ... twotheta, azimuth, efix
%
%   >> par = tofpar            % will return an object of class tofpar, but with zero values for all fields
%

% Check number of input parameters: pick out special cases

    if (nargin == 0)    % fill an empty object
        parn.emode = 0;
        parn.delta = 0;
        parn.x1 = 0;
        parn.x2 = 0;
        parn.twotheta = 0;
        parn.azimuth = 0;
        parn.efix = 0;
        par = class(parn,'tofpar');
        return
    elseif (nargin == 1)    % must already be a tofpar, or a structure with required number of fields
        if (isa(varargin{1},'tofpar'))
            par = varargin{1};
            return
        elseif (isa(varargin{1},'struct'))  % is recursive.
            if (isfield(varargin{1},'emode') & isfield(varargin{1},'delta') & isfield(varargin{1},'x1') ...
                    & isfield(varargin{1},'x2') & isfield(varargin{1},'twotheta') & isfield(varargin{1},'azimuth') & isfield(varargin{1},'efix'))
                par = tofpar (varargin{1}.emode, varargin{1}.delta, varargin{1}.x1, varargin{1}.x2, ...
                    varargin{1}.twotheta, varargin{1}.azimuth, varargin{1}.efix);
                return
            else
                error ('Check field names')
            end
        else
            error ('Wrong argument type for time-of-flight parameter object')
        end
    elseif (nargin < 6 | nargin > 7)
        error ('Check number of input parameters for time-of-flight parameter object')
    end

% --------- Emode ----------------
    emode = varargin{1};
    if (isa(emode,'double') & size(emode)==[1,1] & (emode >= 0 & emode <= 2))
        par.emode = emode;
    else
        error ('EMODE must equal 0,1 or 2 for elastic, direct geometry or indirect geometry')
    end

% --------- Delta ----------------
    delta = varargin{2};
    if (isa(delta,'double') & size(delta)==[1,1])
        par.delta = delta;
    else
        error ('Check type of variable DELTA')
    end

% --------- X1 ----------------
    x1 = varargin{3};
    if (isa(x1,'double') & size(x1)==[1,1] & x1 > 0)
        par.x1 = x1;
    else
        error ('Primary flight path must be greater than zero')
    end
    
% --------- X2 ----------------
    x2 = varargin{4};
% 24/5/05: Modify the following check to enable NaN to be acceptable (needed for 
% conventional case of mspec_core when av_mode = 'none'
%    if (isa(x2,'double') & size(x2)==[1,1] & ((emode>0 & x2>0)|emode==0))
    if (isa(x2,'double') & size(x2)==[1,1] & ((emode>0 & x2>0)|emode==0|isnan(x2)))
        par.x2 = x2;
    else
        error ('Secondary flight path must be greater than zero')
    end

% --------- Twotheta ----------------
    twotheta = varargin{5};
    if (isa(twotheta,'double') & size(twotheta)==[1,1])
        par.twotheta = twotheta;
    else
        error ('Check type of variable TWOTHETA')
    end

% --------- Azimuth ----------------
    azimuth = varargin{6};
    if (isa(azimuth,'double') & size(azimuth)==[1,1])
        par.azimuth = azimuth;
    else
        error ('Check type of variable AZIMUTH')
    end

% --------- Efix ----------------
    if (nargin==6)
        if (emode==0)
            par.efix = 0;
        else
            error ('Must give fixed energy when EMODE = 1 or 2')
        end
    else
        efix = varargin{7};
        if (emode > 0 & efix <= 0)
            error ('Fixed neutron energy must be greater than zero when EMODE = 1 or 2')
        else
            par.efix = efix;
        end
    end

    par = class (par, 'tofpar');