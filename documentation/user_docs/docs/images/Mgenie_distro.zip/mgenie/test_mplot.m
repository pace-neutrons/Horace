function w = test_mplot (irun, period_in, p1, p2, p3)
% DSPACE_MAPS creates an array of workspaces containing intensity as a 
% function of d-spacing for the horizontal detector array of MAPS.
% Data is normalised by monitor integral.
%
% Assumes that the MID-TUBES spectrum mapping file has been used.
%
% Syntax:
%   >> w = dspace_maps (irun)           % uses period 1 and default dspacing range and step
%
%   >> w = dspace_maps (irun, period)   % uses default dspacing range and step
%
%   >> w = dspace_maps (irun, period, dspace_lo, dspace_hi)
%
%   >> w = dspace_maps (irun, period, dspace_lo, dspace_step, dspace_hi)
%           dspace_step +ve: constant step binning
%           dspace_step -ve: logarithmic binning
%       (type '>> help rebin' for more details of rebinning syntax)
%

% This is a a specialised command file that makes special assumptions about the raw file. Only for MAPS.

global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant

%------------------------------------------------------------------------------------------------------
% default d-spacing binning.
dlo_def = 0.5;  % instrument specific (depends on scattering angle range)
dhi_def = 15;   % instrument specific (depends on scattering angle range)
%------------------------------------------------------------------------------------------------------
if (nargin < 1)
    error ('ERROR: Must give run number')
end
ass (irun);

%Check that emode = 0
[efix,emode]=get_efix;
if emode ~= 0
    error ('ERROR: Must set analysis to elastic mode i.e. EMODE=0 (Type >> help set_efix)')
end

% Check that monitor_1 is in spectrum 577. A reasonable way of checking the spectra.dat is correct
mdet = genie_get('mdet');
spec_list = genie_get('spec');
if double(spec_list(mdet(1))) ~= 577
    error (['Check that a mid-tubes spectrum mapping file was used in run ',num2str(irun)])
end

% Check number of periods
nperiod = double(gget('nper'));
nsp1 = double(gget('nsp1'));
if nargin > 1   % period number given
    if (round(period_in) < 0 | round(period_in) > nperiod)
        error (['Period number must lie in the range 1-',num2str(nperiod)])
    else
        if period_in==0
            period = period_in + 1;
        else
            period = period_in;
        end
    end
else
    period = 1;
end

% Get normalisation constant
area = integrate(unspike(mon(analysis_mon_norm,period,'none')),analysis_mon_tlo,analysis_mon_thi);
norm = area.val/analysis_mon_norm_constant;

% Read in data and store spectrum numbers:
specno = [linspace(64,1,64),linspace(65,128,64),linspace(441,576,136)];
w = mspec(specno,'min_twotheta','period',period);

% Change sign of twotheta for the A1 bank:
lw = length(w);
scatt_ang = zeros(1,lw);
for i=1:64
    ang = get(get(w(i),'tofpar'),'twotheta');
    w(i) = set_par(w(i),'twotheta',-ang);
end

% Add line to titles to show spectrum number and nature of analysis
for i=1:length(w)
    temp = get(get(w(i),'spectrum'));
    ang = get(get(w(i),'tofpar'),'twotheta');
    temp.title = add_title(temp.title,['Spectrum ',num2str(specno(i)),'   Scan: Scattering angle']);
    temp.title= add_title(temp.title,['mgenie_control_y_val = ',num2str(ang)]);
    temp.title=add_title(temp.title,'Scattering angle');
    w(i) = set_spectrum(w(i),spectrum(temp));
end

% change units:
n_dpar = max(0,nargin-2);
if (n_dpar==0)  % no d-spacing information given
    w = rebin(units(w,'d'))
    w = rebin(units(w,'d'),dlo_def,dhi_def);
elseif (n_dpar==2)
    if (isa(p1,'double') & isa(p2,'double'))
        w = rebin(units(w,'d'),p1,p2);
    else
        error ('Check rebinning parameter types')
    end
elseif (n_dpar==3)
    if (isa(p1,'double') & isa(p2,'double') & isa(p3,'double'))
        w = rebin(units(w,'d'),p1,p2,p3);
    else
        error ('Check rebinning parameter types')
    end
else
    error ('Check number of rebinning parameters')
end

% Normalise data:

for i=1:length(w)
    w(i) = w(i)/norm;
end

% *** AN AWFUL, AWFUL FIX-UP UNTIL ADD AN EXTRA PARAMETER TO HOLD MPLOT Y VALUES ***
% use efix to hold the dplot y-axis and dintegrate x-axis values 
for i=1:length(w)
    ang = get(get(w(i),'tofpar'),'twotheta');
    w(i) = set_par(w(i),'efix',ang);
end