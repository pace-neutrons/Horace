function [] = set_crpt (source)
%SET_CRPT Set the instrument name for the crpt
%
global genie_handle
global genie_file genie_disk genie_directory genie_instrument genie_run genie_run_char genie_extension genie_dae genie_crpt
global genie_mgenie_initialised genie_opengenie_present

if ~genie_mgenie_initialised
    genie_init
end

% check the extension is a character string:
if(~isa(source,'char') | size(source,1)~=1)
    error ('CRPT name must be a character string')
end
genie_crpt = deblank(source);

command = strcat('set/crpt "',genie_crpt,'"');

if ~isempty(genie_handle)
    invoke (genie_handle,'AssignHandle',command,'');
else
    error('Command cannot be completed because OpenGenie not found')
end