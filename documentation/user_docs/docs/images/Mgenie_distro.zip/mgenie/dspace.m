function w = dspace (varargin)
% DSPACE creates an array of workspaces containing intensity as a 
% function of d-spacing for parts of the detector array of MAPS.
% Data is normalised by monitor integral.
%
% Syntax:
%   >> w = dspace_maps (irun)   % uses period 1 and default dspacing range and step
%
%   >> w = dspace_maps (irun, dspace_lo, dspace_hi)
%
%   >> w = dspace_maps (irun, dspace_lo, dspace_step, dspace_hi)
%           dspace_step +ve: constant step binning
%           dspace_step -ve: logarithmic binning
%       (type '>> help rebin' for more details of rebinning syntax)
%
%   Qualifiers:
%       period      period number 
%
%       map         different mapping schemes -
%                       - keywords recognised for the file
%                           mid-tubes: 'horizontal' [default], 'vertical'
%                                4to1: 'horizontal' [default], 'vertical',
%                                      'a1', 'a2, 'b1', 'b2', 'c1', 'c2', 'c3', 'c4'
%                       - cell array of integer arrays, each of which
%                         gives the spectra in a workspace
%

% This is a a specialised command file that makes special assumptions about the raw file. Only for MAPS.

global analysis_mon_norm analysis_mon_tlo analysis_mon_thi analysis_mon_norm_constant

%------------------------------------------------------------------------------------------------------
% default d-spacing binning.
dlo_def = 0.5;  % instrument specific (depends on scattering angle range)
dhi_def = 15;   % instrument specific (depends on scattering angle range)
%------------------------------------------------------------------------------------------------------

% Find qualifiers and their values, and check number of parameters
% --------------------------------------------------------------------
qualifier = {'period','map','mask'};
takes_value = [1,1,1];
nstart = 1;
[par,present,index,message]=parse_qualifiers(qualifier,takes_value,varargin,nstart);
if ~isempty(message)
    error(message)
end
if length(par)<1
    error ('ERROR: Must give run number to dspace_maps')
elseif length(par)~=par(end) | par(end)>4
    error ('ERROR: Check input arguments to dspace_maps')    % parameters must appear before qualifiers, and no more than four parameters
end
n_dpar = length(par)-1;

% Assign run number
if isnumeric(varargin{1})
    irun = varargin{1};
    ass (irun);
else
    error('ERROR: Run number must be numeric')
end

% Check spectrum number of monitor_1. A reasonable way of checking the spectra.dat
mdet = genie_get('mdet');
spec_list = genie_get('spec');
if double(spec_list(mdet(1))) == 577    % mid-tubes mapping
    run_type = 'mid-tubes';
    map_list = {'horizontal','vertical'};
elseif double(spec_list(mdet(1))) == 41473    % 4to1 mapping
    run_type = '4to1';
    map_list = {'horizontal','vertical','c1','c2','c3','c4'};
else
    error (['Check that a mid-tubes or 4to1 spectrum mapping file was used in run ',num2str(irun)])
end

% Check that emode = 0
[efix,emode]=get_efix;
if emode ~= 0
    error ('ERROR: Must set analysis to elastic mode i.e. EMODE=0 (Type >> help set_efix)')
end

% Get period number if present
nperiod = double(gget('nper'));
nsp1 = double(gget('nsp1'));
if present.period
    period = varargin{index.period};
    if ~isnumeric(period)|~(prod(size(period))==1)
        error ('ERROR: Period must be a scalar number')
    elseif round(period) < 0 | round(period) > nperiod
        error (['Period number must lie in the range 1-',num2str(nperiod)])
    end
    if period==0
        period = period + 1;    % accept period = 0 as meaning period 1
    end
else
    period = 1;
end

% Get mask data if present
if present.mask
    mask = varargin{index.mask};
    if ~isempty(mask)
        if ~(length(size(mask))==2 & min(size(mask))==1)|~isnumeric(mask)
            error ('ERROR: List of masked spectra must be 1D array')
        end
    else
        mask = [];
    end
else
    mask = [];
end

% Get mapping data if present
if present.map
    map = varargin{index.map};
    if ~isempty(map)
        if ischar(map) & size(map,1)==1
            answer = string_find (map, map_list);
            if answer > 0
                map = map_list{answer};
            else
                error ('ERROR: Check name of mapping')
            end
        elseif ~iscell(map)
            error ('ERROR: Check the format of the map description')
        end
    else
        map = map_list{1};   % default map
    end
else
    map = map_list{1};   % default map
end

% Perform analysis of data
% -------------------------------

% Get normalisation constant
area = integrate(unspike(mon(analysis_mon_norm,period,'none')),analysis_mon_tlo,analysis_mon_thi);
norm = area.val/analysis_mon_norm_constant;

% Read in data and store spectrum numbers:
specno = [linspace(64,1,64),linspace(65,128,64),linspace(441,576,136)];
w = mspec(specno,'min_twotheta','period',period);

% Change sign of twotheta for the A1 bank:
lw = length(w);
for i=1:64
    ang = get(get(w(i),'tofpar'),'twotheta');
    w(i) = set_par(w(i),'twotheta',-ang);
end

% Add line to titles to show spectrum number and nature of analysis
for i=1:length(w)
    add_title = ['Spectrum ',num2str(specno(i)),'   Scan: Scattering angle'];
    temp = get(get(w(i),'spectrum'));
    if isempty(temp.title)
        temp.title = add_title;
    elseif isa(temp.title,'cell')
        lt = length(temp.title);
        temp.title{lt+1} = add_title;
    elseif isa(temp.title,'char')
        temp.title = cellstr(temp.title);
        temp.title{2}=add_title;
    else
        error ('Something screwy with titles')
    end
    w(i) = set_spectrum(w(i),spectrum(temp));
end

% change units:
if (n_dpar==0)  % no d-spacing information given
    w = rebin(units(w,'d'),dlo_def,dhi_def);
elseif (n_dpar==2)
    if (isa(p1,'double') & isa(p2,'double'))
        w = rebin(units(w,'d'),p1,p2);
    else
        error ('Check rebinning parameter types')
    end
elseif (n_dpar==3)
    if (isa(p1,'double') & isa(p2,'double') & isa(p3,'double'))
        w = rebin(units(w,'d'),p1,p2,p3);
    else
        error ('Check rebinning parameter types')
    end
else
    error ('Check number of rebinning parameters')
end

% Normalise data:

for i=1:length(w)
    w(i) = w(i)/norm;
end

% *** AN AWFUL, AWFUL FIX-UP UNTIL ADD AN EXTRA PARAMETER TO HOLD MPLOT Y VALUES ***
% use efix to hold the dplot y-axis and dintegrate x-axis values 
for i=1:length(w)
    ang = get(get(w(i),'tofpar'),'twotheta');
    w(i) = set_par(w(i),'efix',ang);
end