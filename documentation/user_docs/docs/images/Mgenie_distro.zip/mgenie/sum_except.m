function s = sum_except(a, dim)
% Sums along all dimensions except for that given by the scalar dim.
% Ouput has same type as input.
%
% Syntax:
%   >> s = sum_except(a, dim)
%
% Input:
% ------
%   a       Input array
%   dim     Dimension to be excluded from the multiple sum
%
% Output:
% -------
%   s       Output array: is column vector

% Original author: T.G.Perring
%
% $Revision: * $ ($Date: * $)
%
% Horace v0.1   J. van Duijn, T.G.Perring

n = size(a);
if dim<1 | dim>length(n)
    error(['ERROR: Dimension to be excluded from the sum must lie in range 1 to ',num2str(length(n))])
end

s = a;
for i=1:length(n)
    if i~=dim
        s = sum(s,i,'native');
    end
end
s = squeeze(s);
if size(s,2)>1  % must do this because if s is a 1xn array it will not be squeezed to nx1
    s = s';
end
