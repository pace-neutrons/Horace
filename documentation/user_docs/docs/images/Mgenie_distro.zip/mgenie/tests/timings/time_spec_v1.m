function [wout,wper]=time_spec_v1(nwork,nspec)
% Time reading counts of blocks of spectra - total time, and time per workspace
% Results are spectra. One of the nwork or nspec can be an array
%   >> [w,wper] = time_spec_v1 (nwork, nspec_per work)
%   >> [w,wper] = time_spec_v1 ([1,10,20,50,100,200,500], 4)
%
% Reads nspec spectra in a lump, spaced at 2*nspec spectra.
%
% Good runs to try with: 41472 spectra in the runs
%       5740    1382 time channels
%       6372    2773 time channels
%       6342    80 time channels

isum = 1;    % no summation in spec_v1
if length(nwork) > 1
    time = zeros(1,length(nwork));
    for i = 1:length(nwork)
        disp(['Calculating nwork = ',num2str(nwork(i))])
        sp_lo = linspace(1,2*nspec*(nwork(i)-1)+1,nwork(i));
        sp_hi = sp_lo + nspec - 1;
        [w,time(i)] = spec_v1(sp_lo,sp_hi,isum);
    end
    wout = spectrum(nwork,time);
    wper = spectrum(nwork,time./nwork);
    wout = set(wout,'xlab','No. workspaces','ylab','time (s)');
    wper = set(wper,'xlab','No. workspaces','ylab','time per workspace (s)');
else
    time = zeros(1,length(nspec));
    for i = 1:length(nspec)
        disp(['Calculating nspec = ',num2str(nspec(i))])
        sp_lo = linspace(1,2*nspec(i)*(nwork-1)+1,nwork);
        sp_hi = sp_lo + nspec(i) - 1;
        [w,time(i)] = spec_v1(sp_lo,sp_hi,isum);
    end
    wout = spectrum(nspec,time);
%    wper = spectrum(nspec,time./(nwork*nspec));
    wper = spectrum(nspec,time./(nwork));
    wout = set(wout,'xlab','No. spectra','ylab','time (s)');
    wper = set(wper,'xlab','No. spectra','ylab','time per workspace (s)');
end
