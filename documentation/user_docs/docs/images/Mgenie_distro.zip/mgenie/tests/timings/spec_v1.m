function [w,time] = spec_v1(sp_lo,sp_hi,nosum)
% output the sum of an array of spectra - raw counts
%
% To sum the counts giving an array of counts:
%   >> [w, time] = spec_v1 ({array_of_lower_bounds}, {array_of_upper_bounds})
%
% No summation, single (dummy) number as return argument
%   >> [w, time] = spec_v1 ({array_of_lower_bounds}, {array_of_upper_bounds}, 1)

ntc=genie_get('ntc1');
w = zeros(1,ntc);
if (nargin==3)
    isum = 1;
else
    isum = 0;
end
tic
for i=1:length(sp_lo)
    ilo_char=sprintf('%.0f',round(sp_lo(i)));
    ihi_char=sprintf('%.0f',round(sp_hi(i)));
    cmd = strcat('cnt1[',ilo_char,':',ihi_char,']');
    cnt = double(genie_get(cmd));    % user the general GET routine
    if isum==0
        w = w + sum(cnt(2:ntc+1,:),2)';
    else
        w = cnt(2,1);
    end
end
time=toc;