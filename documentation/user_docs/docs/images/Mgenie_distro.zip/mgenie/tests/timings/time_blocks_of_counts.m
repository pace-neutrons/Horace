% time reading in blocks of counts

dsp = [1,64,128,256,512,1024,2048,3072,4096,5000,6000,8192,10000,20000,40000]
%dsp = [1,64,128,256,512,1024,2048,3072,4096,5000,6000,8192,10000]
%dsp = [1,64,128,256,512,1024,2048,3072]
isum = 1;

temp = cumsum(dsp)+1;
sp_lo = [1,temp(1:end-1)];
sp_hi = sp_lo + dsp - 1;
time = zeros(1,length(dsp));
for i = 1:length(dsp)
    disp(['block length = ',num2str(dsp(i))])
    [w,time(i)] = spec_v1(sp_lo(i),sp_hi(i),isum);
end

wout = spectrum(dsp,time./dsp);
wout = set(wout,'xlab','block length','ylab','time per spectrum (s)');
