function [pvals,sig]=test_fit (x,y,e)
% test straight line fitting - use formulae from G.L.Squires Practical Physics
% c. 1980
n=length(x);
w=1./(e.^2);
xav=sum(w.*x)/sum(w);
yav=sum(w.*y)/sum(w);
dw=sum(w.*(x-xav).^2);
m=sum(w.*(x-xav).*y)/dw;
c=yav-m*xav;
d=y-m*x-c;
sigm=sqrt(sum(w.*d.^2)/((n-2)*dw));
sigc=sqrt((sum(w.*d.^2)/(n-2))*(1/sum(w)+xav^2/dw));
pvals=[m,c];
sig=[sigm,sigc];
