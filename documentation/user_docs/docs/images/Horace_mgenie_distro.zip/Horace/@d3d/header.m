function header (w)
% HEADER Command window display of a 3D dataset. Synonym to DISPLAY
%
% Syntax:
%   >> header (w)

% Original author: T.G.Perring
%
% $Revision: 104 $ ($Date: 2007-01-29 09:50:38 +0000 (Mon, 29 Jan 2007) $)
%
% Horace v0.1   J.Van Duijn, T.G.Perring

display(w)
