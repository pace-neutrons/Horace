function p(w,varargin)
% Draws line, markers and error bars for a 1D dataset on an existing plot
%
%   >> p(w)
%
% Advanced use:
%   >> p(w,fig_name)       % draw with name = fig_name

% Original author: T.G.Perring
%
% $Revision: 115 $ ($Date: 2007-02-08 11:38:39 +0000 (Thu, 08 Feb 2007) $)
%
% Horace v0.1   J.Van Duijn, T.G.Perring

global genie_max_spectra_1d

% Check spectrum is not too long an array
if length(w)>genie_max_spectra_1d
    error (['This function can only be used to plot ',num2str(genie_max_spectra_1d),' spectra - check length of spectrum array'])
end

pe(w,varargin{:})
pm(w,varargin{:})
pl(w,varargin{:})
