function sp=spectrum(w)
% SPECTRUM  Convert a 1D dataset to an mgenie spectrum
%
% Syntax:
%   >> spec = spectrum (w)

% Original author: T.G.Perring
%
% $Revision: 35 $ ($Date: 2005-07-12 14:01:06 +0100 (Tue, 12 Jul 2005) $)
%
% Horace v0.1   J.Van Duijn, T.G.Perring

sp=d1d_to_spectrum(w);
