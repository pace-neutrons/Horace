function wout = deriv(w)
% DERIV  Numerical first derivative of a 1D dataset
%
%   >> wout = deriv(w)

% Original author: T.G.Perring
%
% $Revision: 35 $ ($Date: 2005-07-12 14:01:06 +0100 (Tue, 12 Jul 2005) $)
%
% Horace v0.1   J.Van Duijn, T.G.Perring

wtemp = deriv(d1d_to_spectrum(w));
wout = combine_d1d_spectrum (w, wtemp);
