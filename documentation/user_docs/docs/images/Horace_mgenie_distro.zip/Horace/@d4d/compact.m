function wout = compact (win)
% Squeezes the data range in a 4-dimensional dataset to eliminate empty bins
%
% Syntax:
%   >> wout = compact(win)
%
% Input:
% ------
%   win         Input dataset 
%
% Output:
% -------
%   wout        Output dataset, with length of axes reduced to yield the
%               smallest cuboid that contains the non-empty bins.
%

% Original author: T.G.Perring
%
% $Revision: 57 $ ($Date: 2005-07-28 14:18:40 +0100 (Thu, 28 Jul 2005) $)
%
% Horace v0.1   J.Van Duijn, T.G.Perring


wout = dnd_create(dnd_compact(get(win)));
