function test_warning(a)
if a>10
    warning('a is too big')
else
    disp('a is OK')
end
