% Create all the mex files for Horace
%
% T.G.Perring 23 July 2007

mex calc_proj_fortran.f
mex get_par_fortran.f
mex get_phx_fortran.f
mex get_spe_fortran.f
