function mess = sqw_checkfields (data_source)
% Check the validity of the fields in an sqw structure
% *** Dummy routine at the moment

% T.G.Perring 24 July 2007

mess=[];
